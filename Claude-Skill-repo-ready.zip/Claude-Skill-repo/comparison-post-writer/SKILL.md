---
name: comparison-post-writer
description: Write "X vs Y" comparison content that objectively evaluates two or more products/tools across real criteria, then makes a clear, honest recommendation — the highest-converting content format in affiliate marketing because it captures high commercial intent. Use when the user wants a comparison article, "vs" post, or is deciding between promoting multiple similar products.
stage: S3 Blog & SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Comparison Post Writer

Write "X vs Y" comparison content — the highest-converting affiliate content
format because it captures readers who are already deciding what to buy, not
just browsing. The skill enforces real research and honest trade-offs; comparison
posts that are obviously biased toward one option convert worse and get flagged
by readers and search engines alike.

## When to Use

- User wants a comparison article ("X vs Y", "X or Y, which is better")
- User promotes 2+ similar products and wants content that helps readers choose
- User wants high-intent, high-converting SEO content
- User has multiple affiliate programs in the same category

## Input Schema

```yaml
products: array               # REQUIRED — 2-5 products to compare
  - name: string
    url: string
    reward_value: string       # OPTIONAL — commission info (internal use only, never published)

criteria: string[]             # OPTIONAL — comparison dimensions (default: auto-selected per category)
audience: string               # OPTIONAL — who the comparison is for (default: general buyer)
recommendation_bias: string    # OPTIONAL — "neutral" | "favor-primary" (default: neutral — the honest answer wins)
format: string                 # OPTIONAL — "blog" | "linkedin" | "twitter-thread" (default: blog)
```

## Workflow

### Step 1: Research Each Product

For each product: search "[product] pricing features [current year]" and
"[product] review" — collect pricing tiers, core feature set, target user,
and 2-3 genuine limitations (every product has trade-offs; omitting them
kills credibility and conversion).

### Step 2: Select Comparison Criteria

Default criteria set (adjust per category):
- Pricing & value
- Core feature set / capability depth
- Ease of use / learning curve
- Best-fit user (who should NOT use this)
- Support & documentation quality
- Integrations / ecosystem

### Step 3: Build the Comparison Table

A scannable table beats a wall of text for this format — most readers decide from
the table alone, then read the narrative for confirmation.

### Step 4: Write the Narrative

For each product: 2-3 paragraphs covering what it does best, who it's genuinely
best for, and its honest limitation. Never write only positives — one credible
"con" per product is what makes the whole piece trustworthy.

### Step 5: Make a Clear Recommendation

End with a direct verdict structured by use case, not a single universal winner:
- "Choose [A] if you need [specific scenario]"
- "Choose [B] if you need [different scenario]"
- "Skip both if [scenario] — consider [alternative] instead"

This use-case-based structure converts better than "and the winner is..." because
it respects that different readers have different needs — and it's more honest.

### Step 6: SEO Structure (if format: blog)

- Title: "[Product A] vs [Product B]: Which Is Better in [Year]?" (adjust to genuinely reflect content)
- H2s per product + a "Quick Verdict" H2 near the top for skimmers
- Comparison table appears above the fold if possible
- FAQ section addressing 3-4 common questions (helps SEO + featured snippets)

### Step 7: Self-Validation

- [ ] Every product has at least one honest limitation listed
- [ ] Recommendation is use-case-based, not a single forced winner
- [ ] No commission amounts or reward values appear in the published content
- [ ] Comparison table data is accurate and sourced from research, not assumed
- [ ] FTC-style affiliate disclosure is present

## Output Format

```
## [Product A] vs [Product B]: [Angle]

**Quick verdict:** [1-2 sentence summary for skimmers]

| Criteria | [Product A] | [Product B] |
|---|---|---|
| Pricing | | |
| Core features | | |
| Best for | | |
| Limitation | | |

### [Product A]: [what it's best at]
[2-3 paragraphs, including one honest con]

### [Product B]: [what it's best at]
[2-3 paragraphs, including one honest con]

### Which Should You Choose?
- Choose [A] if: [scenario]
- Choose [B] if: [scenario]

### FAQ
**[Question 1]?** [answer]
**[Question 2]?** [answer]

*Disclosure: This post contains affiliate links. [standard disclosure language]*
```

## Error Handling

- **Only one product provided**: Ask for a second product, or reframe as a single-product review instead (different skill).
- **Products aren't actually comparable** (different categories): Flag this and suggest reframing as "which tool for which job" instead of a head-to-head.
- **No genuine differentiation found**: Be honest that they're similar — this itself is useful information, and pricing/support become the deciding factors.
- **User wants only positive framing for their preferred product**: Push back — comparison content with no listed cons performs worse and damages trust; recommend an honest structure instead.

## Examples

**Example 1:** "Compare [AI video tool A] vs [AI video tool B] for a blog post" → research both, build table (pricing, avatar quality, export limits, ease of use), honest cons for each, use-case verdict.

**Example 2:** "I promote 3 email tools, which one should I write about?" → run comparison across all 3, let the honest analysis surface which has the strongest differentiated use case — write that one as primary comparison.

**Example 3:** "Turn this comparison into a Twitter thread" → same research and honest trade-offs, compressed into thread format (hand off to `twitter-thread-writer` with the research as input).

## Suggested Next Skills

- `content-research-brief` (S2) — deepen product research before writing
- `affiliate-blog-builder` (S3) — for single-product reviews instead of comparisons
- `keyword-cluster-architect` (S3) — find the right comparison keywords to target
- `internal-linking-optimizer` (S6) — link this post into a broader content cluster

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
