---
name: viral-post-writer
description: Write high-converting, platform-native social media posts (LinkedIn, X, Reddit, Facebook) that promote an affiliate product through story or opinion rather than a direct pitch. Use when the user wants to promote a product on social media, write a post/thread about an affiliate offer, or asks for "viral post", "social content for affiliate", or platform-specific copy that needs to feel authentic and include FTC disclosure.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Viral Post Writer

Turn an affiliate product into a social post that people actually want to share.
Instead of a direct pitch, the skill picks a proven viral framework per platform,
grounds the post in specific detail (not generic hype), and appends the correct
FTC disclosure so the post stays compliant and native to the platform it's posted on.

## When to Use

- User wants to promote an affiliate product on LinkedIn, X/Twitter, Reddit, or Facebook
- User asks for a "viral post", a thread, or platform-specific affiliate copy
- User has personal experience with a product and wants to turn it into a shareable story
- User wants multiple platform variants of the same promotion

## Input Schema

```
{
  product: { name: string, description: string, reward_value: string, url: string }
  platform: "linkedin" | "x" | "reddit" | "facebook" | "all"
  angle: string                  # (optional) specific narrative angle
  tone: "conversational" | "professional" | "casual" | "storytelling"
  audience: string               # (optional)
  personal_experience: string    # (optional) real experience to anchor the post
  cta_style: "soft" | "direct" | "question"
}
```

## Workflow

### Step 1: Gather Context
If the product, platform, or personal experience is missing, ask before writing.
Never invent a personal story — flag it as researched if none is provided.

### Step 2: Research the Product
Quick web search for recent launches/updates, the core pain point solved, how
competitors position themselves, and real user testimonials. Pull 2-3 specific,
verifiable details — specificity is what separates a viral post from an ad.

### Step 3: Pull In Prior Research (if available)
If earlier skills in the chain produced data, use it instead of guessing:
- Winning content formats and hooks from a trend/pattern analysis
- Engagement benchmarks to set realistic expectations
- A recommended angle from an angle-ranking skill

### Step 4: Pick the Framework

| Platform | Default Framework |
|----------|-------------------|
| LinkedIn | Transformation story or contrarian take |
| X | Problem→solution thread or hot take |
| Reddit | Genuine recommendation or problem-solve narrative |
| Facebook | Before/after or listicle |

### Step 5: Write the Post
**Do:** open with a strong hook, use specific numbers/details, frame as narrative
not pitch, format natively for the platform, end with exactly one CTA.
**Don't:** open with "I'm excited to share...", use empty superlatives
("game-changer", "revolutionary"), put raw links in a LinkedIn post body (kills
reach), lead with the pitch, or mention commission amounts.

### Step 6: Attach FTC Disclosure
- LinkedIn / Facebook: `#ad | Affiliate link` in the post
- X: `#ad` in the tweet containing the link
- Reddit: `Full disclosure: affiliate link` at the bottom

### Step 7: Package the Output
Return copy-paste-ready text, link-placement guidance (e.g., first comment on
LinkedIn, pinned on X), a suggested posting time, and 2-3 engagement tips.

### Step 8: Self-Validate
- [ ] Disclosure present and correctly placed
- [ ] Hook fits platform length limits
- [ ] No banned/generic phrases
- [ ] Single CTA, no commission talk
- [ ] Link placement matches platform norms

## Output Format

```
## Viral Post: [Product] on [Platform]

**Framework:** [name]        **Angle:** [description]

### Post Content
[full post text, platform-formatted]

### Posting Guide
| Link placement | Best time | What to watch |
|---|---|---|

### Engagement Tips
1. ...
2. ...

### Variations
- [Alt framework 1]: [one-line description]
- [Alt framework 2]: [one-line description]
```

## Error Handling

- **Missing product info:** Ask for it; suggest researching the affiliate program first.
- **Unknown/unsupported platform:** Default to LinkedIn, list other supported platforms.
- **No personal experience given:** Write from research and label it as such; note that authentic first-person experience converts better.
- **Product details unavailable online:** Ask the user to describe the product directly.
- **Controversial or borderline product:** Flag the concern and propose a safer angle before writing.

## Examples

**Example 1:** "Write a LinkedIn post about my HeyGen affiliate link" → researches HeyGen, picks a transformation-story framework, writes a first-person post with two specific results, places link in the first comment, adds `#ad`.

**Example 2:** "Give me an X thread and a Reddit post for the same SaaS tool" → generates two distinct frameworks (hot-take thread vs. genuine-recommendation post), each with platform-correct disclosure and tone.

**Example 3:** "I don't know what angle to use for this productivity app" → runs quick research, surfaces 2-3 possible angles (time-saved story, contrarian take on competitors), asks user to pick before finalizing copy.

## Suggested Next Skills

- `content-pillar-atomizer` (S2) — turn this single post into 15-30 more pieces across platforms
- `infographic-generator` (S2) — pair the post with a branded visual for higher engagement
- `affiliate-blog-builder` (S3) — expand the post's angle into a full long-form article
- `social-media-scheduler` (S5) — queue the finished post(s) for optimal posting times

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
