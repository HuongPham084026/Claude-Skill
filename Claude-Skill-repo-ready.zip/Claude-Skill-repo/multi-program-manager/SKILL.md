---
name: multi-program-manager
description: Manage and compare multiple affiliate programs as an investment portfolio — computing EPC and revenue share per program, flagging concentration risk, and producing double-down/maintain/optimize/phase-out recommendations plus a weekly time-allocation plan. Use when the user promotes 2+ programs and asks which to prioritize, whether they're too concentrated in one program or niche, or wants a portfolio-level view instead of single-program metrics.
stage: S7 Automation
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Multi-Program Manager

Treat a stack of affiliate programs like an investment portfolio rather than a
pile of disconnected side hustles. This skill compiles every program's
performance into one dashboard, scores each on earnings quality and effort,
flags concentration risk, and turns the analysis into a concrete weekly hour
allocation — so time goes toward the programs actually worth the effort.

## When to Use

- User promotes multiple affiliate programs and asks "which one should I focus on"
- User wants a side-by-side comparison of programs' performance
- User is worried about over-relying on a single program, product, or niche
- User wants a portfolio-style dashboard instead of single-program reporting
- Chains naturally from program research (S1) and performance tracking (S6), feeding into funnel planning (S8)

## Input Schema

```
{
  programs: [
    {
      name: string,              # REQUIRED
      revenue: number,           # REQUIRED — monthly revenue from this program
      clicks: number,            # REQUIRED — monthly clicks sent
      url: string,                # OPTIONAL
      commission_type: string,    # OPTIONAL — "recurring" | "one-time" | "tiered"
      niche: string,               # OPTIONAL — for overlap/diversification analysis
      status: string                # OPTIONAL — "active" | "paused" | "testing"
    }
  ],
  weekly_hours: number,          # OPTIONAL — time budget for allocation plan, default 10
  goal: string                   # OPTIONAL — "maximize_revenue" | "reduce_risk" | "diversify"
}
```

If commission type, niche, or URL are missing, proceed anyway — flag that the analysis is based on revenue/clicks only and would sharpen with the missing fields.

## Workflow

### Step 1: Build the portfolio overview
Compile all programs into one dashboard: revenue, clicks, EPC, and status per program, plus totals and each program's share of total portfolio revenue.

### Step 2: Calculate per-program metrics
- **EPC** (earnings per click) = revenue ÷ clicks
- **Revenue share** = program revenue ÷ total portfolio revenue
- **Effort ratio** = rough estimate of hours spent promoting vs. revenue generated (ask or estimate from status/activity)
- **Commission quality score** — weight recurring commissions and high EPC above one-time low-EPC programs, even if raw revenue looks similar

### Step 3: Analyze portfolio-level risk
- **Concentration risk**: if any single program is >50% of total revenue → flag HIGH RISK, regardless of how well that program performs
- **Niche overlap**: multiple programs in the same niche reduce true diversification even if they're technically different companies — a portfolio can look diversified by program count but be fragile by niche count
- **Revenue stability**: recurring-commission programs are weighted as more stable than one-time-payout programs when assessing overall portfolio health

### Step 4: Generate per-program recommendations
Assign each program one action:
- **Double down** — high EPC, low effort, recurring commission → invest more time/content here
- **Maintain** — solid but not exceptional → keep current effort level
- **Optimize** — good potential but underperforming (low EPC relative to niche, or high clicks/low conversion) → specific fix needed before deciding to scale
- **Phase out** — low EPC, high effort, one-time payout, declining → redirect that time elsewhere

### Step 5: Build the weekly action plan
Allocate `weekly_hours` across programs proportional to their action tier — most hours to "double down" programs, some to "optimize," minimal maintenance time to "maintain," and a defined sunset task (not ongoing hours) for "phase out."

### Step 6: Self-validate before delivering
- EPC and revenue-share math is correct and sums to 100%
- Concentration-risk threshold (>50%) is applied consistently
- Every program has exactly one recommended action
- Weekly hours sum to the stated `weekly_hours` budget
- Niche-overlap flag doesn't get skipped just because niche field was optional/missing (note the gap instead)

## Output Format

```
## Affiliate Portfolio Report

### Portfolio Dashboard
| Program | Revenue | Clicks | EPC | Revenue Share | Status |
|---|---|---|---|---|---|

### Portfolio Health
- Concentration risk: [LOW/MEDIUM/HIGH] — [top program] = X% of revenue
- Niche diversification: [assessment]
- Revenue stability: [% recurring vs one-time]

### Program Scorecards
**[Program name]** — Action: [DOUBLE DOWN / MAINTAIN / OPTIMIZE / PHASE OUT]
Why: ...
Next step: ...

### Weekly Action Plan (X hours)
| Program | Hours | Focus |
|---|---|---|

### Strategic Recommendations
1. ...
2. ...
```

## Error Handling

- **Fewer than 2 programs provided:** This skill's value is comparative — with one program, redirect to a single-program performance skill instead, or ask if there are other programs to include.
- **Missing revenue/click data for some programs:** Rank what's calculable, and for the rest use qualitative signals (commission structure, niche fit, stated effort) with an explicit "estimated" label.
- **All programs in one niche:** Still compute concentration/EPC metrics, but add a standalone flag that niche diversification is zero regardless of how spread the program count looks.
- **Extremely lopsided portfolio (one program is 90%+ of revenue):** Don't just label HIGH RISK — explicitly recommend either building a second program to redundancy-level revenue, or consciously accepting the concentration if switching costs are high.

## Examples

**Example 1:** "I promote HeyGen, Semrush, and Jasper — which should I focus on?" → builds a 3-row dashboard with EPC and revenue share, finds HeyGen is 65% of revenue (HIGH concentration risk), recommends doubling down on HeyGen's best-converting content while explicitly building out Semrush as a hedge.

**Example 2:** "Am I too spread out across 8 different programs?" → computes revenue share per program, finds 5 of the 8 earn under 5% of total revenue each, recommends phasing out the bottom 3 by effort ratio and reallocating those hours to the top 2.

**Example 3:** "Give me a weekly plan, I only have 6 hours a week for affiliate work" → allocates the 6 hours across double-down and optimize-tier programs only, with a one-time (not recurring) task for phasing out the weakest program.

## Suggested Next Skills

- `conversion-tracker` (S6) — the click/revenue data this skill depends on should come from consistent tracked links
- `email-automation-builder` (S7) — build a dedicated automation for whichever program gets the "double down" verdict
- `proprietary-data-generator` (S7) — publish an anonymized version of the portfolio-strategy findings as original content

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
