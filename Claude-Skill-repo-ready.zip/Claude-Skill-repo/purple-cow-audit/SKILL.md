---
name: purple-cow-audit
description: Score a product's remarkability 1-10 across seven weighted dimensions before deciding whether to promote it, using Seth Godin's "Purple Cow" test — would you recommend this to a friend without earning a commission? Use when the user is deciding whether a product is worth promoting, has a shortlist from affiliate-program-search to narrow down, or wants an honest quality gate before investing time in content.
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Purple Cow Audit

A quality gate that stops the user from wasting months of content creation on
a mediocre product. Based on Seth Godin's Purple Cow idea: if a product isn't
genuinely remarkable, no amount of marketing skill makes it convert
sustainably. The central test is simple and unforgiving — "Would I recommend
this to a friend if I earned zero commission?"

## When to Use

- User is considering promoting a specific product and wants an honest read on it
- User asks directly "is this worth promoting?" or "should I promote this?"
- User has a shortlist (e.g., from `affiliate-program-search`) and needs to pick the best one
- Before investing time in landing pages, funnels, or content for a specific product

## Input Schema

```
{
  product: {
    name: string
    url: string
    description: string      # optional
    reward_value: string     # optional — commission rate, useful for bias-checking
  },
  comparison_products: string[]   # optional — competitors to benchmark against; auto-discovered if omitted
}
```

## Workflow

### Step 1: Research the Product
- `web_search`: `"<product>" review 2025 2026` — recent, real user reviews
- `web_search`: `"<product>" vs` or `"<product>" alternative` — identify direct competitors
- `web_search`: `"<product>" complaints` or `"<product>" problems` — surface real weaknesses, not marketing copy
- Check the product's own site for pricing transparency, distinctive features, and genuine social proof (not just testimonial widgets)

### Step 2: Score Seven Remarkability Dimensions

| Dimension | Weight | Question |
|---|---|---|
| Uniqueness | 20% | Does it do something no competitor does? |
| Quality | 20% | Is it genuinely excellent at its core job? |
| Story | 15% | Does using it change how someone feels or is perceived? |
| Word of Mouth | 15% | Would real users mention it to a friend unprompted? |
| Design | 10% | Is the experience delightful, not merely functional? |
| Problem Fit | 10% | Does it solve a real, painful problem? |
| Trust | 10% | Transparent pricing, responsive support, credible social proof? |

Composite score = weighted average, 1-10.

### Step 3: Apply the Verdict
- **8-10 — PROMOTE**: a genuine Purple Cow, go all in
- **6-7 — PROMOTE WITH ANGLE**: solid product, but needs a sharp positioning angle to stand out
- **4-5 — CAUTION**: mediocre; only proceed if commission is exceptional and the user can add real value via bonuses
- **1-3 — SKIP**: not remarkable — promoting it risks the user's reputation; find an alternative

### Step 4: Extract Remarkable Angles (for scores 6+)
Identify: (1) the 1-2 genuinely remarkable features to lead with, (2) the
angles that make content share-worthy, (3) the specific audience segment for
whom this product IS a Purple Cow, even if it isn't for everyone.

### Step 5: Self-Validate
- [ ] Score is backed by cited evidence, not vibes
- [ ] Verdict wasn't inflated by a high commission rate
- [ ] Remarkable angles are specific, not generic praise ("great tool!")
- [ ] Competitor comparison is fair, not a strawman
- [ ] The "recommend without commission" test was applied honestly

## Output Format

```
## Purple Cow Audit: [Product Name]

### The Question
Would I recommend [product] to a friend WITHOUT earning a commission?
**Answer:** [Yes / No / With caveats]

### Remarkability Scorecard
| Dimension | Score | Evidence |
|---|---|---|
| Uniqueness | X/10 | ... |
| Quality | X/10 | ... |
| Story | X/10 | ... |
| Word of Mouth | X/10 | ... |
| Design | X/10 | ... |
| Problem Fit | X/10 | ... |
| Trust | X/10 | ... |
| **Composite** | **X/10** | |

### Recommendation: [PROMOTE / PROMOTE WITH ANGLE / CAUTION / SKIP]
[2-3 sentences of reasoning]

### Remarkable Angles to Lead With
1. ...
2. ...

### Red Flags to Be Honest About
1. ...

### If Score < 6: Better Alternatives
- [Alternative] — why it's more remarkable
```

## Error Handling

- **No product specified**: ask for a name/URL, or suggest running `affiliate-program-search` first to generate candidates.
- **Product too new for reviews**: score on available data, flag low confidence explicitly ("revisit in 3 months once reviews exist").
- **User disputes the score**: treat the score as a starting framework — if the user has firsthand experience that contradicts it, incorporate that and re-score.
- **No comparable alternatives found**: suggest running `affiliate-program-search` within the same category to surface options.
- **High commission but low remarkability**: explicitly call this out — a generous payout doesn't offset a mediocre product long-term.

## Examples

**Example 1:** "Is HeyGen worth promoting?" → Research surfaces strong reviews and unique lip-sync tech; scores 8/10 → PROMOTE, with the AI avatar quality as the lead angle.

**Example 2:** "Evaluate these 3 programs from my search results" → Score all three side-by-side on the same rubric, recommend the highest composite score.

**Example 3:** "Should I promote this generic SaaS tool?" → Research reveals 4 near-identical competitors with no differentiation; scores 5/10 → CAUTION, suggests finding a more remarkable alternative or a micro-audience where it stands out.

## Suggested Next Skills

- `affiliate-program-search` (S1) — source more candidates if the audited product scores low
- `monopoly-niche-finder` (S1) — find the specific audience segment where a mid-scoring product IS remarkable
- `commission-calculator` (S1) — once a product passes the audit, project realistic earnings from promoting it

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
