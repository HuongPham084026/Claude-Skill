---
name: seo-audit
description: Audit an affiliate blog post or landing page across on-page SEO dimensions — structure, keyword usage, meta tags, E-E-A-T signals, affiliate-link compliance (rel=nofollow sponsored, FTC disclosure), and internal linking — producing a 0-100 scorecard and a prioritized fix-it checklist. Use when the user asks "why isn't my page ranking?", wants a pre-publish SEO check, or wants to audit existing affiliate content for compliance and search performance.
stage: S6 Analytics
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# SEO Audit

Runs an affiliate blog post or landing page through a structured on-page SEO
and compliance check, then returns a scorecard plus a fix-it checklist ordered
by effort so the highest-impact, lowest-effort fixes get done first.

## When to Use

- User asks "why isn't my page ranking?" or wants a pre-publish SEO check
- User wants to audit existing content for on-page issues before promoting it
- User needs to confirm affiliate-link compliance (nofollow/sponsored, FTC disclosure) is in place
- Chaining from content-creation skills — audit the blog post or landing page just written before it ships

## Input Schema

```
{
  content: string,           # REQUIRED - markdown, HTML, or a URL to fetch
  target_keyword: string,    # REQUIRED - primary keyword to optimize for
  content_type: string,      # optional - "blog_post" | "landing_page" (default: blog_post)
  secondary_keywords: [string],  # optional
  competitor_urls: [string]      # optional - for relative comparison
}
```

Blog posts and landing pages are held to different standards (e.g., blog posts expected ≥1,500 words with topic depth; landing pages judged more on conversion-oriented structure than word count).

## Workflow

### Step 1: Content Structure
Check word count against the content-type norm, heading hierarchy (single H1, logical H2/H3 nesting), paragraph length/scannability, and topic depth relative to the target keyword.

### Step 2: Keyword Usage
Verify the target keyword appears in the title, the H1, and the first ~100 words. Check keyword density (avoid stuffing) and presence of related/LSI terms. Check secondary keywords are woven in naturally, not forced.

### Step 3: Meta Tags
Title tag length (~50-60 chars), meta description length (~150-160 chars) and whether it includes a call-to-action, Open Graph tags present, canonical URL set correctly.

### Step 4: E-E-A-T Signals
Look for evidence of first-hand Experience (screenshots, "I tested," specific numbers), Expertise (author credentials, depth), Authoritativeness (citations, outbound links to reputable sources), and Trustworthiness (contact info, transparent methodology, dated/updated content).

### Step 5: Affiliate Compliance
- Every affiliate link uses `rel="nofollow sponsored"` (Google's requirement for paid/affiliate links)
- An FTC disclosure is present, clear, and placed before the first affiliate link (not buried in a footer)
- Disclosure language is unambiguous ("This post contains affiliate links" — not vague euphemisms)

### Step 6: Internal Linking
Check for links to related content, descriptive (non-generic) anchor text, and reasonable link density — flag orphaned opportunities where a natural related-content link is missing entirely.

### Step 7: Score and Prioritize
Rate each of the above dimensions 1-10, then compute an overall 0-100 score (weighted average). Sort every identified issue into:
- **Quick wins** — under 5 minutes (meta description tweak, missing nofollow tag)
- **Medium effort** — 15-60 minutes (restructure headings, add missing keyword usage)
- **Major revisions** — requires substantial rewriting (add depth, restructure content, build E-E-A-T signals)

## Output Format

```
## SEO Audit: <title/URL>

**Target keyword:** <keyword>  |  **Overall Score: <n>/100**

### Scorecard
| Dimension | Score (1-10) | Notes |
|---|---|---|
| Content Structure | | |
| Keyword Usage | | |
| Meta Tags | | |
| E-E-A-T Signals | | |
| Affiliate Compliance | | |
| Internal Linking | | |
| Readability | | |
| Mobile-Friendliness | | |

### Quick Wins (<5 min)
- ...

### Medium-Effort Fixes (15-60 min)
- ...

### Major Revisions
- ...
```

## Error Handling

- **No target keyword given:** ask for it — every dimension is scored relative to a target keyword, and without one the audit degrades to generic content review only.
- **URL fetch fails:** ask the user to paste the content directly (markdown or HTML).
- **Content is very short (<300 words) for a blog post:** score content depth low and flag "major revision: expand content" as the top-priority fix rather than nitpicking meta tags.
- **No affiliate links present:** skip the affiliate-compliance dimension's link checks but still verify FTC disclosure isn't falsely present; note the page may not need disclosure at all.
- **Landing page audited with blog-post standards accidentally applied:** confirm `content_type` before scoring — landing pages shouldn't be penalized for lacking 1,500+ words.

## Examples

**Example 1:** "Audit my blog post for SEO, target keyword 'best AI video generator'" → Runs all 7 checks, finds keyword missing from the first 100 words and no FTC disclosure before the first affiliate link, scores 62/100, lists adding disclosure and keyword placement as quick wins.

**Example 2:** "Why isn't my HeyGen review ranking?" (pastes URL) → Fetches the page, finds thin content (600 words vs. 1,500+ norm) and no E-E-A-T signals (no screenshots, no personal testing evidence), flags content depth as a major revision needed.

**Example 3:** "Check if my landing page affiliate links are compliant" → Focuses the affiliate-compliance dimension, confirms/flags missing `rel="nofollow sponsored"` attributes and disclosure placement.

## Suggested Next Skills

- `internal-linking-optimizer` (S6 Analytics) — go deeper on the internal-linking dimension flagged in this audit, across the whole site rather than one page
- `performance-report` (S6 Analytics) — once fixes ship, track whether the page's traffic/EPC improves
- `ab-test-generator` (S6 Analytics) — test alternative headlines/CTAs on pages that score well on SEO but still underperform on conversion

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
