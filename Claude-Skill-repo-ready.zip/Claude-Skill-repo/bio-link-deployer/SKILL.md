---
name: bio-link-deployer
description: Generate a self-contained, single-file "link in bio" hub page (Linktree-style) that aggregates affiliate links, blog posts, landing pages, and social profiles into one mobile-first HTML page with theme options. Use when the user wants a bio link page, a Linktree/Beacons/Stan Store alternative, or a single URL to put in their Instagram/TikTok/X/YouTube bio.
stage: S5 Distribution
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Bio Link Deployer

Builds a lightweight, self-owned "link in bio" hub — a single HTML file
listing all of a creator's affiliate offers, content, and profiles behind
one URL. This becomes the funnel entry point for every platform's bio field,
replacing paid tools like Linktree, Beacons, or Stan Store with something
free and fully owned by the creator.

## When to Use

- User wants a link-in-bio page for their social profiles
- User has several affiliate links, blog posts, or landing pages and needs one page to hold them all
- User explicitly mentions "linktree", "bio link", "link hub", or "link in bio"
- User wants a free, self-hosted alternative to paid link-aggregator tools
- User asks to bundle everything built earlier in the conversation (products, blog posts, landing pages) into one page

## Input Schema

```
{
  user_name: string        # REQUIRED - display name/handle, e.g. "@alexcreator"
  tagline: string          # optional short bio line; auto-generated if omitted
  avatar_url: string       # optional; falls back to a niche-matched emoji
  links: [                 # REQUIRED - at least 3
    { label: string, url: string, category: string, icon: string (optional emoji) }
  ]
  theme: "minimal" | "dark" | "gradient"   # optional, default "minimal"
}
```

If earlier work in the conversation produced affiliate product picks, blog
posts, or landing pages, pull those in automatically instead of re-asking:
product URLs become "Featured Tools", blog/content URLs become "My Content",
landing pages become "Landing Pages", and any social profiles become "Connect".

## Workflow

### Step 1: Collect and Categorize Links
Gather links from whichever source applies:
- **Direct input** — use the provided `links` array as-is.
- **Conversation context** — pull affiliate URLs, blog posts, and landing pages already produced earlier and auto-tag them by type.
- **Partial input** — ask only for what's missing; the hard minimum is a name plus 3 links.

Order categories so the highest-value link is seen first:
1. Featured Tools (affiliate/money links)
2. My Content (blog posts, videos, landing pages)
3. Connect (social profiles, email, website)

### Step 2: Choose and Apply a Theme
Pick one of three visual directions based on the user's niche/brand:

| Theme | Look | Best for |
|---|---|---|
| Minimal | White background, dark text, 12px rounded cards | Professional/clean brands |
| Dark | Navy background, light text, blue accents | Tech, gaming, modern brands |
| Gradient | Purple-to-blue background, frosted-glass cards, 24px rounded corners | Creative, lifestyle, bold brands |

Use CSS custom properties so the theme is a single variable swap. If no
`avatar_url` is supplied, render an emoji placeholder matched to the user's
niche instead of a broken image tag.

### Step 3: Assemble the Page
Produce one self-contained HTML file (inline CSS, no external dependencies,
no build step) that:
- Renders correctly at 375px width first (mobile is 90%+ of bio-link traffic)
- Groups links under their category headers in the priority order from Step 1
- Includes a short FTC affiliate disclosure line in the footer
- Includes a small "built with [tool]" attribution footer

### Step 4: Deliver Output and Deploy Instructions
Present three parts: a short summary (name, theme, link count, categories),
the full HTML in a code block ready to save as `index.html`, and deploy
options:
- **Netlify Drop** — drag the file to app.netlify.com/drop (fastest, ~30s)
- **Vercel** — `npx vercel deploy --prod`
- **GitHub Pages** — push to a repo, enable Pages on the main branch
- Optional custom domain via DNS CNAME/A record pointing at the host

### Step 5: Self-Check Before Delivering
- Every link is a real, working URL (no placeholders)
- Layout holds up at mobile width
- Theme variables applied consistently, unused theme CSS removed
- Money/affiliate links appear before generic content or social links
- Disclosure and attribution footers present

## Output Format

```
--- BIO LINK PAGE ---
Name: <user_name>
Theme: <minimal|dark|gradient>
Links: <count>
Categories: <list>
---

<complete HTML file in a code block>

--- DEPLOY ---
1. Save as index.html
2. Preview locally by opening the file in a browser
3. Deploy: Netlify Drop / Vercel / GitHub Pages
4. Paste the live URL into every social bio (Instagram, TikTok, X, LinkedIn, YouTube)
5. Optional: point a custom domain at it
---
```

## Error Handling

- **Fewer than 3 links supplied:** ask for more before generating — a bio page needs enough content to justify existing.
- **No user_name given:** ask "what name or handle should I show?" rather than guessing.
- **Broken/missing avatar URL:** silently substitute a niche-appropriate emoji and mention the swap.
- **Unrecognized theme value:** fall back to "minimal" and tell the user which themes are supported.
- **Very large link lists (20+):** include everything but suggest trimming to the top 10-15 with a separate "full directory" link for the rest.

## Examples

**Example 1:** "Create a dark-themed bio link page for @sarahcontent with these 4 links: HeyGen, Semrush, my HeyGen review post, and my X profile" → builds a dark-theme page with Tools/Content/Connect categories and outputs the HTML plus deploy steps.

**Example 2:** "Make me a bio link page with everything we've done today" (after earlier product research, a blog post, and a landing page were produced in-session) → auto-gathers all those URLs, categorizes them, defaults to the minimal theme.

**Example 3:** "I need a link in bio page" (no details given) → asks for a display name and at least 3 links before proceeding.

## Suggested Next Skills

- `email-drip-sequence` (S5) — turn bio-link traffic into a nurtured email list
- `social-media-scheduler` (S5) — drive consistent traffic to the new bio link
- `conversion-tracker` (S6) — measure which links on the page actually get clicked

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
