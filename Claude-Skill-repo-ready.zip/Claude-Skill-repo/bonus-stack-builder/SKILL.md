---
name: bonus-stack-builder
description: Designs an exclusive stack of bonuses that make one specific affiliate link the obvious choice, since the underlying product is identical no matter whose link a buyer uses. Use when the user promotes an affiliate product and wants to differentiate from every other affiliate promoting the same offer, or asks "why would someone buy through my link" or "what bonuses should I offer."
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Bonus Stack Builder

Because the product is identical through every affiliate's link, bonuses are
the actual differentiator. This skill designs a stack of 5-7 specific,
deliverable bonuses matched to the user's own skills and the audience's real
pain points — not vague promises — and calculates a total stack value against
the product's price so the offer feels lopsided in the buyer's favor.

## When to Use

- User promotes an affiliate product and wants to stand out from other affiliates selling the same thing
- User asks "why buy through my link?" or has flat/low conversion despite decent traffic
- User says "bonus," "bonus stack," "exclusive offer," or "differentiate"
- Following an offer-design step, to flesh out bonus ideas already proposed

## Input Schema

```
{
  product: { name, description, pricing, url, tags: string[] },  # REQUIRED
  your_skills: string[],          # OPTIONAL — writing, design, coding, consulting, etc.
  audience_pain_points: string[], # OPTIONAL — inferred from product category if omitted
  existing_bonuses: string[]      # OPTIONAL
}
```

## Workflow

### Step 1: Gather Context
Pull product details from context or search for them. Identify the product's
top 3 pain points it solves, and separately its top 3 gaps — things buyers
still struggle with *after* purchasing. Search
`"[product] complaints" OR "[product] struggles" OR "[product] learning curve"`
to surface real post-purchase friction; these gaps are the best bonus opportunities,
since the product itself can't fill them but a well-made bonus can.

### Step 2: Design the Bonus Stack
For every bonus, define: what it specifically is (never vague), which pain
point or product gap it addresses, its format (PDF, video, template,
spreadsheet, community access, live call), its perceived standalone value,
the effort required to create it (low/medium/high), and why it's exclusive to
this link.

Design 5-7 bonuses spread across three tiers:
- **Tier 1 — Quick wins:** low effort, high perceived value (templates, checklists, swipe files). Build these first.
- **Tier 2 — Deep value:** medium effort, high impact (mini-course, workshop recording, a tool).
- **Tier 3 — Premium:** high effort, strongest differentiator (personal support, private community, 1:1 call).

### Step 3: Calculate Stack Value
Sum the perceived value of all bonuses and compare it to the product's price —
target a bonus-to-price ratio of roughly 3x-10x. Identify the single "hero
bonus" that carries the most persuasive weight and should be featured most
prominently.

### Step 4: Write the Bonus Copy
For each bonus: a specific, benefit-driven name (never "Bonus #1"), a
one-line description of what it is and what it does for the buyer, a value
statement ("$XX value — FREE with your purchase"), and how it's delivered
after purchase.

### Step 5: Self-Check
- Every bonus is concrete and actually deliverable, not a vague promise
- At least one bonus targets the product's single biggest post-purchase gap
- Total bonus value clearly exceeds the product price
- At least one bonus is genuinely exclusive to this link
- Every bonus is within the user's real capacity to create
- No income claims or unrealistic outcome promises

## Output Format

```
## Bonus Stack: [Product Name]

### Stack Overview
- Product price: $XX
- Total bonus value: $XXX
- Hero bonus: [name]
- Headline message: "Get $XXX in exclusive bonuses FREE when you buy through my link"

### Bonus 1: [Name] ($XX value)
- What: [specific deliverable]
- Solves: [pain point / gap]
- Format: [format]
- Delivery: [how they receive it]
- Why exclusive: [reason]

[repeat per bonus]

### Ready-to-Paste Copy
✅ [Bonus 1] — [one-liner] ($XX value)
✅ [Bonus 2] — [one-liner] ($XX value)
...
Total value: $XXX — yours FREE through my link

### Creation Priority
1. [Easiest bonus — build and launch first]
2. [Next priority]
3. [Can follow later]
```

## Error Handling

- **No product given:** ask for one, or point to a program-research step first.
- **No skills specified:** default to universal, low-effort bonuses anyone can make — curated resource lists, setup checklists, comparison spreadsheets, email templates.
- **Product is a free tier:** shift bonus framing from financial value to speed — templates and guides that accelerate results rather than add dollar value.
- **User can't realistically deliver high-effort bonuses:** weight the stack toward Tier 1 items, which carry high perceived value for low creation cost.

## Examples

**Example 1:** "Design bonuses for [an AI video tool] affiliate link" → research common pain points (avatar setup, scripting, editing), propose a setup guide, script template pack, brand-voice cheat sheet, private community access, and a 1:1 setup call.

**Example 2:** "What bonuses can I offer for [an SEO tool]? I'm a content writer." → match writer skills to product gaps: keyword-research template, content calendar spreadsheet, SEO audit checklist, per-content-type writing prompts, monthly strategy call.

**Example 3:** "Flesh out the bonus ideas from the offer I just designed" → take the rough bonus list, add specific deliverables, formats, values, and a creation-order roadmap.

## Suggested Next Skills

- `landing-page-creator` (S4) — surface the bonus stack in a page's bonus section
- `guarantee-generator` (S4) — the bonus stack often shapes what's realistic to guarantee
- `squeeze-page-builder` (S4) — a single bonus can double as the lead magnet
- `email-drip-sequence` (S5) — bonus reveals make strong email content

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
