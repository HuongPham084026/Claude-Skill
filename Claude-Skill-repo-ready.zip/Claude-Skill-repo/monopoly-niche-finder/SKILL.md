---
name: monopoly-niche-finder
description: Find intersection niches where the user can become the dominant authority by combining two unrelated domains of expertise, applying the "competition is for losers" principle to escape saturated markets. Use when the user is stuck in a crowded niche, wants to find an underserved audience, or asks "what niche should I pick?"
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Monopoly Niche Finder

Help the user find a niche narrow enough to dominate but broad enough to
monetize, by intersecting two domains of expertise or interest instead of
competing head-on in a saturated single category. Rooted in Peter Thiel's idea
that durable advantage comes from monopoly, not competition.

## When to Use

- User is starting from scratch and doesn't know what niche to pick
- User is stuck competing in an oversaturated niche ("AI tools", "make money online")
- User wants to know how to become "the" authority in a space rather than one of many
- User has two areas of knowledge/interest and wants to know if combining them is viable

## Input Schema

```
{
  expertise_areas: string[]     # domains the user knows or is credible in
  interests: string[]           # optional — topics they enjoy, even without deep expertise
  avoid_niches: string[]        # optional — niches already tried/saturated
  monetization_required: bool   # default: true — must have viable affiliate programs
}
```

## Workflow

### Step 1: Map Expertise and Interests
List everything the user has real credibility in (professional background,
hobbies, lived experience) plus adjacent interests. Aim for at least 4-6
distinct areas — intersections need raw material.

### Step 2: Generate Niche Intersections
Cross-multiply expertise areas against interests and audience segments to
generate candidate intersections. Examples of the pattern:
- "AI video tools" × "real estate agents" → "AI video tools for real estate listings"
- "Personal finance" × "new parents" → "budgeting for first-time parents"
- "Productivity apps" × "freelance illustrators" → niche tool reviews for a specific creative profession

Generate 8-10 candidate intersections minimum before narrowing.

### Step 3: Validate with Search Data
For each candidate:
- `web_search`: `"<intersection>" reddit` — is there an active community discussing this exact combination?
- `web_search`: `"<intersection>" -site:reddit.com` — how much existing content covers it? Thin content = opportunity.
- Check for a search volume signal (even directionally) that people are looking for this

### Step 4: Score Candidates

| Dimension | Weight | What to check |
|---|---|---|
| Monopoly Potential | 30% | How few credible voices currently serve this exact intersection |
| Monetization Viability | 25% | Confirmed affiliate programs or products exist for this audience |
| Audience Size | 20% | Big enough to sustain a business, not a niche of one |
| Personal Fit | 15% | User has genuine credibility/interest, not just opportunism |
| Content Sustainability | 10% | Enough angles to produce content for 12+ months without repeating |

### Step 5: Deep-Dive the Winner
For the top-scoring niche, produce:
- 3-5 specific content pillar topics
- Evidence of demand (cited Reddit threads, forum posts, or search signals)
- Competitor gap analysis — who else serves this exact intersection, and what are they missing?
- Confirmed affiliate programs or monetization paths available

### Step 6: Self-Validate Monopoly Potential
- [ ] The niche is specific enough that the user could realistically become the #1 voice within 6-12 months
- [ ] It's broad enough to sustain content and revenue (not a niche of 200 people)
- [ ] Evidence of demand is real, not assumed
- [ ] At least one confirmed monetization path exists

## Output Format

```
## Monopoly Niche Analysis

### Candidate Intersections Considered
| Intersection | Monopoly | Monetization | Audience | Fit | Sustainability | Score |
|---|---|---|---|---|---|---|
| ... | X | X | X | X | X | X/10 |

### Winning Niche: [Intersection Name]

**Why this is a monopoly opportunity:**
[2-3 sentences citing evidence]

**Evidence of demand:**
- [Reddit thread / forum post / search signal]
- [Reddit thread / forum post / search signal]

**Competitor gap:**
[Who serves this space today and what's missing]

**Content pillars (12-month runway):**
1. ...
2. ...
3. ...

**Monetization paths:**
- [Affiliate program / product category]

### Runner-Up Niche
[1-2 sentences, in case the winner doesn't resonate]
```

## Error Handling

- **User has no clear expertise areas**: broaden to interests, hobbies, and life circumstances (parent, freelancer, expat, etc.) — expertise isn't required, credibility can be built.
- **All intersections too narrow to monetize**: widen one side of the intersection (broader interest or broader audience) and re-score.
- **No evidence of demand found**: don't force a recommendation; say the niche may be too early or too small, and suggest 2 alternate intersections.
- **User wants to stay in a saturated niche anyway**: don't block them — instead identify a sub-intersection within it that's less contested.

## Examples

**Example 1:** "I'm a nurse who's really into productivity apps, what niche should I pick?" → Generates intersections like "productivity systems for shift workers," validates demand via Reddit nursing communities, scores and recommends the strongest one with content pillars.

**Example 2:** "Everyone's already doing AI tool reviews, I feel stuck" → Cross-multiplies "AI tools" against the user's other interests/audiences to find an underserved sub-niche instead of abandoning the category entirely.

## Suggested Next Skills

- `affiliate-program-search` (S1) — find programs to monetize the winning niche
- `purple-cow-audit` (S1) — vet specific products within the niche before promoting
- `trending-content-scout` (S1) — see what's already resonating within the chosen intersection

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
