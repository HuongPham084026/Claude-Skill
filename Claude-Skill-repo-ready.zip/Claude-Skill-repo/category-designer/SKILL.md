---
name: category-designer
description: Help an affiliate escape a crowded, price-competitive niche by designing a new "category" — a fresh buying frame with its own name, point of view, and evaluation criteria — instead of competing head-on inside an existing one. Use when the user feels stuck competing on price/features against bigger sites, wants to "own" a niche narrative, or asks how to stand out in a saturated market.
stage: S8 Meta
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Category Designer

Most affiliates lose because they compete inside a category someone else already
defined — "best budget laptop," "top CRM tool" — where the biggest, most-funded
player always wins on the buyer's existing checklist. Category Designer flips this:
it helps the user invent a narrower, ownable category with its own name and its
own rules for what "good" means, so the comparison the buyer makes is one the
user's offer is guaranteed to win. Category kings capture a disproportionate share
of category economics — this skill exists to make the user one.

## When to Use

- User is stuck competing on price or generic "best X" rankings against bigger, better-funded competitors
- User wants a distinctive brand/content angle instead of blending into a saturated niche
- User has a genuinely different audience, use case, or mechanism but is still describing it with the old category's language
- Feeds naturally after `monopoly-niche-finder` or `purple-cow-audit` once a promising gap has been identified but not yet named
- User asks "how do I stand out," "how do I stop competing on price," or "what makes my angle different"

## Input Schema

```
{
  product_or_niche: string        # What's being promoted (product, program, or niche)
  current_positioning: string     # (optional) How it's described/marketed today
  target_audience: string         # (optional) Known or hypothesized audience segment
  known_differentiators: string[] # (optional) Any unique capability, mechanism, or angle already identified
}
```

## Workflow

### Step 1: Map the Current Category
Identify the existing category the product is implicitly competing in (e.g., "AI video generators," "budget running shoes"). List the top 3-5 incumbents and the criteria buyers currently use to compare options (price, feature count, brand trust, reviews). Note where the user's offer loses on these criteria — that's the trap of playing the existing game.

### Step 2: Find the Category Seed
A new category seed sits at the intersection of three things:
1. **Unique capability or mechanism** — something the product does differently, not just better
2. **Specific audience** — a narrower slice underserved by the generic category (e.g., "non-creators," "solo landlords," "first-time freelancers")
3. **Desired outcome** — the transformation that audience actually wants, described in their language, not the incumbents' feature language

Where these three overlap is the category seed. Test it: could an incumbent credibly claim this same seed? If yes, it's not narrow enough yet.

### Step 3: Design the Category
Draft the following concrete assets:
- **Category name** — short, memorable, ideally a new noun phrase (e.g., "AI avatar platform for non-creators" rather than "AI video tool")
- **Point of view** — a one-sentence belief statement about why the old category fails this audience
- **New buying criteria** — 3-4 evaluation questions that favor the user's product by construction (not by spin)
- **Lightning-strike proof point** — one vivid, specific piece of evidence (case study, number, demo) that makes the category real instantly

### Step 4: Build Supporting Content Assets
Turn the category design into usable materials:
- A short narrative (origin story: "we tried the old way, it failed because X, so we built Y")
- 3-5 "reframe" statements that translate old-category language into new-category language (old: "best editing software" → new: "fastest way to launch without editing")
- Content angle ideas that only make sense inside the new category (comparison posts, "why X category is broken" pieces)
- Objection handling for "isn't this just [old category] with a new name?"

### Step 5: Self-Validate
Before delivering, check:
- Is the category genuinely different, or is it a rebrand with no real buying-criteria shift? (If incumbents could win under the new criteria too, redesign.)
- Is the audience narrow enough to be ownable but large enough to be worth pursuing?
- Does the proof point actually exist, or is it aspirational? Flag if unproven.

## Output Format

```
## Category Design: <Category Name>

### The Old Game (what you're escaping)
- Current category: ...
- Why you lose here: ...

### The New Category
- Name: ...
- Point of view: "..."
- New buying criteria:
  1. ...
  2. ...
  3. ...
- Lightning-strike proof point: ...

### Content Assets
- Origin narrative: ...
- Reframe statements (old → new):
  | Old language | New language |
  |---|---|
- Content angle ideas: ...
- Objection handling: "Isn't this just [old category]?" → ...

### Validation Notes
- Ownability check: ...
- Risks / open questions: ...
```

## Error Handling

- **No real differentiator exists yet:** Don't force a category name onto a commodity product. Recommend the user first run `purple-cow-audit` or product development work before category design.
- **Audience too broad to narrow:** If every attempt at Step 2 keeps landing back on the whole market, ask clarifying questions about who the product has worked best for so far (use real case studies/testimonials as signal).
- **Category name collides with an existing term:** Search whether the proposed name is already used by a competitor or another industry; if so, iterate on naming before finalizing.
- **User just wants a tagline, not a strategy:** Clarify that category design is a positioning shift affecting content, offer, and messaging — not just a slogan — and scope expectations accordingly.

## Examples

**Example 1:** "I sell an AI writing tool but there are 50 competitors doing the same thing" → Map the "AI writing tool" category, find a seed like "the only AI writer built for non-native English freelancers," and produce a full category design with reframed buying criteria.

**Example 2:** "How do I stop being compared on price against Amazon affiliate roundups?" → Design a narrower category (e.g., "curated gear for van-life beginners" instead of "budget camping gear") where price isn't the primary criterion.

**Example 3:** "I have a testimonial that says our onboarding is 10x faster than competitors" → Use that as the lightning-strike proof point and build the category design around "speed to first result" as the new buying criterion.

## Suggested Next Skills

- `grand-slam-offer` (S4) — turn the new category's buying criteria into an irresistible offer structure
- `affiliate-blog-builder` (S3) — build content architecture around the new category's language
- `comparison-post-writer` (S3) — write "why [new category] beats [old category]" comparison content
- `funnel-planner` (S4) — design a funnel that walks cold traffic through the reframe before the pitch

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
