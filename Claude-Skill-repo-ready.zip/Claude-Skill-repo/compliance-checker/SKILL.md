---
name: compliance-checker
description: Audit affiliate/marketing content (blog posts, social posts, video scripts, landing pages, emails) for FTC-style disclosure compliance, checking placement, clarity, and platform-specific requirements before publishing. Use before publishing any affiliate content, or when the user asks if their content is compliant.
stage: S8 Meta
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Compliance Checker

Audit affiliate and marketing content for disclosure compliance before it goes
live. Undisclosed affiliate relationships create real legal and platform risk —
this skill catches the common mistakes (missing disclosure, disclosure too
subtle/buried, wrong placement for the platform) before publishing, not after.

**Scope note:** this skill provides general compliance guidance based on common
FTC-style disclosure norms and platform policies. It is not legal advice — for
jurisdiction-specific or high-stakes situations, consult a qualified attorney.

## When to Use

- Before publishing any affiliate content (blog, social, video, email, landing page)
- User asks "is this compliant?" or "do I need a disclosure here?"
- User is setting up a new content channel and wants disclosure defaults in place
- User has existing published content and wants a compliance audit

## Input Schema

```yaml
content: string               # REQUIRED — the content to audit, or a URL if already published
content_type: string           # REQUIRED — "blog" | "social-post" | "video-script" | "landing-page" | "email"
platform: string               # OPTIONAL — "tiktok" | "instagram" | "youtube" | "twitter" | "linkedin" | "blog" | "email"
jurisdiction: string           # OPTIONAL, default: "US-FTC-general" — general norms only, not legal advice
```

## Workflow

### Step 1: Check for Disclosure Presence

Scan the content for any disclosure language: "affiliate", "commission", "#ad",
"#sponsored", "partner link", "I earn from qualifying purchases", etc. If none
found → automatic fail.

### Step 2: Check Disclosure Placement (Platform-Specific)

| Content Type | Where Disclosure Must Appear |
|---|---|
| Blog post | Near the top, before the first affiliate link — not only in a footer |
| Short-form video (TikTok/Reels/Shorts) | Text overlay during or before the CTA segment; verbal is best practice |
| YouTube video | In the video itself (verbal or on-screen) AND in the description |
| Social post (static) | Within the visible text, not hidden after a "show more" cutoff or buried in hashtags |
| Email | Clear statement near the top or near the relevant link, not only in a footer |
| Landing page | Visible without scrolling if possible, or clearly linked near the top |

### Step 3: Check Disclosure Clarity

- Is it in plain language a general audience would understand? ("#ad" and
  "affiliate link" pass; obscure abbreviations or legal jargon alone do not)
- Is it unmistakable, not blended into unrelated hashtags/text where it could be missed?
- Does it appear BEFORE the reader/viewer needs to act on the recommendation, not after?

### Step 4: Check for Deceptive Claims

- No income claims without a substantiated basis ("I made $10k this month" needs
  real substantiation or should be reframed/removed)
- No fake urgency/scarcity ("only 2 spots left" when untrue)
- No exaggerated results presented as typical without a disclaimer
- Reviews include genuine limitations, not only positives (also a trust signal, see `comparison-post-writer` / `affiliate-blog-builder`)

### Step 5: Score and Report

Assign a status per check: **Pass / Needs Fix / Fail**, with the specific fix required for each issue found.

### Step 6: Provide Corrected Version

Don't just flag issues — provide the corrected disclosure language and placement, ready to paste in.

### Step 7: Self-Validation

- [ ] Every disclosure recommendation is platform-appropriate, not generic
- [ ] Corrected version is provided, not just a list of problems
- [ ] Legal-advice disclaimer is included in the response
- [ ] No claim is made that this constitutes formal legal sign-off

## Output Format

```
## Compliance Audit: [Content Type / Platform]

| Check | Status | Issue | Fix |
|---|---|---|---|
| Disclosure present | ✅/⚠️/❌ | | |
| Disclosure placement | ✅/⚠️/❌ | | |
| Disclosure clarity | ✅/⚠️/❌ | | |
| Deceptive claims | ✅/⚠️/❌ | | |

**Overall:** [Pass / Needs Fixes Before Publishing / Fail]

**Corrected disclosure text to use:**
"[ready-to-paste disclosure line, matched to the platform]"

**Corrected placement:** [where exactly to put it]

*This is general guidance based on common disclosure norms, not legal advice.
For jurisdiction-specific requirements or high-stakes content, consult a
qualified attorney.*
```

## Error Handling

- **No content type specified**: Ask, since placement rules differ significantly by format.
- **Content is fine as-is**: Say so clearly — don't manufacture issues to seem thorough.
- **Ambiguous jurisdiction**: Default to general US-FTC-style norms and flag that other jurisdictions (EU, UK ASA, Vietnam's advertising law) may have additional requirements worth checking separately.
- **Content includes income/earnings claims**: Flag as higher-risk regardless of other compliance status; recommend removing or substantiating with real, verifiable data.

## Examples

**Example 1:** "Check if my TikTok script has proper disclosure" → checks for #ad/affiliate text overlay near the CTA segment, flags if disclosure is only in the caption (needs to be in-video too per platform norms), provides corrected overlay text.

**Example 2:** "Audit this blog post before I publish" → checks disclosure is near the top (not just footer), scans for income claims, confirms honest cons are present, gives a Pass/Needs Fix per section.

**Example 3:** "I said 'this made me $5k last month' in my post" → flags as a claim needing substantiation or removal; suggests reframing around a specific, verifiable metric instead (e.g., "I use this tool daily for X") or clearly labeling it as a personal, non-typical result.

## Suggested Next Skills

- `affiliate-blog-builder` / `tiktok-script-writer` (upstream) — build disclosure in from the start next time
- `funnel-planner` (S8) — add a compliance-check step at every publish point in the roadmap

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill. General compliance guidance only — not a substitute for legal advice.
