---
name: value-ladder-architect
description: Maps the full free-to-premium customer ascension journey for an affiliate promotion — free content, a low-cost tripwire, the core affiliate product, and an upsell — specifying which page or email builds each rung and how visitors move between them. Use when the user wants to plan an entire funnel rather than one page, asks about upsells/downsells/tripwires, or wants to maximize lifetime value instead of a single commission.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Value Ladder Architect

Designs the entire ascension path a prospect walks — free → tripwire → core →
upsell — where every rung delivers standalone value on its own while naturally
pulling the visitor toward the next one. The value ladder isn't abstract
strategy; it's literally the sequence of pages and emails to build: squeeze
page → bridge/tripwire page → sales page → upsell page.

## When to Use

- User wants to plan a whole customer journey, not just a single page
- User asks about upsells, downsells, tripwires, or overall funnel stages
- User wants to maximize lifetime value from an affiliate relationship, not just the first commission
- User says "value ladder," "customer journey," "ascension," or "funnel architecture"
- The product has multiple pricing tiers (free / pro / enterprise) worth sequencing

## Input Schema

```
{
  product: {
    name: string,
    pricing_tiers: [{ name, price, features: string[] }],
    reward_value: string,
    reward_type: string,   # recurring | one-time | tiered
    url: string
  },
  your_assets: string[],   # OPTIONAL — blog, email list, YouTube, templates; default ["blog"]
  goal: string             # OPTIONAL — first_commission | maximize_ltv | build_list; default first_commission
}
```

## Workflow

### Step 1: Gather Context
Map the product's pricing tiers and commission structure, inventory the user's
existing assets (blog, list, following), and decide whether the goal is a
simple ladder (fastest path to first commission) or a fuller ladder (maximize
lifetime value).

### Step 2: Design the Rungs

**Rung 0 — Free (Awareness):** a blog post, social content, or free tool that
builds trust and captures an email. Goal: demonstrate expertise, get the opt-in.

**Rung 1 — Tripwire ($1-$49, impulse buy):** a low-cost asset the user creates
themselves (template pack, mini-course, audit). Goal: convert reader to buyer
and confirm the email if not already captured.

**Rung 2 — Core (the affiliate product):** the product at its most popular
tier — this is where the primary commission is earned. Goal: solve the
visitor's main problem.

**Rung 3 — Upsell:** a premium tier of the same product, or a complementary
affiliate product. Goal: maximize lifetime value and larger/recurring
commissions once trust is established.

### Step 3: Map the Page Sequence
For each rung, specify: page type (blog post, squeeze page, bridge page,
landing page, or email), likely traffic source (organic, social, email, paid),
which skill builds it, the conversion mechanism (CTA, opt-in, checkout), and a
rough conversion-rate benchmark to set expectations.

### Step 4: Define Transition Triggers
State explicitly what moves someone from one rung to the next: Rung 0→1 —
downloaded the lead magnet, gets an email sequence pitching the tripwire; Rung
1→2 — purchased the tripwire, sees an immediate upsell page or a follow-up
sequence; Rung 2→3 — used the core product for some period, receives an email
about premium features.

### Step 5: Output the Full Ladder with a Build Order
Present the whole ladder plus a realistic implementation sequence — don't
recommend building all four rungs at once.

### Step 6: Self-Check
- Every rung delivers real standalone value, not just a teaser for the next one
- Transitions feel natural rather than forced
- The affiliate product sits at Rung 2 (core), not buried as an afterthought upsell
- Free content (Rung 0) is genuinely useful on its own
- Build order is realistic — starts simple, adds rungs over time
- Disclosure present at every rung that includes an affiliate link

## Output Format

```
## Value Ladder: [Product Name]

### Ladder Overview
[simple ASCII diagram: Free → Tripwire → Core → Upsell]

### Rung 0: FREE — [Offer]
- What: ... | Where: ... | Traffic: ... | Build with: [skill]
- → Next: [transition trigger] | Benchmark: [expected conversion %]

### Rung 1: TRIPWIRE — [Offer] ($XX)
[same structure]

### Rung 2: CORE — [Product] ($XX/mo)
[same structure]

### Rung 3: UPSELL — [Offer] ($XX/mo)
[same structure]

### Implementation Roadmap
1. Week 1: Build Rung 2 (core landing page) — start earning immediately
2. Week 2: Build Rung 0 (content driving traffic)
3. Week 3: Build Rung 1 (tripwire, capture emails)
4. Week 4+: Build Rung 3 (upsell for max LTV)

### Email Sequences
- Rung 0→1: [N emails / N days] — [theme]
- Rung 1→2: [N emails / N days] — [theme]
- Rung 2→3: [N emails / N days] — [theme]
```

## Error Handling

- **No product given:** ask for one, or point to a program-research step first.
- **Product has only one pricing tier:** build Rungs 0-2 as normal; suggest a complementary (non-competing) product for Rung 3 instead of inventing a tier that doesn't exist.
- **User has no existing assets (no blog/list):** recommend starting with Rung 2 only — a direct landing page — and building Rungs 0/1 later. "Start earning first, then build the ladder."
- **Product is one-time payment, not recurring:** shift Rung 3 toward complementary recurring products to build ongoing income instead of relying on the same one-time product.

## Examples

**Example 1:** "Design a value ladder for [an AI video tool]" → free blog series on AI video for business → $7 script-template tripwire → the tool's Pro tier as core → an enterprise tier plus a paid implementation package as upsell.

**Example 2:** "I have a blog and an email list, design my funnel for [an SEO tool]" → SEO tutorial content as Rung 0 → a paid audit-template kit as Rung 1 → the tool's Pro tier as Rung 2 → the Business tier plus monthly coaching as Rung 3.

**Example 3:** "Map my funnel" after a prior offer/bonus step → reuse the existing offer and bonuses, slot bonuses in as the tripwire, the core offer as Rung 2, and design a complementary product for Rung 3.

## Suggested Next Skills

- `squeeze-page-builder` (S4) — build the Rung 0/1 page
- `landing-page-creator` (S4) — build the Rung 2/3 page
- `email-drip-sequence` (S5) — write the transition sequences between rungs
- `bonus-stack-builder` (S4) — source bonuses for the tripwire and core rungs

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
