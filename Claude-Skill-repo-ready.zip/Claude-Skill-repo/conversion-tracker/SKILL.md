---
name: conversion-tracker
description: Design a UTM tagging scheme and lightweight tracking setup so every piece of content and traffic source can be measured for clicks and conversions, then read the resulting data to identify what's actually working. Use when the user wants to know which content or channel drives results, or is about to launch content without a way to measure it.
stage: S6 Analytics
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Conversion Tracker

Design a consistent UTM tagging scheme and lightweight tracking setup so every
piece of content, every channel, and every campaign can be measured individually.
Most affiliates and marketers can't answer "what's actually working?" because
they never tagged their links consistently — this skill fixes that before content
goes out, and reads the results once data exists.

## When to Use

- User is about to publish content/links without a way to measure performance
- User wants to know which platform, content piece, or campaign drives the most conversions
- User has scattered links with no consistent naming and wants to clean it up
- User has traffic/click data and wants it interpreted into a decision
- User wants to set up UTM parameters correctly for the first time

## Input Schema

```yaml
channels: string[]            # OPTIONAL — e.g., ["tiktok", "linkedin", "blog", "email", "twitter"]
products: string[]            # OPTIONAL — products/programs being promoted
existing_data: object          # OPTIONAL — raw click/conversion data to analyze, if available
naming_convention: string      # OPTIONAL — existing convention to match, if any
```

## Workflow

### Step 1: Design the UTM Naming Convention

Use a consistent, predictable structure:

```
utm_source   = platform (tiktok, linkedin, twitter, blog, email, youtube)
utm_medium   = content type (video, post, article, newsletter, bio-link)
utm_campaign = specific piece or series (product-name-launch, comparison-post-jan)
utm_content  = variant identifier, for A/B testing (hook-a, hook-b, version-1)
```

Example: `https://product.com/?utm_source=tiktok&utm_medium=video&utm_campaign=heygen-review&utm_content=demo-first-hook`

### Step 2: Generate Tagged Links

For each planned piece of content, generate the fully tagged URL using the
convention above. Keep a running link log (content piece → tagged URL → date
published) so results can be traced back later.

### Step 3: Set Up Lightweight Measurement

Recommend the simplest tool that fits the user's stack:
- **No tooling yet**: a bio-link tool with click tracking (e.g., Beacons, Linktree Pro), or a self-hosted bio-link page from `bio-link-deployer` with basic analytics
- **Has a landing page**: add a simple analytics snippet (Plausible, Fathom, or GA4) and track UTM parameters as custom dimensions
- **Has affiliate network dashboards**: cross-reference network-side conversion data against the UTM log by campaign name

### Step 4: Read the Data (once available)

When `existing_data` is provided, analyze:
- **Click-through rate by channel** — which platform sends the most clicks?
- **Conversion rate by content type** — does video outperform static posts?
- **Best-performing individual pieces** — which specific post/video converts best, and what does it have in common with other top performers (hook style, format, topic)?
- **Underperformers** — what's not working, and is it a traffic problem or a conversion problem?

### Step 5: Turn Data Into Decisions

Don't just report numbers — recommend action:
- "Channel X converts 3x better than Y — shift more content effort there"
- "Video content outperforms static posts 2:1 — prioritize video format"
- "This specific hook style appears in your top 3 performers — reuse it"

### Step 6: Self-Validation

- [ ] UTM convention is consistent and documented (not ad-hoc per link)
- [ ] Every generated link is copy-paste ready
- [ ] Data interpretation includes a specific, actionable recommendation — not just a restated number
- [ ] Sample size caveats are noted if data volume is low (avoid over-indexing on 1-2 data points)

## Output Format

**If setting up tracking:**
```
## UTM Tracking Setup: [Campaign/Product]

**Naming convention:**
utm_source: [options]
utm_medium: [options]
utm_campaign: [convention]
utm_content: [convention]

**Tagged links:**
| Content Piece | Channel | Tagged URL |
|---|---|---|

**Recommended tracking tool:** [tool] — [why]
```

**If analyzing data:**
```
## Performance Analysis: [Period/Campaign]

| Channel | Clicks | Conversions | Conv. Rate |
|---|---|---|---|

**What's working:** [specific finding]
**What's not:** [specific finding]
**Recommendation:** [specific next action]
```

## Error Handling

- **No channels specified**: Default to the most common set (blog, one social platform, email) and note it's adjustable.
- **Data too sparse to draw conclusions**: Say so explicitly rather than forcing a false pattern; recommend a minimum sample size before deciding.
- **Inconsistent existing naming**: Recommend a clean migration point going forward rather than trying to retrofit old links.
- **No analytics tool at all**: Start with the simplest option (bio-link tool with built-in click counts) rather than recommending a complex stack for someone just starting out.

## Examples

**Example 1:** "I'm about to post on TikTok, LinkedIn, and my blog — help me track this properly" → design UTM convention, generate 3 tagged links, recommend a bio-link tool with click tracking.

**Example 2:** "Here's my click data from last month, what's working?" → analyze channel/content-type breakdown, identify the top-performing piece and its common traits, give a specific recommendation to double down.

**Example 3:** "My links are a mess, no consistent naming" → propose a clean UTM convention going forward, don't try to fix historical data, explain the trade-off.

## Suggested Next Skills

- `bio-link-deployer` / `github-pages-deployer` (S5) — host the tagged links
- `ab-test-generator` (S6) — test specific variants against each other
- `performance-report` (S6) — turn ongoing data into a recurring report
- `content-repurposer` (S7) — double down on what the data shows is working

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
