---
name: infographic-generator
description: Generate a complete branded infographic specification — layout, copy, data, and color scheme — from any content, stat, or comparison, ready to render as HTML/CSS or in a design tool. Use when the user wants a social media graphic, stat card, comparison chart, checklist visual, or infographic to pair with a post or blog article, since image posts consistently outperform text-only posts.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Infographic Generator

Turns content into a fully-specified visual asset without requiring design
skill: pick the right infographic type for the data, lay it out for the target
platform's dimensions, write every word of copy, and choose a color scheme —
output as a structured spec, self-contained HTML, or both.

## When to Use

- Right after writing a social post, to give it an accompanying visual
- When a research brief or blog post surfaces stats worth visualizing
- When comparing two or more products/features side by side
- When a listicle or step-by-step process would land better as a visual
- Anytime a post would benefit from an image (image posts get markedly more engagement than text-only)

## Input Schema

```
{
  content: string                # REQUIRED — text, data, or article to visualize
  infographic_type: string       # optional, auto-detected:
                                  # stat_highlight | comparison | process_flow |
                                  # checklist | timeline | data_chart | quote_card | feature_grid
  platform: "linkedin" | "instagram" | "twitter" | "facebook" | "blog"  # default: linkedin
  brand: { name, primary_color, secondary_color, accent_color, font_style, logo_text }  # optional
  output_format: "spec" | "html" | "both"  # default: spec
}
```

## Workflow

### Step 1: Detect the Right Type

| Content pattern | Type |
|---|---|
| 1-3 prominent numbers/stats | `stat_highlight` |
| "vs" / comparison data | `comparison` |
| Numbered steps or a process | `process_flow` |
| A list of 3-10 items | `checklist` or `feature_grid` |
| Dates or chronological events | `timeline` |
| A notable quote | `quote_card` |
| Percentages or proportions | `data_chart` |

Use the user-specified type if given; otherwise pick from the table above.

### Step 2: Extract the Visual Data
Pull out only what will appear on the graphic — e.g. for a comparison, each
product's name plus 3-5 feature/value pairs with a `highlight` flag marking
the winning value per row; for a stat highlight, 1-3 number+label+context
triples; for a process flow, each step's number, title, short description,
and an icon.

### Step 3: Set Dimensions for the Platform

| Platform | Size | Aspect |
|---|---|---|
| LinkedIn | 1080×1350 | 4:5 portrait |
| Instagram | 1080×1080 | 1:1 square |
| Twitter | 1200×675 | 16:9 landscape |
| Facebook | 1200×630 | ~2:1 |
| Blog | 1200×800 | 3:2 |

Layout skeleton for every type: header (10-15% height, title), body
(70-80%, type-specific content), footer (10%, brand/CTA/source).

### Step 4: Pick a Color Scheme
Use brand colors if supplied. Otherwise choose from a default palette set
(dark modern, light clean, warm bold, dark gradient) matched to the platform
— dark/light professional tones for LinkedIn, higher-contrast/gradient for
Twitter, anything for Instagram.

### Step 5: Write All the Copy
Headline (3-8 words, a bold claim or a specific number), optional
subheadline, body item labels, one CTA line ("Link in bio", "See comments for
link"), footer/brand handle, and a source attribution line. Total on-graphic
word count should stay at or under 50 — numbers beat adjectives every time.

### Step 6: Produce the Output
- **Spec (default):** structured data any renderer can consume — type,
  platform, dimensions, colors, layout regions, type-specific data, and copy.
- **HTML (if requested):** self-contained inline-CSS HTML at exact pixel
  dimensions, screenshot-able or renderable server-side (e.g. with Satori).

### Step 7: Self-Validate
- [ ] ≤50 total words on the graphic
- [ ] Text legible at roughly 50% zoom
- [ ] Color contrast meets WCAG AA (4.5:1)
- [ ] Data is accurate and attributed
- [ ] Layout has intentional whitespace, doesn't feel cramped
- [ ] Dimensions match the declared platform

## Output Format

```
## Infographic: [Headline]

### Spec
Type: [...]   Platform: [...] — WxH   Colors: [palette + hex values]

### Preview (text mock-up)
[ASCII-box representation of the layout]

### Data
[structured spec, YAML or JSON]

### HTML (if requested)
[self-contained HTML/CSS block]

### Next Steps
- Pair with a post from `viral-post-writer`
- Generate a variant for another platform
```

## Error Handling

- **No extractable data in the content:** fall back to a `quote_card` or `checklist` type and say so explicitly.
- **Too much data for one graphic:** keep only the top 3-5 most impactful points; suggest splitting into multiple infographics.
- **No brand colors supplied:** use a sensible default palette and note it, so the user knows to lock in brand colors later.
- **HTML spec getting too complex:** simplify — an infographic that needs a legend to explain itself has already failed.

## Examples

**Example 1:** "Make an infographic comparing HeyGen vs Synthesia for LinkedIn" → `comparison` type, 1080×1350, extracts commission/cookie/rating/price per product, highlights the winning values, dark modern palette.

**Example 2:** "Create a stat card from my research brief's key numbers" → `stat_highlight`, three large numbers with labels and context (e.g. "$60M raised", "40K businesses", "30% commission").

**Example 3:** "Visualize the affiliate funnel as an infographic" → `process_flow`, blog dimensions, horizontal step sequence with icons and one-line descriptions per step.

## Suggested Next Skills

- `viral-post-writer` (S2) — write the post the infographic will accompany
- `content-pillar-atomizer` (S2) — generate several infographics as part of a larger content batch
- `affiliate-blog-builder` (S3) — use the infographic as a blog post's featured image

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
