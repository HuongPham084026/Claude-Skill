---
name: email-drip-sequence
description: Write a 5-7 email drip sequence that nurtures a subscriber list from cold to buyer for a specific affiliate product, following a value-first Welcome-Value-Soft Sell-Hard Sell-Objection-Follow Up arc. Use when the user has an email list and wants to promote a product, just launched a lead magnet, or asks for a "drip campaign", "email funnel", or "nurture sequence".
stage: S5 Distribution
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Email Drip Sequence

Writes a complete multi-email nurture sequence that turns a fresh
subscriber into a buyer of a specific affiliate product. Email remains one
of the highest-ROI channels available to affiliates, but only when value is
delivered before the pitch — this skill enforces that ordering so
subscribers stay engaged instead of unsubscribing after email one.

## When to Use

- User has an email list (or just built a lead magnet/opt-in) and wants to monetize it
- User wants to promote a specific affiliate product via email automation (ConvertKit, Beehiiv, Mailchimp, ActiveCampaign, etc.)
- User asks for a "welcome sequence", "drip campaign", "email funnel", or "nurture series"
- A product was already identified earlier in the conversation and the user now wants emails written for it

## Input Schema

```
{
  product: {
    name: string, affiliate_url: string,          # REQUIRED
    category: string, price: string,               # optional
    reward_value: string,                           # optional, e.g. "30% recurring"
    key_benefits: string[]                          # optional, inferred if omitted
  },
  audience: {
    description: string,       # REQUIRED, e.g. "content creators", "SaaS founders"
    pain_point: string,        # optional
    awareness_level: "cold" | "warm" | "hot"   # optional, default "cold"
  },
  sequence: {
    length: 5 | 6 | 7,                     # optional, default 7
    send_days: number[],                    # optional, default [0,1,3,5,7,10,14]
    sender_name: string, tone: string,      # optional, tone default "conversational"
    lead_magnet: string                     # optional
  }
}
```

If a product was already identified by an earlier research step in this
conversation, reuse its name, affiliate URL, benefits, and commission rate
rather than asking the user to restate them.

## Workflow

### Step 1: Gather Inputs
Confirm the product, its affiliate link, and who the audience is. If key
benefits weren't supplied, infer the top 3 from what's known about the
product and state the assumption so the user can correct it. Missing
essentials to ask for: product + affiliate link, audience description.

### Step 2: Map the Sequence Arc
Assign each email a day and purpose. Drop from the end of this table to
shorten to 5 or 6 emails:

| # | Day | Type | Purpose |
|---|---|---|---|
| 1 | 0 | Welcome | Deliver the lead magnet, set expectations, build trust — no pitch |
| 2 | 1 | Value | Teach something genuinely useful, zero sell |
| 3 | 3 | Value + soft mention | More value, product mentioned casually in context |
| 4 | 5 | Soft sell | Properly introduce the product, benefit-led |
| 5 | 7 | Hard sell | Clear CTA, urgency/deadline if one exists |
| 6 | 10 | Objection handling | Answer the top 3 objections, add social proof |
| 7 | 14 | Follow-up | Short "did you see this?" last-chance re-engagement |

### Step 3: Write Each Email
Every email needs four parts:
- **Subject line** — 40-60 characters, curiosity or benefit-driven, avoid spam-trigger words ("free", "guaranteed", "act now")
- **Preview text** — 80-100 characters extending the subject
- **Body** — short paragraphs (2-3 sentences), one idea each, "you"-focused, conversational opener, single CTA. Target length grows through the sequence: ~200-300 words for emails 1-2, ~250-350 for 3-4, ~300-400 for the hard-sell email, tapering back down for the follow-up (~150-200 words)
- **CTA** — email 1 links to the lead magnet (not the affiliate link); email 2's CTA is engagement (reply/read); email 3 softly surfaces the affiliate link; emails 4-7 use a direct action verb CTA ("Try X Free", "Get 20% Off")

### Step 4: Add Compliance Disclosure
Every email containing the affiliate link needs a one-line disclosure placed
right next to the link, plus a plain-text version in the footer for clients
that strip HTML:

> *Affiliate disclosure: I may earn a commission if you purchase through my link, at no extra cost to you.*

### Step 5: Self-Check Before Delivering
- All 5-7 emails present with subject, preview, body, and CTA
- Disclosure present on every email carrying the affiliate link
- Send-day spacing is realistic (not everything on day 0)
- Value-only emails outnumber pitch emails across the sequence
- CTA links point at the correct affiliate URL

## Output Format

```
--- EMAIL <N> — Day <X> — <Type> ---
Subject: <subject line>
Preview: <preview text>

<body copy>

<CTA>

<sign-off>
---
```

After the last email, append setup guidance:

```
--- SETUP ---
Recommended ESP: ConvertKit / Beehiiv / ActiveCampaign
Trigger: new subscriber joins the list / completes opt-in
Delays: fire each email X days after the previous one per the send-day plan
A/B test first: the Email 5 (hard sell) subject line — highest-leverage test
Tag: apply an "affiliate-<product>" tag to track clicks in the ESP
---
```

## Error Handling

- **No affiliate URL yet:** write the sequence with a `[YOUR_AFFILIATE_LINK]` placeholder and note it needs to be swapped in before sending.
- **Unknown/unfamiliar product:** ask the user for 2-3 key benefits rather than guessing, or research it if tools are available.
- **Vague audience ("everyone"):** default to "online business owners and marketers" and flag that more specific targeting language will convert better.
- **No lead magnet described:** email 1 becomes a general welcome + "what to expect" instead of a lead-magnet delivery email.
- **User asks for 3 emails or fewer:** explain that's too short to build trust before pitching, and recommend 5 as the floor.

## Examples

**Example 1:** "Write an email sequence for HeyGen targeting YouTube creators who downloaded my AI tools checklist" → 7-email sequence, day 0 delivers the checklist, emails 2-3 teach AI video tips, emails 4-7 pitch HeyGen with creator-specific angles.

**Example 2:** (after an earlier step identified Semrush at 30% recurring commission for SEO consultants) "Now write an email sequence for this" → reuses the product data already in context, writes the full 7-email arc for that audience without re-asking.

**Example 3:** "Write me a drip sequence for my Notion template affiliate program" (no audience given) → asks for the affiliate URL and audience, defaults to a shorter 5-email sequence given the simpler buying journey.

## Suggested Next Skills

- `bio-link-deployer` (S5) — give subscribers a hub link to click through from emails
- `social-media-scheduler` (S5) — drive new sign-ups into this sequence
- `conversion-tracker` (S6) — measure open, click, and conversion rates per email

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
