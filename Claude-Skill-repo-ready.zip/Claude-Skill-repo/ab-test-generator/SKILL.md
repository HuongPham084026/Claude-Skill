---
name: ab-test-generator
description: Generate A/B test variants for affiliate content — headlines, CTAs, landing page sections, email subject lines, and social hooks — each paired with a copywriting-grounded hypothesis and a test plan (sample size, duration, winner criteria). Use when the user wants to improve conversion rates, asks to "test my headline/CTA", or wants alternatives to compare before committing budget or traffic.
stage: S6 Analytics
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# A/B Test Generator

Turn one piece of affiliate copy into several theory-driven variants — plus the
test plan needed to actually find a winner. Small wording changes in headlines
and CTAs routinely swing conversion rates 20-50%, so this skill replaces
guesswork with variants grounded in named copywriting principles.

## When to Use

- User wants to lift conversion on existing content (headline, CTA, email subject, social hook)
- User pastes a line of copy and asks for "alternatives" or "A/B test ideas"
- A landing page section isn't converting and needs testable variations
- Chaining from earlier content skills — take any generated headline/CTA and produce test variants for it

## Input Schema

```
{
  original: string          # REQUIRED - the copy to test
  content_type: string      # REQUIRED - "headline" | "cta" | "landing_section" | "email_subject" | "social_hook"
  goal: string               # optional - "clicks" | "signups" | "purchases" (default: clicks)
  num_variants: number       # optional - 2-5, default 3
  audience: string           # optional - who sees this copy
  product: string            # optional - product being promoted
}
```

## Workflow

### Step 1: Deconstruct the Original
Identify: emotional angle (curiosity, fear, desire, urgency), specificity level, structural form (question / statement / command / stat), and which classic framework it follows (PAS, AIDA, 4U, BAB).

### Step 2: Pick Testable Levers
Choose which dimensions to vary across variants — don't just swap synonyms:
- Emotional angle (curiosity → urgency)
- Specificity (add a number, name a result)
- Structure (question vs. declarative vs. command)
- Length (trim vs. expand)
- Social proof (add/remove a proof point)
- Power words (upgrade weak verbs/adjectives)

### Step 3: Generate Variants
Produce `num_variants` alternatives, each anchored to a *different* lever from Step 2 so they're genuinely distinct approaches, not cosmetic edits. Every variant must preserve the core product reference and any FTC affiliate disclosure present in the original.

### Step 4: Write a Hypothesis Per Variant
For each: what changed, which copywriting principle backs it, and the expected behavioral effect (e.g., "questions create an open loop → higher CTR").

### Step 5: Build the Test Plan
- Minimum sample size: ~100 impressions/variant for social, ~500 for landing pages
- Duration: 7-14 days minimum (avoid day-of-week bias)
- Primary metric: CTR, conversion rate, or revenue per visitor depending on `goal`
- Winner criteria: 95% statistical significance, or a defined practical-significance threshold if traffic is low

### Step 6: Self-Check Before Delivering
- Variants are structurally distinct, not word swaps
- Every hypothesis names a concrete copywriting principle
- Sample size and duration are realistic for the stated traffic
- Winner criteria is explicit

## Output Format

```
## A/B Test: <content_type>

**Original:** <original copy>

### Variants
| Label | Copy | What Changed | Framework/Principle | Hypothesis |
|---|---|---|---|---|
| Variant A | ... | ... | ... | ... |
| Variant B | ... | ... | ... | ... |
| Variant C | ... | ... | ... | ... |

### Test Plan
- Sample size: <n> per variant
- Duration: <n> days
- Primary metric: <metric>
- Winner criteria: <threshold>

### Quick Win
<if one variant is clearly favored on copywriting grounds, call it out>
```

## Error Handling

- **Original is only 1-2 words:** ask for the full headline, CTA, or subject line — too little context to vary meaningfully.
- **Content type not specified:** ask whether it's a headline, CTA button, email subject, or social hook — format changes what levers apply.
- **More than 5 variants requested:** cap at 5 and explain that more variants split traffic too thin to reach significance.
- **No traffic/audience size given:** still produce the test plan, but flag that sample-size targets are generic and should be checked against actual traffic volume.
- **Original contains an FTC disclosure:** make sure every variant retains an equivalent disclosure — don't let a "shorter is better" variant strip compliance language.

## Examples

**Example 1:** "Test this headline: 'HeyGen Review: Is It Worth It in 2026?'" → Produces three variants (personal-experience angle, direct comparison angle, quantified-result angle), each with a hypothesis, plus a 7-14 day test plan tracking CTR.

**Example 2:** "Optimize this CTA: 'Start Free Trial'" → Variants reduce friction ("No Card Required"), emphasize outcome ("Create Your First Video in 2 Minutes"), and shorten for urgency ("Get Started Free →"), with a 500-click-per-variant test plan.

**Example 3:** "Test this email subject: 'Check out Semrush — it's great for SEO'" → Flags the vagueness, then generates social-proof, FOMO, and specific-result variants while preserving the affiliate disclosure.

## Suggested Next Skills

- `performance-report` (S6 Analytics) — once the test has run, feed the results in to compare against portfolio-wide KPIs
- `seo-audit` (S6 Analytics) — if the tested copy lives on a landing page, audit the surrounding page for on-page SEO issues
- `internal-linking-optimizer` (S6 Analytics) — for landing-page variants, make sure the page is well-linked internally so it accumulates enough traffic to reach significance

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
