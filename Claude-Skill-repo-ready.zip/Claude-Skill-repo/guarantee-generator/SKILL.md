---
name: guarantee-generator
description: Crafts a personal risk-reversal guarantee that sits on top of an affiliate product's own refund policy, addressing "what if it doesn't work for me" objections that stop buyers from clicking. Use when the user wants to raise affiliate conversion rates, asks what guarantee they can personally offer, or needs copy for a "money back," "results," or "risk-free" guarantee section on a landing page.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Guarantee Generator

Most affiliates rely entirely on the product's built-in refund policy and never
address the buyer's real fear: "what if this doesn't work for ME, specifically?"
This skill designs a personal guarantee — scoped to what the user can actually
deliver, not the product's features — that removes that last hesitation before
a click. Risk reversal is one of the most underused conversion levers in
affiliate marketing.

## When to Use

- User wants to raise conversion on an existing promotion without more traffic
- User asks "what guarantee can I offer as an affiliate?"
- User says "guarantee," "risk reversal," "risk-free," or "money back"
- Following a bonus-stack or offer-design step, to complete the full offer

## Input Schema

```
{
  product: { name, pricing, has_free_trial: boolean, has_guarantee: string },  # REQUIRED
  your_bonuses: string[],     # OPTIONAL — from a prior bonus-stack step
  your_capacity: string,      # OPTIONAL — low | medium | high (time available), default medium
  audience_fears: string[]    # OPTIONAL — inferred from product type if omitted
}
```

## Workflow

### Step 1: Gather Context
Confirm the product's existing refund/guarantee policy. Identify the top 3
fears or objections buyers in this category typically have (e.g. "will this
actually work for someone like me," "will I waste money on something I don't
finish setting up"). Assess how much personal time the user can realistically
commit to fulfilling a guarantee.

### Step 2: Design Three Guarantee Options at Increasing Commitment
- **A — Light Touch** (low capacity): scoped only to the user's own bonuses. e.g. "If my bonuses don't help you get started faster, I'll refund their value." Minimal risk to the user.
- **B — Support Guarantee** (medium capacity): scoped to the user's time plus bonuses. e.g. "If you're still stuck after 30 days, I'll personally help you implement for one hour." Moderate, capped risk.
- **C — Results Guarantee** (high capacity): scoped to a specific measurable outcome. e.g. "If you don't [specific result] in [timeframe], I'll [specific corrective action]." Higher risk, but the largest conversion lift.

### Step 3: Write the Copy for Each Option
For every option, produce: a bold, specific headline; body copy stating exactly
what's promised, under what conditions, and within what timeframe; a simple
claim process (how the buyer reaches the user to invoke it); and fair-but-firm
fine print (must have actually used the product, must claim within the stated
window).

### Step 4: Recommend One
Based on stated capacity and the product type, recommend a single option with
a one-paragraph rationale rather than leaving the user to choose blind.

### Step 5: Self-Check
- Specific, never a vague "satisfaction guaranteed"
- Scoped to what the user personally controls, not the product's own features
- Clear timeframe stated
- Claim process is simple and low-friction
- Realistically fulfillable by the user
- No guarantees phrased around income or specific financial results (regulatory risk)

## Output Format

```
## Your Guarantee: [Product Name]

### Product's Existing Guarantee
[what the product already offers on its own]

### Option A — Light Touch
"[headline]"
[body copy] · Timeframe: [X days] · Claim: [process] · Risk to you: minimal

### Option B — Support Guarantee
"[headline]"
[body copy] · Timeframe: [X days] · Claim: [process] · Risk to you: moderate

### Option C — Results Guarantee
"[headline]"
[body copy] · Timeframe: [X days] · Claim: [process] · Risk to you: higher

### Recommended: Option [X]
[why this fits the user's stated capacity and the product]

### Ready-to-Paste Copy
[final guarantee section copy for the landing page]
```

## Error Handling

- **No product given:** ask for it, or reuse one established earlier in the conversation.
- **User is uneasy about guaranteeing anything:** lead with Option A — the lowest-risk option still measurably outperforms no guarantee at all.
- **Product has no refund policy of its own:** flag this as a risk factor and scope the guarantee entirely around the user's own bonuses (Option A).
- **User wants to guarantee income or specific financial results:** flag the regulatory risk and reframe toward a process guarantee ("I guarantee I'll help you implement") rather than an outcome guarantee about money.

## Examples

**Example 1:** "Create a guarantee for my [AI video tool] promotion" → research the product's refund policy, surface fears like "will the output be good enough," propose three options from a bonus-value refund up to a personal screen-share session.

**Example 2:** "I don't have much time but want a guarantee for [an SEO tool]" → low capacity → recommend Option A scoped narrowly around a specific bonus (e.g. audit template).

**Example 3:** "Design a results guarantee" after a prior offer-design step → target the weakest point of the existing offer (e.g. time-to-first-result) and scope Option C around fixing exactly that.

## Suggested Next Skills

- `landing-page-creator` (S4) — insert the guarantee copy into the page's risk-reversal section
- `bonus-stack-builder` (S4) — bonuses often define what's realistic to scope a guarantee around
- `email-drip-sequence` (S5) — reintroduce the guarantee as a late-sequence objection-handler

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
