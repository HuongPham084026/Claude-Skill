---
name: squeeze-page-builder
description: Builds a single self-contained HTML email-capture (squeeze) page that trades a free lead magnet for the visitor's email, then redirects to an affiliate offer on submission. Use when the user wants to grow an email list while still driving affiliate clicks, or asks for an "opt-in page," "lead magnet page," "email capture page," or a two-step funnel that warms up traffic before the affiliate pitch.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Squeeze Page Builder

Produces a minimal, single-goal email-capture page: one free lead magnet, one
form, one outcome. After the visitor submits their email, the page redirects to
an affiliate offer, turning cold or paid traffic into both a list subscriber and
a warmed-up prospect in a single step. Output is one self-contained `.html`
file with no backend required to preview.

## When to Use

- User wants to build an email list while still promoting an affiliate product
- User has paid or cold traffic and needs to warm it up before an affiliate pitch
- User says "squeeze page," "opt-in page," "lead magnet," or "email capture page"
- User wants a two-step funnel: capture email → redirect to affiliate offer

## Input Schema

```
{
  lead_magnet: { title: string, type: string, description: string },  # REQUIRED
  affiliate_product: { name: string, url: string, reward_value: string, description: string },  # REQUIRED
  target_audience: string,   # REQUIRED
  niche: string,             # OPTIONAL — shapes copy tone and lead-magnet visual
  headline: string,          # OPTIONAL — override auto-generated headline
  color_scheme: string,      # OPTIONAL — default blue
  social_proof: { type: "count"|"testimonial", value: string, attribution: string },  # OPTIONAL
  esp: string                # OPTIONAL — mailchimp | convertkit | beehiiv | aweber | other
}
```

## Workflow

### Step 1: Nail Down the Lead Magnet and the Redirect
A squeeze page needs exactly two decisions: what free resource is offered, and
where the visitor lands after submitting. If missing, ask directly: "What free
resource will you offer?" and "What affiliate product should they see next?"

Match lead-magnet type to niche if the user is unsure:
| Niche | Good lead magnet |
|---|---|
| Marketing / SEO | Checklist, swipe file, templates |
| Finance | Calculator, cheat sheet, guide |
| Health / Fitness | Meal plan, workout plan, tracker |
| Software / SaaS | Quick-start guide, resource list |
| Business / Productivity | Templates, SOPs, spreadsheets |

Title formulas that convert: "[N]-Point Checklist: How to [Outcome]," "The Free
[Niche] Starter Kit," "Download: The Ultimate [Topic] Guide," "[Adjective]
Cheat Sheet: [X] Ways to [Outcome] in [Timeframe]."

### Step 2: Apply Squeeze-Page Conversion Principles
- **Clarity over cleverness** — visitor understands the offer in 3 seconds.
- **Above-fold completeness** — the form must be visible without scrolling, even on mobile.
- **Single goal, zero distractions** — no nav, no outbound links except the form.
- **One social proof number** beats generic trust badges ("Join 4,200+ readers").
- **Privacy micro-copy** at the form reduces friction: "No spam. Unsubscribe anytime."

Section order: header (logo only, no nav) → hero (headline, sub-headline, styled
CSS mockup of the lead magnet, single-field email form, privacy note) → "what's
inside" (3-5 bullets) → social proof → "who this is for" (3-4 bullets) → second
opt-in form lower on the page → footer (disclosure, privacy link, credit line).

### Step 3: Wire the Redirect
Since a static file has no backend, intercept the form submit in JavaScript,
prevent default, and redirect to the affiliate URL — with an inline comment
explaining how to swap this for a real ESP integration (Mailchimp embed,
ConvertKit/Kit form, Beehiiv embed) once the user wants actual email capture.

### Step 4: Write the Copy and HTML
Headline options: "Get the Free [Lead Magnet] and Start [Outcome] Today,"
"Download: [Lead Magnet] — Free for [Audience]." Sub-headline: "[N]
[templates/steps] that [audience] use to [outcome] — completely free." Button
copy should be action-specific, never "Submit": "Send Me the Free [Lead
Magnet] →", "Get Instant Access →".

- Single `<style>` block, mobile-first (375px base, 768px breakpoint), system fonts.
- Email-only form field (no name field — lowest friction).
- Lead-magnet visual is a pure-CSS mockup (book/checklist cover), no images.
- No navigation links that could pull the visitor off the page.
- Mark the page `noindex` — squeeze pages aren't meant to rank in search.
- Client-side email format validation before redirect.
- Disclosure line in the footer plus a short credit line.

### Step 5: Output
Three parts: page summary (lead magnet, redirect target, headline, button copy,
ESP notes), complete HTML in a fenced block, setup instructions (wire to an ESP,
replace the placeholder affiliate URL, deploy, drive traffic).

### Step 6: Self-Check
- Footer disclosure present
- "No spam" micro-copy near the form
- `noindex` meta tag present
- Single email field only
- Email format validated before redirect
- No external resources, no off-page navigation links

## Output Format

```
## Page Summary
- Lead magnet: ...
- Redirect target: ...
- Headline: ...
- Button copy: ...
- ESP notes: ...

## HTML
```html
<!-- complete self-contained file -->
```

## Setup
1. Save as `[niche]-optin.html`
2. Wire the form to an ESP (Mailchimp / ConvertKit / Beehiiv) or use a no-backend form service (Netlify Forms, Formspree) if real email capture is needed
3. Replace the placeholder affiliate URL with your real tracking link
4. Deploy via Netlify Drop / GitHub Pages / Vercel
5. Drive traffic via social, ads, or a bio link
```

## Error Handling

- **No lead magnet specified:** propose 3 options tailored to the stated niche and let the user pick.
- **No affiliate redirect given:** ask directly — this is required for the funnel to have a purpose.
- **Audience too vague:** infer from the niche; fall back to "online entrepreneurs and marketers" only as a last resort.
- **User expects the form to actually send email:** explain static HTML can't do this alone; point to Netlify Forms/Formspree or a real ESP embed.
- **No ESP specified:** include generic instructions covering the major providers in code comments.

## Examples

**Example 1:** "Build a squeeze page for a free checklist, then send people to my [tool] affiliate link" → checklist mockup, blue theme, redirect wired to the given URL.

**Example 2:** "Email capture page for a template pack, purple theme" → purple color scheme, template-pack mockup, generic ESP instructions.

**Example 3:** "Squeeze page with 2,000 subscribers as social proof" → subscriber count displayed prominently near the form.

## Suggested Next Skills

- `email-drip-sequence` (S5) — nurture captured emails toward the affiliate offer
- `bio-link-deployer` (S5) — add the squeeze page to a link hub
- `value-ladder-architect` (S4) — position this page as the entry rung of a larger funnel

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
