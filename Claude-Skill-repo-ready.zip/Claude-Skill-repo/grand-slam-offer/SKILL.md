---
name: grand-slam-offer
description: Design a differentiated affiliate/product offer using the Hormozi Value Equation (Dream Outcome x Perceived Likelihood / Time Delay / Effort). Use when the user wants to differentiate a promotion from every other affiliate/seller, asks "why would someone buy through ME", or needs the offer framework before building a landing page.
stage: S4 Offer & Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Grand Slam Offer

Design offers so good that people feel silly saying no. Uses the Hormozi Value
Equation: **Value = Dream Outcome × Perceived Likelihood ÷ Time Delay ÷ Effort & Sacrifice**.
Deconstructs why someone should buy/click through YOU specifically, not any other seller or affiliate.

## When to Use

- User wants to differentiate their promotion from every other affiliate/competitor
- User asks "why would someone buy through MY link / from ME?"
- User is about to create a landing page and needs the offer angle first
- User wants to increase conversion rates on an existing promotion
- User says anything like "offer", "value proposition", "irresistible", "Hormozi"
- User has a product/service picked and wants to craft positioning before building the page

## Input Schema

```yaml
product:                    # REQUIRED
  name: string
  description: string       # What it does
  reward_value: string      # Commission or margin (e.g., "30% recurring")
  url: string
  pricing: string           # Price or pricing page URL
  tags: string[]            # e.g., ["ai", "video", "saas"]

target_audience: string     # OPTIONAL — default: inferred from product tags
bonuses: string[]           # OPTIONAL — bonuses already offered — default: none (will suggest)
competitors: string[]       # OPTIONAL — default: auto-researched
```

## Workflow

### Step 1: Gather Context

Research: "[product name] features pricing review". Gather name, pricing tiers, key features, target audience, top 3 competitors. If target audience not given, infer from product positioning.

### Step 2: Apply the Value Equation

Score the product 1-10 on each component and identify leverage points:

**Dream Outcome (maximize)** — What's the #1 transformation the audience wants? What does life look like AFTER using this? Frame in terms of identity: "Become the person who…"

**Perceived Likelihood (maximize)** — What proof exists (case studies, user count, reviews)? What specific numbers can you cite? Can you demonstrate with your own results/screenshots?

**Time Delay (minimize)** — How fast can they see first results? What quick wins exist? Can your bonuses accelerate this (templates, setup guide)?

**Effort & Sacrifice (minimize)** — What's the learning curve? What do they give up? Can done-for-you assets reduce effort?

### Step 3: Design the Offer Stack

1. **Core product** — the product itself, reframed positioning
2. **Your unique angle** — why YOU are the right person to recommend/sell this
3. **Bonus suggestions** — 3-5 bonuses addressing the weakest Value Equation components
4. **Guarantee suggestion** — your personal guarantee on top of the product's own
5. **Urgency element** — ethical, real urgency only

### Step 4: Write Offer Copy

- **Headline**: one sentence capturing the dream outcome
- **Sub-headline**: addresses the biggest objection
- **Value stack**: bullet list of everything included (product + bonuses + guarantee)
- **CTA**: action-oriented, specific, urgent

### Step 5: Self-Validation

- [ ] Value Equation is complete (all 4 components scored and addressed)
- [ ] Offer is differentiated from a generic "buy through my link" promotion
- [ ] Bonuses are specific and deliverable (not vague promises)
- [ ] Guarantee is realistic and scoped to what YOU can actually deliver
- [ ] Copy is specific to this product (not generic template fill)
- [ ] No income claims, no fake urgency (compliance)

## Output Format

```
## Grand Slam Offer: [Product Name]

### Value Equation Analysis
| Component | Score | Leverage Point |
|---|---|---|
| Dream Outcome | X/10 | [key insight] |
| Perceived Likelihood | X/10 | [key insight] |
| Time Delay | X/10 | [key insight] |
| Effort & Sacrifice | X/10 | [key insight] |
| **Total Value Score** | **X/40** | |

### Your Unique Angle
[Why YOUR recommendation matters]

### Offer Stack
**They get:**
1. [Product] — [reframed benefit] ($XX/mo value)
2. BONUS: [Bonus 1] — [what it solves] ($XX value)
3. BONUS: [Bonus 2] — [what it solves] ($XX value)
4. BONUS: [Bonus 3] — [what it solves] ($XX value)
5. YOUR GUARANTEE: [guarantee statement]

**Total value: $XXX — they pay: $XX/mo**

### Ready-to-Use Copy
**Headline:** [headline]
**Sub-headline:** [sub-headline]
**Value Stack:** [bullet list]
**CTA:** [call to action]

### Next Steps
- Flesh out bonus details
- Craft guarantee copy
- Build the landing page with this offer
```

## Error Handling

- **No product provided**: Ask user for the product name, or run a program-search skill first.
- **No pricing found**: Search "[product] pricing". If unavailable, frame value around ROI instead of price comparison.
- **Product too generic / crowded market**: Focus the differentiation on YOUR bonuses, expertise, and guarantee rather than the product itself.
- **No competitive data**: Design the offer on the product alone; note that competitive intel would sharpen it further.

## Examples

**Example 1:** "Design a grand slam offer for [AI video tool]" → research features/pricing, score Value Equation, identify unique angle (e.g., "AI video for non-creators"), suggest bonuses (script templates, avatar setup guide, prompt library), write offer copy.

**Example 2:** "I promote [SEO tool] but my conversion rate is low" → diagnose the weakest Value Equation component (often Effort — steep learning curve), design bonuses that reduce effort (done-for-you audit template, setup walkthrough).

**Example 3:** "Create an offer for this product" (with prior niche/competitor research available) → pull in remarkability angles and competitive gaps to sharpen the offer.

## Quality Gate

Before delivering, check:
1. Would I share this on my own personal social?
2. Contains a specific, surprising detail (not generic)?
3. Respects the reader's intelligence?
4. Is the offer genuinely remarkable / share-worthy?
5. Is it irresistible, not just "good"?

Any NO → rewrite before delivering.

## Suggested Next Skills

- `landing-page-creator` (S4) — turn the offer copy into a page
- `bonus-stack-builder` (S4) — flesh out bonus details
- `guarantee-generator` (S4) — craft guarantee copy
- `email-drip-sequence` (S5) — carry the offer framing into email

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), based on Alex Hormozi's public Value Equation framework. Repackaged as a standalone Claude Skill.
