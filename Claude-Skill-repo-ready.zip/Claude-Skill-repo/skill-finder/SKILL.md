---
name: skill-finder
description: Help the user pick the right skill(s) from this 50-skill affiliate-marketing library — across S1 Research, S2 Content, S3 Blog/SEO, S4 Offer/Landing, S5 Distribution, S6 Analytics, S7 Automation, and S8 Meta — based on a plain-language goal. Use when the user asks "what can I use for X," "which skill do I need," "what's available," or describes a goal without naming a specific skill.
stage: S8 Meta
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Skill Finder

This library has 50 skills spread across 8 stages of the affiliate-marketing
workflow, and most users won't know all of them by name. Skill Finder is the
entry point: it takes a plain-language goal ("I want to find a profitable
niche," "write me a comparison post," "get my first commission") and maps it
to the right skill or sequence of skills in this specific library — no external
registry or API required, just the fixed stage map below plus reasoning about
the user's intent.

## When to Use

- User asks "what can I do," "what skills are available," or "what should I use for X"
- User describes a goal or problem without naming a skill directly (e.g., "I want to know what my competitors are doing")
- User wants a multi-step plan spanning several stages (e.g., "from zero to first commission")
- User isn't sure whether a task needs one skill or several in sequence

## Input Schema

```
{
  goal: string             # Plain-language description of what the user wants to do
  stage_hint: string       # (optional) Narrow to a stage: S1 Research, S2 Content, S3 Blog/SEO,
                            #   S4 Offer/Landing, S5 Distribution, S6 Analytics, S7 Automation, S8 Meta
  experience_level: string # (optional) "new" or "experienced" — affects how much explanation to give
}
```

## Stage Map (this library)

| Stage | Focus | Representative skills |
|---|---|---|
| S1 Research | Finding niches, offers, competitors, audience insight | `competitor-spy`, `niche-opportunity-finder`, `content-research-brief` |
| S2 Content | Writing/producing raw content across formats | `tiktok-script-writer`, `twitter-thread-writer` |
| S3 Blog/SEO | Long-form, SEO-structured written content | `affiliate-blog-builder`, `comparison-post-writer` |
| S4 Offer/Landing | Offer design, funnels, landing pages | `grand-slam-offer`, `funnel-planner` |
| S5 Distribution | Publishing, deployment, traffic channels | `github-pages-deployer` |
| S6 Analytics | Tracking, measuring, retrospectives | `conversion-tracker` |
| S7 Automation | Compliance, repeatable ops, guardrails | `compliance-checker` |
| S8 Meta | Positioning, self-improvement, navigating this library | `category-designer`, `self-improver`, `skill-finder` |

Note: this table lists representative examples, not the full 50 — when a
match isn't in this list, reason from the stage's purpose and the skill
naming pattern (`<action>-<object>`) to infer the most likely fit, and say
so explicitly rather than inventing a skill name with false confidence.

## Workflow

### Step 1: Parse the Goal
Extract the underlying intent from the user's phrasing. Separate a *stated* task ("write a comparison post") from a *deeper* goal ("get my first commission") — the deeper goal often implies a multi-stage sequence, not just one skill.

### Step 2: Match Against the Stage Map
Score candidate skills in three tiers:
- **Exact** — the user named the task the skill does almost verbatim
- **High** — strong keyword/intent overlap with a skill's purpose (e.g., "find what's working for competitors" → `competitor-spy`)
- **Related** — same stage or adjacent workflow step, useful as a next step even if not a direct hit

### Step 3: Detect Multi-Stage Goals
If the goal spans more than one stage (e.g., "go from nothing to my first sale," "build a whole content pipeline"), don't return a single skill — chart a short sequence across stages, in the order the user would naturally execute them (typically S1 → S3/S2 → S4 → S5 → S6).

### Step 4: Rank and Select
Order matches Exact → High → Related. Cap the primary recommendation list at 3-5 skills so the user isn't overwhelmed; mention additional Related skills briefly at the end.

### Step 5: Format the Recommendation
For each recommended skill, give: name, stage, one-sentence reason it fits this goal, and a ready-to-paste example prompt that would trigger it.

### Step 6: Self-Validate
Before answering, check: does every recommended skill actually exist in this library's naming pattern and stage map (don't hallucinate skills)? Is the sequence ordered the way a real user would execute it? If the goal is genuinely ambiguous, ask one clarifying question instead of guessing.

## Output Format

```
## Skill Recommendations for: "<user's goal>"

### Best Matches
| Skill | Stage | Why it fits | Try this prompt |
|---|---|---|---|

### Suggested Sequence (if multi-stage)
1. `<skill>` (S#) — ...
2. `<skill>` (S#) — ...
3. `<skill>` (S#) — ...

### Also Worth Knowing About
- `<skill>` (S#) — ...
```

## Error Handling

- **Goal is too vague ("help me make money"):** Ask one clarifying question (e.g., "do you already have a niche/offer picked, or are you starting from zero?") before recommending, rather than dumping the full stage map.
- **No skill in this library actually fits:** Say so plainly instead of forcing a stretch match; suggest the closest adjacent skill and note the gap.
- **User asks for a skill outside marketing scope entirely (e.g., unrelated coding task):** Clarify that this library is scoped to affiliate marketing and point to general-purpose help instead.
- **User wants "everything" (a full library tour):** Summarize by stage (one line each) rather than listing all skills individually, to keep the response scannable.

## Examples

**Example 1:** "I don't have a niche yet, where do I start?" → Recommend `niche-opportunity-finder` (S1) as the entry point, with `competitor-spy` (S1) as a natural follow-up once a niche is shortlisted.

**Example 2:** "I want to go from zero to my first commission" → Chart a sequence: `niche-opportunity-finder` → `content-research-brief` → `affiliate-blog-builder` or `tiktok-script-writer` → `grand-slam-offer` → `github-pages-deployer` → `conversion-tracker`.

**Example 3:** "What's the difference between comparison-post-writer and affiliate-blog-builder?" → Explain both are S3 Blog/SEO skills but `affiliate-blog-builder` sets up the overall site/content architecture while `comparison-post-writer` produces one specific comparison-style article within it.

## Suggested Next Skills

- `self-improver` (S8) — once the recommended skills have been run and results are in, close the loop with a retrospective
- `category-designer` (S8) — for users whose real blocker is positioning, not tooling
- Whatever S1 Research skill is recommended as step one for most "starting from zero" goals

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
