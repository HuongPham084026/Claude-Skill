---
name: how-to-tutorial-writer
description: Write step-by-step how-to tutorial blog posts that solve a real reader problem and naturally recommend an affiliate product as the tool for the job, using a "problem to solution to tool" structure. Use when the user wants a tutorial, walkthrough, or "how to [task]" guide that builds trust and ranks for informational keywords while driving affiliate signups.
stage: S3 Blog/SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# How-To Tutorial Writer

Write practical, step-by-step tutorials that solve a real reader problem and
position an affiliate product as the right tool for each step. Uses the
"problem → solution → tool" pattern: establish what the reader wants to
accomplish, show them exactly how, and let the product prove its value through
demonstration rather than a sales pitch.

## When to Use

- User wants educational content that converts indirectly, through trust rather than a hard pitch
- Request contains "how to", "tutorial", "guide", "walkthrough", "step by step"
- User wants to rank for "how to [task]" keywords — higher traffic and lower competition than "best" keywords
- The product is best understood by watching it used, not just described
- User wants to build topical authority before making an offer

## Input Schema

```
{
  task: { description: string, goal: string }   # REQUIRED — what the reader accomplishes
  product: { name, url, reward_value, description }  # REQUIRED — the affiliate tool used
  tutorial_type: string     # OPTIONAL — "quickstart" | "deep-dive" | "feature-focus" | "problem-solution"
                             # auto-detected from phrasing if omitted
  audience_level: string    # OPTIONAL — "beginner" (default) | "intermediate" | "advanced"
  supporting_tools: []      # OPTIONAL — other tools used alongside the primary product
  include_video_outline: boolean  # OPTIONAL — also produce a YouTube script outline
}
```

## Workflow

### Step 1: Define the Tutorial Goal
Identify the task, the tool that enables it, the audience level, and the end
state the reader will reach. If the request is vague ("write a tutorial about
HeyGen"), search `"[product] tutorial" OR "how to use [product]"` and default
to the highest-traffic use case.

Detect tutorial type from phrasing:

| Signal | Type | Length |
|---|---|---|
| "how to get started", "beginner's guide", "first time" | quickstart | 5-8 steps, 1,500-2,000 words |
| "step by step", "complete guide", "full tutorial" | deep-dive | 8-15 steps, 2,500-3,500 words |
| "how to [specific feature]" | feature-focus | 5-8 steps, 1,500-2,000 words |
| "how to [goal] without [product]" → redirect | problem-solution | 6-10 steps, 2,000-2,500 words |

### Step 2: Research the Tutorial Content
Search for: the actual step-by-step process, common beginner mistakes, official
docs, and gaps in existing top-ranking tutorials.
- `"how to [task] with [product]"`
- `"[product] tutorial [year]"`
- `"[product] [feature] settings"`
- `"[task] mistakes beginners make"`

**Accuracy rule:** never invent UI details. If a button name or menu path is
uncertain, describe the action generically ("open the settings panel") rather
than guessing.

### Step 3: Plan the Structure
- **Prerequisites:** account/tier requirements, technical requirements, assets the reader needs ready
- **Steps:** one atomic action per step, numbered (never just bulleted); each step = action-verb headline + explanation + expected result; add callout boxes for decision points
- **Affiliate integration points (natural, not forced):**
  1. Prerequisites — "You'll need a [Product] account. [Sign up free →]"
  2. The step where the product's key feature does the work
  3. After showing the final result — "here's what else it can do"
  4. The closing Next Steps section
- **Rule:** never interrupt a step sequence with a sales pitch — CTAs belong only at natural pause points.

### Step 4: Write the Full Tutorial
- **Title formula:** `How to [Task] with [Product]: Step-by-Step Guide ([Year])`
- **Intro (150-200 words):** open on the reader's problem (not "in this tutorial..."), state the concrete end result, note time required and experience level, one-sentence product intro with CTA if signup is needed before starting
- **Prerequisites block:**

```
What you need before starting:
- A [Product] account (free plan works / Pro required for [feature]) -> Create your free account
- [other required tool/asset]
- Estimated time: [X minutes]
```

- **Step format:**

```
## Step N: [Action Verb] + [What You're Doing]
[2-4 sentence explanation of what this does and why]
1. [specific sub-action]
2. [next sub-action]
You should see: [expected result]
Note: [common mistake or alternative path]
```

- **Result section:** describe the concrete output and what the reader can now do with it; contextual CTA tying it to the product's next-level feature
- **Troubleshooting (optional, high SEO value):** 3-5 "Error: X → this usually means Y, fix by Z" entries
- **Next Steps:** what to do with the result, related product features, related tutorials, final strong CTA
- **FAQ (4-6 Qs):** "Do I need a paid plan?", "How long does this take?", "Can I do this without [product]?", "Is [product] free for this?"

Target length: 1,500-3,500 words depending on tutorial_type — never pad steps just to hit a number.

### Step 5: Self-Validate Before Delivering
- Steps are numbered and atomic (one action each)
- Prerequisites section present with requirements + time estimate
- FTC disclosure appears right after the title
- No invented UI details — generic language used where unsure
- No CTA interrupts a step sequence

## Output Format

```
## SEO Metadata
Title: ...
Slug: how-to-[task-slug]
Meta Description: (150-160 chars, includes "how to" + task + product name)
Target Keyword: how to [task] with [product]
Secondary Keywords: [product] tutorial, [task] guide, [product] for beginners
Word Count: ...
Steps: N

## Article
[full publishable markdown]

## Supplementary
- FAQ schema questions/answers
- Screenshot suggestion per major step
- Affiliate URLs by product and role (primary-tool / supporting-tool)
- Video script outline (if include_video_outline=true): hook, chapter timestamps, YouTube description, tags
```

## Error Handling

- **Task too vague ("tutorial about email marketing"):** Ask for a specific task, e.g. "how to set up an automated welcome sequence in Mailchimp."
- **No product provided:** Ask which product to feature, or offer to research and suggest the best fit for the task.
- **Feature requires a paid plan:** State this clearly in Prerequisites — never hide paid requirements — and add the affiliate CTA there.
- **Task too complex for one tutorial:** Split it — write the first phase as a focused tutorial and offer to cover remaining phases separately.
- **Product UI may have changed:** Use generic action descriptions where uncertain and note that screenshots may vary from the reader's current version.

## Examples

**Example 1:** "Write a tutorial on how to create AI avatar videos with HeyGen" → task="create AI avatar video", tutorial_type=deep-dive, 12-step guide targeting "how to create ai avatar video with heygen".

**Example 2:** "Write a how-to guide for automating social media posts" → research the best-fit tool, confirm with user (or auto-select if a program was already chosen upstream), write a problem-solution tutorial.

**Example 3:** "Tutorial on how to use Semrush's Keyword Magic Tool" → tutorial_type=feature-focus, focused 8-step guide with CTAs at start and end only.

## Suggested Next Skills

- `content-pillar-atomizer` (S2) — turn the tutorial into short-form tips and clips
- `landing-page-creator` (S4) — build a signup page for the featured product
- `internal-linking-optimizer` (S6) — connect the new tutorial into the site's link graph
- `keyword-cluster-architect` (S3) — supply informational-intent clusters for future tutorial topics

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
