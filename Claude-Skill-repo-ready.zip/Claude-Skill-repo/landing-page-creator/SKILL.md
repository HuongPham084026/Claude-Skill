---
name: landing-page-creator
description: Builds a single self-contained HTML landing page (no build step, no dependencies) that promotes one affiliate product, either as a solo product spotlight or a multi-product comparison/"vs" page. Use when the user asks for a "landing page," "sales page," "product page," or "comparison page" for an affiliate offer, or wants to turn a product researched earlier into a conversion-ready page they can deploy immediately.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Landing Page Creator

Produces a dedicated, deployable landing page for an affiliate product — a single
HTML file with inline CSS, mobile-responsive, with zero external dependencies.
This is the bridge page between a traffic source (social, email, ads) and the
affiliate link itself, so every section on the page exists to move the visitor
toward one click. Supports two modes: a single-product spotlight, or a
side-by-side comparison of 2-3 competing products.

## When to Use

- User wants a dedicated page to promote one affiliate product
- User wants a "vs" or comparison page across 2-3 competing tools
- A product was already identified (e.g. from a program-research step) and now needs a conversion page
- User mentions "landing page," "sales page," "product page," or "comparison page"

## Input Schema

```
{
  product: {                # REQUIRED
    name: string,
    description: string,
    reward_value: string,   # commission, e.g. "30% recurring"
    url: string,             # affiliate link
    reward_type: string,     # recurring | one-time | tiered
    tags: string[]
  },
  page_type: string,         # "single" | "comparison" (default "single")
  compare_with: [{ name, description, url, pricing }],  # for comparison pages
  angle: string,             # marketing hook, e.g. "cheapest", "best for beginners"
  color_scheme: string       # blue | green | purple | orange | dark | hex (default blue)
}
```

If a product was surfaced by an earlier research step in the conversation, use it
directly instead of re-asking the user.

## Workflow

### Step 1: Gather Product Info
If product data isn't already available, search for it: `"[product] features pricing review"`.
Collect name, description, 3-6 key features, pricing, target audience, and top
competitors. For comparison pages missing `compare_with`, search
`"best alternatives to [product]"` and pull 1-2 credible competitors with pricing.

### Step 2: Plan the Structure
Decide `page_type` — if the user says "vs" or "compare," or supplies competitors, use
comparison; otherwise single.

**Single-product sections:** disclosure → hero (headline + CTA + trust signal) →
trust bar → 3-column feature grid → pricing + CTA → one strong testimonial → "who
this is for" → FAQ (4-6 objections) → final CTA → footer.

**Comparison sections:** disclosure → "A vs B" hero → comparison table with a
highlighted winner → per-product pros/cons blocks with individual CTAs → clear
winner callout with reasoning → FAQ → dual CTA → footer.

Map the requested color to a primary CSS variable (blue `#2563eb`, green
`#059669`, purple `#7c3aed`, orange `#ea580c`, dark = light text on `#0f172a`
background, or a raw hex).

### Step 3: Write the Full HTML
- All CSS inline in one `<style>` block; system font stack; no external fonts,
  images, or scripts (JS only for optional non-critical enhancements like an FAQ
  accordion).
- Mobile-first responsive layout.
- Every affiliate link opens with `target="_blank" rel="noopener"`.
- Write real, specific copy driven by the chosen angle — never generic filler or
  "[insert here]" placeholders.
- Visible disclosure of the affiliate relationship placed before the first
  affiliate link.
- At least 3 CTA buttons spread across hero, mid-page, and bottom.
- A short footer credit line noting the page was built with this skill library.
- No site navigation — a landing page has exactly one job.

### Step 4: Output
Deliver three parts: (1) a short page summary (type, product, angle, color,
CTA count, section list), (2) the complete HTML in a fenced code block ready to
save as `.html`, (3) deploy instructions (open locally, or push to Netlify Drop /
Vercel / GitHub Pages, then add the page to a link hub).

### Step 5: Self-Check Before Delivering
- Disclosure appears before the first affiliate link
- 3+ CTAs distributed through the page
- Mobile viewport meta tag present
- Zero external resources
- No leftover placeholder text
Fix silently rather than flagging issues to the user.

## Output Format

```
## Landing Page Summary
- Type: single | comparison
- Product(s): ...
- Angle: ...
- Color scheme: ...
- CTA count: ...
- Sections: ...

## HTML
```html
<!-- complete self-contained file -->
```

## Deploy
1. Save as `[product-slug]-landing.html`
2. Preview locally by opening the file
3. Deploy via Netlify Drop, `vercel deploy --prod`, or GitHub Pages
4. Point a custom domain if desired
5. Add the URL to your bio-link hub
```

## Error Handling

- **No product given:** ask for a product name or point the user to a program-research step first.
- **Comparison requested with only one product:** auto-search for 1-2 alternatives before proceeding.
- **No pricing found:** search once more; if still unavailable, replace the price with a "Check Current Pricing" CTA instead of guessing.
- **Unknown color name:** default to blue and tell the user they can pass a hex code instead.
- **Product has almost no public information:** ask the user for features, pricing, and audience rather than inventing claims.

## Examples

**Example 1:** "Create a landing page for [an AI video tool]" → single-product page using data already known from context, blue theme, three CTAs, disclosure above the fold.

**Example 2:** "Build a comparison page: Tool A vs Tool B vs Tool C" → comparison mode, searches for competitor pricing/features, builds a table with a highlighted recommended winner.

**Example 3:** "Make a dark-themed landing page with an SEO angle" → single-product, dark color scheme, copy angled around SEO outcomes.

## Suggested Next Skills

- `bio-link-deployer` (S5) — add the finished page URL to a link-in-bio hub
- `email-drip-sequence` (S5) — use the landing page as the destination link in email
- `bonus-stack-builder` (S4) — feed bonus copy into the page's bonus section
- `guarantee-generator` (S4) — feed guarantee copy into the page's risk-reversal section

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
