---
name: funnel-planner
description: Build a personalized, week-by-week affiliate/marketing execution roadmap that sequences research, content, offer, distribution, and analytics steps with exact time estimates and prompts. Use when the user is starting from scratch, asks "how do I start affiliate marketing", has a niche but no strategy, or wants a week-by-week roadmap.
stage: S8 Meta (planning/orchestration)
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Funnel Planner

Plan a complete affiliate/marketing funnel from research to revenue by sequencing
work into a week-by-week execution roadmap. Output is a plan with the right order
of operations, time estimates, and exact next actions for each step.

Most affiliates and solo marketers fail because they skip steps or work out of
order (e.g., building a landing page before validating the offer, or posting
content before researching what converts). This skill maps the user's resources
(time, channels, experience) to a personalized execution plan.

## When to Use

- User is starting from scratch and wants a complete plan
- User asks "how do I start affiliate marketing?" or "how do I build this system?"
- User has a niche but no strategy
- User wants to know what to do first, second, third
- User says "build me a funnel" or "plan my affiliate/marketing business"
- User wants a week-by-week roadmap

## Input Schema

```yaml
niche: string                  # OPTIONAL — e.g., "AI tools", "fitness supplements"
product: string                 # OPTIONAL — specific product/offer if already chosen
experience_level: string        # OPTIONAL — "beginner" | "intermediate" | "advanced" (default: beginner)
available_channels: string[]    # OPTIONAL — e.g., ["blog", "twitter", "linkedin", "email"] (default: ["blog", "twitter"])
weekly_hours: number            # OPTIONAL — hours per week available (default: 5)
goal: string                    # OPTIONAL — "first_commission" | "scale_to_1k" | "scale_to_10k" (default: first_commission)
```

## Workflow

### Step 1: Assess Starting Point

- **Has nothing**: start from research (niche/program discovery)
- **Has a product/offer**: skip to content creation
- **Has content**: skip to blog/SEO or landing page stage
- **Has traffic**: skip to analytics or automation stage

Ask clarifying questions only if truly ambiguous. Default to the most common case (beginner, starting from scratch).

### Step 2: Select the Right Sequence of Work

Based on channels, experience, and goal, select 5-8 concrete steps, e.g.:

- **Beginner + blog + twitter**: Research → social posts → blog review → bio-link page → SEO audit
- **Intermediate + email + blog**: Research → blog → landing page → email sequence → performance report → repurpose content
- **Advanced + all channels**: Full research-to-analytics pipeline with a compliance check at every content step

### Step 3: Estimate Effort

Estimate time per step based on experience level:
- Beginner: 2-4 hours per step
- Intermediate: 1-2 hours per step
- Advanced: 30-60 minutes per step

Fit into `weekly_hours` to build a realistic week-by-week schedule.

### Step 4: Build the Roadmap

Table with: week number, step, what it produces, time estimate, exact action/prompt to execute it.

### Step 5: Add Success Metrics

Define measurable outcomes per phase, e.g.:
- Research: "2-3 programs/offers selected"
- Content: "5+ posts ready"
- Blog/SEO: "1-2 articles published"
- Distribution: "a live page/bio-link"
- Analytics: "you know your conversion rate and cost per lead"

### Step 6: Self-Validation

- [ ] Roadmap follows a logical sequence (not random order)
- [ ] Each step has a clear, executable action
- [ ] Time estimates are realistic for the stated experience level
- [ ] Success metrics are measurable and specific (not "do well")
- [ ] Total weeks are feasible given the weekly hours budget

## Output Format

1. **Plan Overview** — niche/product, goal, timeline, total steps
2. **Week-by-Week Roadmap** — table: week | step | action | time estimate | how to execute it
3. **Milestones** — key checkpoints with expected outcomes
4. **Entry Points** — where to jump in if not starting from zero

## Error Handling

- **No niche or product**: Start with a research step to find one; ask what topics interest the user.
- **Unrealistic time commitment ("1 hour total")**: Recommend a minimal plan with one channel only.
- **Too many channels for experience level**: Recommend starting with 2 channels, adding more after the first result.

## Examples

**Example 1 — Complete beginner:** "I want to start affiliate marketing. I have 5 hours a week and I blog." → 6-week plan: Week 1 research/find programs, Week 2 social posts, Weeks 3-4 blog review, Week 5 bio-link page, Week 6 SEO audit + tracking setup.

**Example 2 — Intermediate with product:** "I already promote [Product]. How do I scale to $1K/month?" → skip research. Baseline performance → A/B test existing content → repurpose what works → build a nurture email sequence → re-measure.

**Example 3 — Advanced multi-channel:** "I'm experienced with blog, YouTube, and email. Plan a full funnel for AI tools." → compressed 4-week plan: Week 1 research + content blitz, Week 2 blog + landing page, Week 3 distribution + repurposing, Week 4 analytics setup + compliance check. Ongoing: monthly self-review.

## Suggested Next Skills

This is the orchestration layer — it points to whichever research, content, offer, distribution, or analytics skill is next in the sequence it builds. Chain it with:
- `niche-opportunity-finder` / `competitor-spy` (research)
- `content-research-brief` (content research)
- `grand-slam-offer` (offer design)
- `github-pages-deployer` (distribution)

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
