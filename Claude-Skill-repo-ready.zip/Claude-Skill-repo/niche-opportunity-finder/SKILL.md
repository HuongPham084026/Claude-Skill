---
name: niche-opportunity-finder
description: Analyze search demand, competition, and affiliate program availability to find untapped, high-opportunity affiliate niches with a data-backed scoring model. Use when the user is new to affiliate marketing and has no niche, wants to validate a niche idea, is unhappy with their current niche, or asks which niches are trending or low-competition.
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Niche Opportunity Finder

Analyze search demand, competition, and available affiliate programs to surface
untapped niches worth entering. Outputs a scored shortlist with clear reasoning
so beginners can start promoting in under an hour.

## When to Use

- User is new to affiliate marketing and has no niche
- User is unhappy with their current niche and wants alternatives
- User wants to validate a niche idea before investing time
- User asks which niches are trending or low-competition
- User wants to find niches underserved by existing affiliates

## Input Schema

```
{
  interests: string[]       # (optional) Topics user already knows or cares about
  audience: string          # (optional) Who they plan to reach — "beginners", "professionals", "parents"
  platform: string          # (optional) Where they'll publish — "blog", "tiktok", "youtube", "linkedin"
  budget: string            # (optional) "zero" | "low ($0-50/mo)" | "medium ($50-200/mo)"
  goal: string              # (optional) "first $100" | "side income $1k/mo" | "full-time income"
  avoid: string[]           # (optional) Niches or topics to exclude
}
```

## Workflow

### Step 1: Understand the User's Situation

Ask (if not already clear from context):

1. Any topics you already know well or are curious about?
2. Where will you publish content? (blog, TikTok, YouTube, newsletter...)
3. What's your income goal in the first 6 months?

If user says "just find me something" → default to: AI/SaaS tools, YouTube or blog,
goal = first $500/mo.

### Step 2: Generate Niche Candidates

Produce 8-12 niche candidates across 3 tiers:

**Tier A — Trending (high demand, growing fast):** search "fastest growing affiliate niches [current year]" and "trending affiliate programs [current year]" to find niches with momentum. Look for: AI tools, health tech, fintech, remote work tools, creator economy.

**Tier B — Evergreen (stable demand, proven programs):** Always-on niches: personal finance, web hosting, email marketing, SEO tools, fitness/wellness, online education, cybersecurity.

**Tier C — Micro-niches (narrow, low competition, high intent):** Examples: AI tools for lawyers, budgeting apps for freelancers, SEO for Shopify stores, productivity tools for ADHD. These are combinations of a vertical + a job or persona. Search "[vertical] affiliate programs [persona]" to discover.

### Step 3: Score Each Niche

Score each candidate on 4 dimensions (1-10 scale each):

| Dimension | Weight | How to Assess |
| --- | --- | --- |
| Search Demand | 30% | Search "[niche] how to" — look at result count and autosuggest depth |
| Program Availability | 30% | Search "[niche] affiliate programs" — count quality programs |
| Competition Level | 25% | Search "[niche] best tools" — how saturated is the top 10? Fewer exact-match affiliate sites = less competition. Score 10 = very low competition |
| Content Potential | 15% | Can tutorials, comparisons, listicles, and reviews be made for this niche easily? |

**Overall score** = weighted average. Cut anything below 5.5.

Verdict: 7.5+ = "High Opportunity" / 5.5-7.4 = "Worth Testing" / <5.5 = "Saturated/Skip"

### Step 4: Validate Top 3 Niches

For the top 3 niches, verify real programs exist with good commission structures:

- At least 3 programs with 20%+ commission OR recurring commission type
- At least one program with 30+ day cookie duration
- Community-validated / well-reviewed programs

If a niche scores well on demand but has no programs, search for alternative program sources to verify options exist.

### Step 5: Build the Opportunity Brief

For the top-ranked niche, produce a one-page opportunity brief (see Output Format).
For runner-up niches, produce summary cards only.

### Step 6: Recommend Next Steps

Map user's chosen niche to next actions:

1. Find the best specific program in this niche
2. Draft first content pieces (TikTok script, Twitter thread, etc.)
3. Project first 90 days of income

### Step 7: Self-Validation

Before presenting output, verify:

- [ ] Search demand backed by data (autosuggest depth, result count)
- [ ] Top niche has ≥3 programs with 20%+ commission
- [ ] Competition score reflects actual top-10 SERP analysis
- [ ] Content angles are specific and actionable, not generic

If any check fails, fix the output before delivering. Do not flag the checklist to the user — just ensure the output passes.

## Output Format

```
## Niche Opportunity Report

### Top Pick: [Niche Name]

**Opportunity Score:** [X.X/10] — [Verdict]
**Tier:** [Trending / Evergreen / Micro-niche]
**Difficulty:** [Beginner-friendly / Intermediate / Advanced]

**Why this niche:**
[2-3 sentences covering demand, program quality, and why it's not yet saturated]

| Dimension | Score | Evidence |
|-----------|-------|----------|
| Search Demand | X/10 | [What search data showed] |
| Program Availability | X/10 | [X programs found, avg commission Y%] |
| Competition Level | X/10 | [What competitor landscape looks like] |
| Content Potential | X/10 | [Content formats that work here] |
| **Overall** | **X.X/10** | **[Verdict]** |

**Example affiliate programs:** [Program A], [Program B], [Program C]

**Content angles to start with:**
1. [Angle 1 — specific post/video idea]
2. [Angle 2]
3. [Angle 3]

---

### Runner-up: [Niche Name] — [X.X/10]
[2-sentence summary + why it's #2]

### Other Candidates Scored

| Niche | Score | Verdict | Note |
|-------|-------|---------|------|
| ...   | ...   | ...     | ...  |

---

## Next Steps

1. Find the best [Niche] program available
2. Project 90-day earnings
3. Create your first piece of content
```

## Error Handling

- **No interests provided:** Default to AI/SaaS tools niche. Explain the default.
- **Niche too broad (e.g., "health"):** Break into sub-niches and score each separately.
- **Niche too narrow:** Widen one dimension and present a spectrum of options.
- **No programs found for top niche:** Still present the niche but flag program gap. Suggest direct brand deals as alternative.
- **User picks a saturated niche:** Don't just say no. Find the micro-niche angle within it that is less saturated.
- **Conflicting interests:** Ask user to pick one dimension (monetization speed vs. passion vs. content ease) and sort by that.

## Examples

**Example 1:** User: "I want to start affiliate marketing but have no idea what niche to pick"
→ Ask: any interests? what platform? income goal?
→ If no answer: default to AI/SaaS tools on YouTube/TikTok, goal = first $500/mo
→ Generate 10 candidates, score all, return top 3 with detailed brief for #1

**Example 2:** User: "Is fitness a good niche for affiliate marketing?"
→ Validate fitness niche: high demand, many programs
→ Flag: highly competitive on Google. Score = 6.2 "Worth Testing"
→ Suggest micro-niches: fitness for new moms, home gym under $500, wearables for runners
→ Score micro-niches — surface the strongest one

**Example 3:** User: "I know a lot about Notion and productivity tools"
→ Lean into existing knowledge: AI productivity tools, note-taking apps, PKM space
→ Score with "expert authority" bonus — existing knowledge = faster content creation
→ Recommend micro-niche: "AI tools for knowledge workers" — score 8.1

## Suggested Next Skills

- `affiliate-program-search` (S1) — validated niches to search programs in
- `competitor-spy` (S1) — reverse-engineer who's already winning in this niche
- `content-research-brief` (S2) — research the chosen niche before writing content
- `grand-slam-offer` (S4) — design the offer once a program is picked

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
