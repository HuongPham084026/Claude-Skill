---
name: internal-linking-optimizer
description: Audit a site's internal link architecture using hub-and-spoke SEO methodology — finds orphan pages, weak hub-to-spoke connections, and missing contextual links, then outputs specific linking instructions (source, target, anchor text, placement, priority). Use when the user mentions "orphan pages", "internal links", "site structure", or after publishing new content that needs to be linked into the existing site.
stage: S6 Analytics
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Internal Linking Optimizer

Maps a site's internal link graph, finds pages that are cut off from link
equity (orphans, weak hub connections), and produces a concrete, prioritized
list of links to add — not general advice, but "add this link, from this
page, to that page, with this anchor text." Fixing orphan pages typically
lifts their organic traffic 30-100% within 4-6 weeks, which on a money page
earning even $100/month is a direct, fast revenue uplift.

## When to Use

- User mentions "orphan pages," "link structure," or "hub and spoke"
- After publishing new content that hasn't been linked in from anywhere yet
- Monthly site-maintenance review of link architecture
- Chaining downstream from a keyword-cluster-architecture skill that already defined the ideal topical structure

## Input Schema

```
{
  site_url: string,                # REQUIRED
  known_pages: [                   # optional - speeds up analysis if provided
    { url: string, topic_cluster?: string, is_money_page?: boolean }
  ],
  hub_pages: [string],             # optional - known pillar/hub URLs
  recent_pages: [string]           # optional - newly published pages needing links
}
```

## Workflow

### Step 1: Discover Site Structure
Crawl or search-index the site to build a page inventory. For each page, note its likely topic based on title/URL/content.

### Step 2: Map Pages to Topical Clusters
Group pages into clusters around shared topics. Identify (or confirm) which page in each cluster is the natural hub/pillar and which are spokes/supporting content.

### Step 3: Compute Link Metrics Per Page
- Inbound internal links (inlinks)
- Outbound internal links (outlinks)
- Click depth from homepage
- Anchor text used for existing inlinks (generic "click here" vs. descriptive)

### Step 4: Identify Problems
- **Orphan pages** — zero or near-zero inbound internal links
- **Weak hub-spoke connections** — a cluster's hub doesn't link to all its spokes, or spokes don't link back to the hub
- **Missing contextual links** — clearly related pages that don't link to each other in body content
- **Link-equity dilution** — pages with excessive outlinks spreading authority too thin
- **Under-linked money pages** — pages carrying affiliate links but low internal inlink count relative to their revenue importance

### Step 5: Generate Linking Instructions
For every fix, specify:
- Source page (where the link goes)
- Target page (what it points to)
- Suggested anchor text (natural, descriptive — not generic or keyword-stuffed)
- Placement (which paragraph/section, ideally near genuinely related content)
- Priority: P0 (money pages, orphans), P1 (weak hub-spoke gaps), P2 (nice-to-have contextual links)
- Reasoning (why this link helps — e.g., "connects orphaned money page to its topical hub")

### Step 6: Validate Output
- Every recommendation is specific (real source/target URLs, not "link more")
- Hub-and-spoke logic is coherent — hubs link out to all spokes, spokes link back
- Anchor text reads naturally, not stuffed
- Link density stays in a healthy range (roughly 3-5 internal links per 1,000 words)
- Every newly published page gets at least 2-3 inbound links assigned

## Output Format

```
## Internal Linking Audit — <site_url>

### Site Metrics
- Pages analyzed: <n>
- Orphan pages found: <n>
- Avg inlinks/outlinks per page: <n> / <n>
- Max click depth from homepage: <n>

### Priority Linking Instructions
| Priority | Source Page | Target Page | Anchor Text | Placement | Reason |
|---|---|---|---|---|---|
| P0 | | | | | |
| P1 | | | | | |
| P2 | | | | | |

### Orphan Pages Needing Immediate Attention
- <url> — <topic cluster it belongs to> — <suggested hub to link from>
```

## Error Handling

- **Site too large to fully crawl:** sample the most important sections (money pages, recent posts, main nav categories) and state the analysis is partial.
- **No clear topic clusters exist yet:** note that cluster structure should be defined first (recommend a keyword-clustering skill) before internal linking can be optimized systematically.
- **All pages already well-linked:** report that no orphans were found, and shift recommendations toward strengthening anchor-text quality and money-page link density instead.
- **`recent_pages` provided but no existing site map:** prioritize just getting those pages 2-3 solid inbound links from the most topically relevant existing pages, rather than a full-site audit.
- **Money pages can't be identified:** ask the user which pages carry affiliate links/monetization so P0 priority can be assigned correctly.

## Examples

**Example 1:** "I just published a new HeyGen review, can you make sure it's linked in?" → Finds 2-3 topically related existing pages (AI tool roundups, other video-tool reviews), assigns each a specific anchor-text link to the new page, prioritized P0 since it's a money page.

**Example 2:** "Check my site for orphan pages" → Crawls/maps the site, reports orphan count and which topic clusters they belong to, and generates linking instructions from the nearest hub page to each orphan.

**Example 3:** "My blog has 80 posts but I never think about internal links" → Full audit: builds topic clusters, flags weak hub-spoke connections, and outputs a prioritized batch of P0/P1/P2 links, noting current link density is likely under the 3-5-per-1,000-words benchmark.

## Suggested Next Skills

- `seo-audit` (S6 Analytics) — run a full on-page audit on the money pages identified as under-linked
- `performance-report` (S6 Analytics) — track whether traffic to previously orphaned pages improves after links are added
- `ab-test-generator` (S6 Analytics) — once a page gets enough new traffic from internal links, test its headline/CTA to convert that traffic

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
