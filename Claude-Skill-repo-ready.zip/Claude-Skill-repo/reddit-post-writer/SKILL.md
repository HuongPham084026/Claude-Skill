---
name: reddit-post-writer
description: Write Reddit posts and comments that recommend an affiliate product the way a real Redditor would — leading with genuine value and only mentioning the product after trust is established — so they earn upvotes instead of getting flagged as spam or banned. Use when the user wants to promote a product on Reddit, reply to a Reddit thread with a product mention, or asks how to share an affiliate link on Reddit without getting removed.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Reddit Post Writer

Reddit has the sharpest spam detector of any platform. This skill writes posts
and comments that would hold up as useful even with the product mention deleted
— the recommendation rides in on genuine value, not the other way around.

## When to Use

- User wants to drive affiliate traffic from a specific subreddit
- User is replying to an existing Reddit thread and wants to mention a product naturally
- User has genuine experience with a product and wants to share it as a Redditor, not a marketer
- User asks how to avoid getting banned for self-promotion on Reddit

## Input Schema

```
{
  product: { name: string, description: string, url: string, reward_value: string }
  subreddit: string                # e.g. "r/productivity"
  post_type: "post" | "comment_reply" | "ama_style"   # default: auto
  trigger_question: string         # (optional) the specific question/post being replied to
  personal_experience: string      # (optional) real experience to anchor the post
  audience: string                 # (optional)
  tone: "genuine" | "analytical" | "casual"
  problem_focus: string            # (optional) specific problem the post should address
}
```

## Workflow

### Step 1: Read the Subreddit's Culture First
Search `reddit r/[subreddit] rules affiliate` to check whether links are banned
outright, what post formats get upvoted, and whether the community expects
declared neutrality.

- **Generally tolerant of product mentions:** r/productivity, r/Entrepreneur, r/sidehustle, r/freelance, r/marketing, r/SEO, r/webdev, r/startups, r/smallbusiness
- **Ban-happy about promotion:** r/frugal, r/cscareerquestions, r/AskReddit, r/personalfinance (strict about direct links)

If links are banned, drop the URL entirely — mention the product by name and
point to "search for [product]'s affiliate/referral program" instead.

### Step 2: Choose the Post Type
- **Original post** — best with no existing discussion; frame as a story, a
  question, or an honest breakdown ("I tested 5 tools so you don't have to").
- **Comment reply** — highest-trust format; answer the actual question fully
  before the product ever comes up (3rd+ paragraph).
- **AMA-style / experience share** — position as an experienced practitioner;
  the product surfaces naturally when people ask "what do you use?"

Use comment-reply whenever `trigger_question` is supplied; default to original
post otherwise.

### Step 3: Research Reddit-Specific Angles
Search `reddit [product] review` for how real users describe it (mirror their
language) and common objections to pre-empt. Search `reddit [problem space]
best tools` to see what's already recommended, so the post reads as additive
rather than a takeover of the thread.

### Step 4: Write the Post
1. **Title** (new posts only): specific and human, never a headline
   — "I tried 4 PM tools over 2 years, here's what stuck" not "The BEST tool!!"
2. **Opening:** establish credibility/relatability, zero product mention.
3. **Body:** the real story or breakdown — must stand alone as useful.
4. **Product introduction (70-80% through):** name it, state the specific use
   case, and include one honest limitation — cons build trust fast.
5. **Disclosure at the bottom:** "Full disclosure: the link in my profile is
   an affiliate link. No extra cost to you, and I'd recommend this regardless."
   If no link is being posted: "Not affiliated, just a genuine fan."
6. **Closing:** invite discussion, not clicks — ask a question back.

### Step 5: Run the Anti-Spam Checklist
- [ ] Still useful with the product mention stripped out
- [ ] No exclamation-mark praise, no unqualified superlatives
- [ ] Link lives in a comment or profile bio, not the post body (most subreddits)
- [ ] Disclosure present and clear
- [ ] At least one genuine limitation stated
- [ ] Tone matches the subreddit
- [ ] Flag if this is a brand-new account (instant-downvote risk)

### Step 6: Add an Engagement Plan
Note a reply strategy for likely comments, what kind of engagement to court
(discussion, saves), the best day/time for this subreddit, and 1-2 subreddits
this content could be cross-posted to (reworded, not copy-pasted).

## Output Format

```
## Reddit Post: [Product]

**Type:** [Post / Comment Reply / AMA]   **Subreddit:** [r/...]
**Allows affiliate links:** [Yes / No / Comments only]

### Title (if new post)
[title]

### Post Body
[full text, Reddit markdown]

### Link Placement
[where and why]

### Subreddit Notes
- Tone: ...   Best time: ...   Watch out for: ...

### Cross-Post Opportunities
1. [r/subreddit] — [why]

### Engagement Tips
1. ...
```

## Error Handling

- **Subreddit bans affiliate links outright:** drop the link, mention the product by name only, switch disclosure to "not affiliated, genuine rec," suggest building karma there first.
- **No personal experience supplied:** write from research and label it clearly; warn that fabricated first-person claims get called out fast on Reddit.
- **Product is controversial in that community:** address it head-on in the post rather than avoiding it — pre-empts pile-on downvotes.
- **User wants the same post mass-posted across subreddits:** refuse — that's spam and risks a ban; write a distinct version per subreddit instead.
- **New account posting this:** add an explicit warning that new accounts posting affiliate content get near-instant suspicion; recommend 3-6 months of genuine participation first.

## Examples

**Example 1:** "Write a Reddit post for r/productivity recommending Notion" → original post, "18 months with Notion" framing, honest con about the learning curve, link in the first comment.

**Example 2:** "Someone in r/freelance asked what tools people use for clients — reply for me" → comment-reply format, product is one of several tools mentioned, not the headline.

**Example 3:** "Write about HeyGen for r/videography" → checks that subreddit's strict promotion norms, frames as an honest experience share with limitations (uncanny valley) stated up front, link in comments only.

## Suggested Next Skills

- `affiliate-blog-builder` (S3) — expand the Reddit angle into a full review article
- `content-pillar-atomizer` (S2) — break a long-form piece into Reddit-ready fragments plus other platforms
- `viral-post-writer` (S2) — adapt the same experience story for LinkedIn/X with a punchier framing

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
