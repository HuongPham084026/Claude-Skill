---
name: affiliate-program-search
description: Search and evaluate affiliate programs by niche, commission structure, and cookie duration, then score each candidate across earning potential, content potential, market demand, competition, and trust. Use when the user wants to find affiliate programs to join, is comparing programs in a niche, or asks "what should I promote in X?"
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Affiliate Program Search

Systematically discover and rank affiliate programs so the user starts with data,
not guesswork. Queries a public affiliate-program directory (or falls back to web
search), scores every candidate on a weighted rubric, and hands off a ranked
shortlist ready for deeper due diligence.

## When to Use

- User wants to find affiliate programs in a niche ("best AI tool affiliate programs")
- User has a rough topic/audience and needs monetization options
- User wants to compare programs by commission, cookie length, or recurring vs one-time payout
- Kicking off a new niche before any content has been created (first step of S1)

## Input Schema

```
{
  niche: string                # required — topic, product category, or audience
  commission_pref: string      # optional — "recurring" | "one_time" | "either" (default: either)
  platform: string             # optional — where content will be published (blog, YouTube, TikTok, email)
  min_cookie_days: number      # optional — filter out short cookie windows
}
```

## Workflow

### Step 1: Clarify Intent
Confirm niche, whether the user prefers recurring commissions (SaaS-style) over
one-time payouts, target audience, and the primary content platform — these
change which programs are worth surfacing.

### Step 2: Query Program Data
- Primary: `GET https://openaffiliate.dev/api/programs?q=<niche term>` — public directory, no auth required
- Fallback: `web_search`: `"<niche> affiliate program" commission OR "cookie duration"`
- Also search: `"<niche> affiliate program" reddit review` to catch payout complaints before recommending

Pull 8-15 candidate programs minimum before scoring — a shortlist built from 2-3 results is unreliable.

### Step 3: Score Each Program

| Dimension | Weight | What to check |
|---|---|---|
| Earning Potential | 30% | Commission %/flat rate, average order value, recurring vs one-time |
| Content Potential | 25% | Enough evergreen angles (reviews, comparisons, tutorials) to sustain a content calendar |
| Market Demand | 20% | Search volume signals, active communities, growing category |
| Competition Level | 15% | How saturated the affiliate space is for this product |
| Trust Factor | 10% | Payout track record, network reputation, terms transparency |

Composite = weighted average, 1-10 scale.

### Step 4: Apply Verdict Thresholds
- **7.5-10 — Strong Pick**: recommend leading with this
- **5.5-7.4 — Worth Testing**: viable, flag what to validate first
- **Below 5.5 — Skip**: don't recommend unless user has a specific reason to override

### Step 5: Self-Validation
- [ ] Reward values/cookie durations came from real data, not invented
- [ ] Cookie duration is a number, not a vague phrase
- [ ] Verdict matches the score threshold exactly
- [ ] At least 2 alternative programs are shown, not just the winner

## Output Format

```
## Affiliate Program Search: [Niche]

### Ranked Programs

| Program | Commission | Cookie | Recurring? | Score | Verdict |
|---|---|---|---|---|---|
| ... | ... | ... | ... | X/10 | Strong Pick |

### Top Recommendation: [Program Name]
- Why it wins: [reasoning tied to scores]
- Commission structure: [detail]
- Content angles this unlocks: [2-3 ideas]

### Runner-Up: [Program Name]
[1-2 sentence reasoning]

### Next Steps
1. Sign up for [top pick]'s affiliate program
2. Run `purple-cow-audit` before committing content budget
3. Run `commission-calculator` to project realistic monthly earnings
```

## Error Handling

- **No programs found for niche**: broaden the search term (e.g., parent category) and note the niche may be too narrow for existing programs.
- **API unavailable**: fall back to `web_search` and clearly label figures as estimates, not verified API data.
- **All programs score low**: say so honestly; suggest `monopoly-niche-finder` to find an adjacent niche with better options rather than forcing a weak pick.
- **Conflicting commission data across sources**: report the range and flag it as unverified rather than picking one number.

## Examples

**Example 1:** "Find me affiliate programs for AI writing tools" → Queries the directory, returns 10 scored programs, recommends the top recurring-commission pick with content angle ideas.

**Example 2:** "I want one-time high-ticket commissions in the fitness niche" → Filters for `commission_pref: one_time`, surfaces coaching/equipment programs, flags any with poor trust signals from Reddit complaints.

## Suggested Next Skills

- `purple-cow-audit` (S1) — verify the top-scoring program's product is actually worth promoting before committing
- `commission-calculator` (S1) — project realistic monthly earnings from the chosen program
- `monopoly-niche-finder` (S1) — if all programs score low, find an intersection niche with less competition

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
