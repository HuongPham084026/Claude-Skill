---
name: content-pillar-atomizer
description: Turn one long-form piece (blog post, article, or review) into 15-30 platform-native micro-content pieces for Twitter/X, LinkedIn, Reddit, TikTok, and email — re-contextualized for each platform's culture, not just reformatted. Use when the user wants to repurpose a blog post, "atomize" content, multiply one article into weeks of social posts, or turn an existing article into platform-specific content.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Pillar Atomizer

One deep piece of writing becomes a month of social content. The key discipline
is re-contextualization, not reformatting: a LinkedIn post built from an insight
should read nothing like the Reddit comment built from the same insight, even
though they share the underlying idea.

## When to Use

- User has a blog post or article and wants to maximize its reach across platforms
- User explicitly asks to "atomize", "repurpose", or "10x" a piece of content
- Right after a long-form skill (e.g. a blog builder) produces an article
- User wants a steady content cadence without writing something new every day

## Input Schema

```
{
  pillar_content: string        # REQUIRED — full article text or a URL to fetch
  platforms: string[]           # default: ["twitter", "linkedin", "reddit"]
                                 # also: "tiktok", "email", "threads"
  product: { name: string, url: string, reward_value: string }  # optional
  mode: "quality" | "volume"    # default: "quality"
  tone: "professional" | "casual" | "edgy" | "educational"  # default: inferred
}
```

## Workflow

### Step 1: Analyze the Pillar Content
Fetch the URL if given. Extract 5-8 key insights, data points, quotes,
frameworks, and stories. Identify which are "atomic units" — ideas
self-contained enough to work independently of the rest of the article.

### Step 2: Check Which Platform Is Actually Hot for This Topic
Don't split evenly by default if you don't have to. Search
`[topic] youtube vs tiktok vs linkedin` or check any available engagement data
to see whether the topic skews visual (TikTok/YouTube-heavy) or professional
(LinkedIn-heavy), and weight the piece count accordingly:

```
Even split:        Twitter 5 | LinkedIn 3 | Reddit 3 | TikTok 3 | Email 2
TikTok is hot:      Twitter 3 | LinkedIn 1 | Reddit 2 | TikTok 6 | Email 2
LinkedIn is hot:    Twitter 3 | LinkedIn 5 | Reddit 2 | TikTok 2 | Email 2
```
Reddit is frequently under-used by affiliates — don't drop it just because it's
not the default hot platform; a strong Reddit post ranks in Google for years.

### Step 3: Map Each Platform's Culture

| Platform | Format | Tone | Length | CTA |
|---|---|---|---|---|
| Twitter/X | Thread or single | Punchy, opinionated | 280 chars / 5-10 tweet thread | Last tweet |
| LinkedIn | Story or insight post | Professional, first-person | ~1300 chars | Soft CTA in comments |
| Reddit | Value-first post/comment | Helpful, skeptical-aware | Variable | Disclosure + subtle |
| TikTok | Hook + script | Casual, energetic | 30-60s | Verbal + bio link |
| Email | Newsletter section | Conversational | 200-400 words | Direct link |
| Threads | Conversational take | Casual, authentic | ~500 chars | Bio link |

### Step 4: Generate the Micro-Content
Draw each piece from a different atomic unit so pieces on the same platform
never repeat the same point:
- Twitter: 3-5 pieces (1 thread, 2-3 standalone tweets, 1 hot take)
- LinkedIn: 2-3 pieces (story, insight, question post)
- Reddit: 2-3 pieces (1 detailed post, 1-2 comment-ready responses)
- TikTok: 2-3 scripts (educational, hot take, tutorial)
- Email: 1-2 pieces (newsletter section, standalone email)

Every piece must stand alone without the reader having seen the pillar, feel
native to its platform, carry exactly one insight, and include FTC disclosure
wherever an affiliate link is present.

### Step 5: Tag Each Piece for Tracking
Attach: source pillar reference, platform, content type, affiliate product (if
any), and a suggested posting day/time.

### Step 6: Self-Validate
- [ ] Every piece reads native to its platform, not resized copy
- [ ] Every piece stands alone
- [ ] Disclosure present wherever a link appears
- [ ] No duplicate messaging within the same platform
- [ ] Platform norms respected (Reddit skepticism, LinkedIn professionalism, etc.)

## Output Format

```
## Content Atomizer: [Pillar Title]

**Atomic units extracted:** X   **Platforms:** [...]   **Total pieces:** XX

### Twitter/X (X pieces)
**Thread: [title]**
🧵 1/ ...
...
**Standalone Tweet:** ...

### LinkedIn (X pieces)
**Story Post:** ...

### Reddit (X pieces)
**Post: r/[subreddit]** — Title: ... / Body with disclosure

[repeat per platform]

### Posting Schedule
| Day | Platform | Piece | Time |
|---|---|---|---|
```

## Error Handling

- **No pillar content given:** ask for the article text or a URL to fetch.
- **Content too short to atomize well:** extract what's there, note that a longer pillar piece would yield more/better pieces.
- **No affiliate angle in the source:** generate value-only content — it still builds the audience for future promotions.
- **Unsupported platform requested:** generate generic-format content and flag it as unreviewed for that platform's specific norms.

## Examples

**Example 1:** "Atomize my HeyGen review blog post into social content" → extracts 6 insights, produces 15 pieces (Twitter thread + 3 tweets, 2 LinkedIn posts, 2 Reddit posts, 2 TikTok scripts).

**Example 2:** "Turn this article into just LinkedIn and Twitter content" → limits to 2 platforms, generates 3 LinkedIn posts and 5 Twitter pieces.

**Example 3:** "Atomize in volume mode" → generates 25-30 pieces with multiple variants per platform tagged with variant IDs for A/B testing.

## Suggested Next Skills

- `viral-post-writer` (S2) — polish any single atomized piece into a fully-worked platform post
- `infographic-generator` (S2) — turn a stat-heavy atomized piece into a visual asset
- `reddit-post-writer` (S2) — deepen the Reddit-specific piece with full subreddit-culture handling

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
