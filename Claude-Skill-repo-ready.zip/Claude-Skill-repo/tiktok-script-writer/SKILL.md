---
name: tiktok-script-writer
description: Write structured 30-60 second video scripts for TikTok, Instagram Reels, and YouTube Shorts that hook viewers in the first 3 seconds, demo the product naturally, and drive affiliate/product link clicks. Use when the user asks for a TikTok/Reels/Shorts script, a "hook for TikTok", or short-form video content promoting a product.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# TikTok Script Writer

Write punchy 30-60 second video scripts for TikTok, Instagram Reels, and YouTube
Shorts that stop the scroll, demo the product naturally, and drive clicks. Every
script is structured for vertical video: **hook → problem → demo → result → CTA**.

## When to Use

- User wants to promote a product/tool on short-form video
- User has a product picked and needs a TikTok/Reels script
- User asks for a hook, or "write a TikTok for X"
- User wants a script that converts, not just entertains
- User creates content on TikTok, Reels, or YouTube Shorts

## Input Schema

```yaml
product:
  name: string               # REQUIRED
  key_feature: string        # REQUIRED — the single most demo-able feature
  pain_point: string         # REQUIRED — the problem it solves
url: string                  # OPTIONAL

duration: number             # OPTIONAL, default: 45 (seconds; 15-60)
hook_style: string           # OPTIONAL — "demo-first" | "shock-stat" | "relatable" | "story" | "controversial"
persona: string              # OPTIONAL — creator persona/voice (default: neutral expert)
can_demo_live: boolean       # OPTIONAL, default: true — can the creator screen-record the product live?
mode: string                 # OPTIONAL — "single" | "volume" (volume = 5-10 hook variants for A/B testing)
```

## Workflow

### Step 1: Research What's Winning (Optional but Recommended, <2 min)

Before writing, check what's currently performing in this niche on TikTok/Reels:
search "[product category] TikTok viral" or "[niche] TikTok trending format". Note
the winning format (comparison, before/after, storytime, listicle) and typical hook
style. This alone can significantly improve a script's potential — build on proven
patterns instead of guessing.

### Step 2: Pick the Hook Style

Match hook to the product's strongest angle:
- **AI tools / visual products** → Demo First almost always wins ("Watch this AI do X in 5 seconds")
- **SaaS / productivity tools** → Relatable or Shock/Stat hooks ("I wasted 10 hours a week until I found this")
- **Health/finance/high-consideration** → Story or Controversial hook, softer CTA
- If `hook_style` specified, use it. Otherwise pick the best fit and state why.

### Step 3: Structure the Script

Every script follows this arc (adapt timing to `duration`):

| Segment | Time | Purpose |
|---|---|---|
| Hook | 0-3s | Stop the scroll — tease the payoff, don't just ask a question |
| Problem | 3-10s | Name the pain point the audience already feels |
| Demo | 10-30s | Show the product actually solving it — must be REAL, no vague "then it does this amazing thing" |
| Result | 30-40s | The payoff — what changed, with a specific number/detail if possible |
| CTA | 40-45s | Clear next action — "link in bio", not a hard sell |

### Step 4: Write for the Format

- Sentences under 10 words — viewers process fast
- No filler ("basically", "literally", "you know what I mean")
- New visual cut, text overlay, or spoken transition every 3-5 seconds
- Sound-optional: the text overlay alone should tell the whole story
- End the hook WITH the setup — tease the answer, don't just pose a question

### Step 5: Add Production Notes

For each segment, include: spoken copy, on-screen text overlay, and a visual/shot direction cue (e.g., "[SCREEN RECORD: open the app, click X]").

### Step 6: Compliance Pass

Per FTC-style disclosure norms for short-form video:
- Text overlay "#ad" or "Affiliate link in bio" must appear during the CTA segment
- Verbal disclosure is best practice but not always required — flag either way
- Never expose specific commission amounts in the script

### Step 7: Volume Mode (if requested)

If `mode: "volume"`: generate 5-10 hook variations for the same product, prioritizing speed and variety over polish. Tag each with a variant ID so the user can A/B test and let real data pick the winner — don't try to predict which hook wins from theory alone.

### Step 8: Self-Validation (Purple Cow Test)

- [ ] Remarkable enough to share? (not generic template copy)
- [ ] Demo is concrete and specific, not vague
- [ ] Hook teases the payoff in the first 3 seconds
- [ ] Disclosure is present in the CTA segment
- [ ] No commission amounts exposed

Any NO → rewrite before delivering.

## Output Format

```
## TikTok/Reels/Shorts Script: [Product Name]
**Duration:** ~[X]s | **Hook style:** [style] | **Platform notes:** same script works for Reels/Shorts with minor caption/hashtag tweaks

| Time | Visual | Text Overlay | Spoken |
|---|---|---|---|
| 0-3s | [shot] | [overlay text] | [line] |
| 3-10s | ... | ... | ... |
| 10-30s | ... | ... | ... |
| 30-40s | ... | ... | ... |
| 40-45s | ... | ... | "Link in bio #ad" |

**Caption:** [ready-to-post caption with hashtags]

### Film Checklist
1. Screen-record the demo section first — hardest part to improvise
2. Film hook + CTA last, once you know the demo's actual pacing
3. Post to TikTok, cross-post to Reels/Shorts (1 video, 3 platforms)
```

## Error Handling

- **Platform unspecified**: Default to TikTok; note Reels/Shorts use the same script with minor caption/hashtag adjustments.
- **Product has no visual/demo-able feature**: Use Story or Relatable hook instead of Demo-First; lean on before/after framing.
- **`can_demo_live: false`**: Substitute with a talking-head "here's what changed" testimonial structure instead of a live demo.
- **Sparse product input**: Research the product briefly to find its most demo-able feature and core pain point before writing.
- **User wants a "salesy" hard-sell script**: Push back gently — hard-sell hooks underperform on TikTok; recommend the softer, benefit-led framing and explain why.

## Examples

**Example 1:** "Write a TikTok script for an AI video generator" → Demo First hook ("I replaced my $5K video team with this"), live demo of generating a video in 15s, result (time saved), CTA with #ad overlay.

**Example 2:** "Give me 5 hook variations for an AI writing tool" → volume mode, 5 tagged hook variants (shock-stat, relatable, demo-first, controversial, story), ready for A/B testing.

**Example 3:** "Script for a budgeting app, I can't screen-record well" → `can_demo_live: false` → talking-head testimonial structure with a specific before/after number instead of a live demo.

## Suggested Next Skills

- `social-media-scheduler` (S5) — schedule the script across platforms
- `content-pillar-atomizer` (S7) — repurpose the script into other formats (carousel, tweet, blog snippet)

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
