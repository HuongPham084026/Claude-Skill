---
name: self-improver
description: Run a structured retrospective on affiliate campaign results — diagnose why content, offers, or funnels underperformed using offer-market fit, traffic-content match, and funnel-leak analysis — then produce a prioritized, measurable improvement plan. Use when the user says "review my results," "what went wrong," "why aren't I converting," or wants to close the loop after a campaign or content push.
stage: S8 Meta
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Self-Improver

Most affiliates never close the loop: they publish content, run traffic, watch
results trickle in, and move straight to the next idea without diagnosing *why*
something under- or over-performed. Self-Improver turns raw results into a
structured retrospective — root-causing failure points with evidence, not
guesswork — and hands back a prioritized action plan that feeds directly into
earlier stages (new content, new offers, new traffic channels).

## When to Use

- User has campaign, content, or funnel results and asks "what went wrong" or "how do I improve this"
- Conversion rate, CTR, or traffic is below expectations and the cause is unclear
- User wants a periodic retrospective cadence (weekly/monthly) rather than one-off firefighting
- Before scaling spend or content volume on something whose real performance drivers haven't been diagnosed
- After running skills like `funnel-planner` or `affiliate-blog-builder` and results are in

## Input Schema

```
{
  campaign_or_content: string     # What's being reviewed (post, funnel, campaign, channel)
  results_data: string            # Available metrics (traffic, CTR, conversion rate, revenue, etc.)
  expectations: string            # (optional) What was expected/targeted going in
  timeframe: string                # (optional) Period the data covers
}
```

## Workflow

### Step 1: Establish the Baseline
Collect whatever metrics exist (traffic, click-through rate, conversion rate, average order value, revenue per visitor) and note what's missing. If baseline data is thin, say so explicitly rather than fabricating numbers — recommend minimum tracking needed for next time (see `conversion-tracker`).

### Step 2: Compare Results Against Expectations
Lay results next to what was expected or against industry benchmarks when the user has no stated target:
- Blog/content CTR benchmark: ~2-5%
- Affiliate landing page conversion rate benchmark: ~1-3%
Flag each metric as **on-target**, **below**, or **above**, with the size of the gap.

### Step 3: Diagnose Root Causes with Evidence
Apply three diagnostic lenses, and for each, cite the specific evidence pointing to it (don't just assert):
1. **Offer-Market Fit** — Is the promoted product actually what this audience wants? Look for mismatches between content topic/audience intent and offer positioning.
2. **Traffic-Content Match** — Does content format fit the channel and traffic source? (e.g., a long comparison post pushed via short-form video traffic will leak visitors before conversion.)
3. **Funnel-Leak Analysis** — Walk the funnel stage by stage (impression → click → landing page view → offer click → conversion) and identify the stage with the steepest drop-off relative to benchmark.

### Step 4: Prioritize Improvements by Impact-to-Effort
For each diagnosed issue, score estimated impact (High/Med/Low) and implementation effort (High/Med/Low). Sort recommendations by best impact-to-effort ratio first — cheap, high-impact fixes surface at the top.

### Step 5: Create the Iteration Plan
Turn top-priority fixes into concrete next actions, each mapped to the skill/stage that should execute it (e.g., "rewrite intro hook" → S2/S3 content skill; "test new offer angle" → S4 `grand-slam-offer`; "diversify traffic channel" → S5 distribution skill). Attach a measurable success metric and a re-check timeframe to each action.

### Step 6: Self-Validate
Before delivering, check: Are root causes backed by actual evidence from the data provided, or are they speculative? Label speculative diagnoses clearly as hypotheses to test, not confirmed causes. Ensure every recommendation has a measurable success metric attached.

## Output Format

```
## Retrospective: <Campaign/Content Name>

### Results vs. Expectations
| Metric | Actual | Expected/Benchmark | Status |
|---|---|---|---|

### Root Cause Diagnosis
| Issue | Framework | Evidence | Severity |
|---|---|---|---|

### Prioritized Improvement Actions
| Action | Impact | Effort | Owning Skill/Stage | Success Metric |
|---|---|---|---|---|

### Next Iteration Plan
1. ...
2. ...
- Re-check date: ...
```

## Error Handling

- **Insufficient data to diagnose:** State clearly which metrics are missing and what tracking to add (point to `conversion-tracker`) before a confident diagnosis is possible; give a best-effort hypothesis-only analysis in the meantime.
- **No stated expectations or benchmarks:** Fall back to the stated industry benchmarks and flag that they're generic, not personalized.
- **User wants blame, not diagnosis:** Redirect toward root causes and fixable levers rather than framing the retro around what the user "did wrong."
- **Multiple plausible root causes with no way to isolate:** List all plausible causes, rank by likelihood given the evidence, and recommend the cheapest test to isolate the true cause (e.g., A/B test one variable at a time).
- **Results are actually good but user feels they underperformed:** Reframe against realistic benchmarks and highlight what's working so it isn't accidentally "fixed" away.

## Examples

**Example 1:** "My blog post got 5k visits but only 3 affiliate clicks, what went wrong?" → Run funnel-leak analysis, likely diagnose a traffic-content or CTA-placement mismatch, and produce a prioritized fix list (e.g., add mid-content CTA, tighten offer relevance).

**Example 2:** "Review this month's TikTok-to-landing-page funnel performance" → Compare each funnel stage against benchmarks, diagnose whether the drop-off is at video-to-click or click-to-conversion, and recommend the higher-impact fix first.

**Example 3:** "I want a monthly retro process for my affiliate site" → Set up a recurring checklist based on this workflow's six steps and recommend a cadence and minimum metrics to track each cycle.

## Suggested Next Skills

- `conversion-tracker` (S6) — set up the tracking needed to make future retrospectives data-driven
- `funnel-planner` (S4) — redesign funnel stages flagged as high-leak
- `grand-slam-offer` (S4) — rework the offer when offer-market fit is the diagnosed root cause
- `content-research-brief` (S1) — regenerate a sharper content brief when traffic-content mismatch is diagnosed

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
