---
name: email-automation-builder
description: Design multi-sequence email automations with branching if/then logic (opened, clicked, purchased, inactive) instead of a flat drip — covering welcome flows, nurture flows, win-back flows, and cart-abandonment flows, with platform-specific setup steps. Use when the user wants conditional email logic, wants to upgrade a linear drip sequence into a real automation, or names a specific ESP (ConvertKit, Mailchimp, ActiveCampaign, Beehiiv).
stage: S7 Automation
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Email Automation Builder

Build branching email automations that react to what a subscriber actually does —
opens, clicks, purchases, or silence — instead of blasting everyone the same fixed
sequence. This is the upgrade path from a simple linear drip: it adds decision
points, exit conditions, and multiple parallel branches, then hands back a full
flow diagram, every email's copy, and ESP-specific setup instructions.

## When to Use

- User wants "email automation," "email funnel," or a "conditional sequence" rather than a flat drip
- User is building a welcome series, nurture flow, win-back campaign, or cart-abandonment sequence
- User names a specific ESP (ConvertKit, Mailchimp, ActiveCampaign, Beehiiv) and wants flow logic mapped to it
- User already has a linear drip sequence from an earlier skill and wants to add branching on top of it
- User asks "what happens if they don't open the email" or similar behavioral-routing questions

## Input Schema

```
{
  product_name: string,          # REQUIRED — what's being promoted
  affiliate_url: string,         # REQUIRED — the link driving the CTA
  audience: string,              # REQUIRED — who is on this list
  flow_type: string,             # OPTIONAL — "welcome" | "nurture" | "winback" | "cart_abandon" | "reengagement"
                                  # default: "welcome"
  email_tool: string,            # OPTIONAL — "convertkit" | "mailchimp" | "activecampaign" | "beehiiv" | generic
  num_emails: number,            # OPTIONAL — 5-12, default 7
  lead_magnet: string,           # OPTIONAL — what they opted in for
  existing_drip: string          # OPTIONAL — paste an existing linear sequence to upgrade
}
```

## Workflow

### Step 1: Pick the flow template
Match `flow_type` to a base skeleton:
- **Welcome**: entry → deliver value/lead magnet → wait → value email → branch on open → soft sell vs. re-engagement → continue selling to openers
- **Nurture**: entry → educational series → branch on affiliate-link click → move clickers to a sales sequence, keep non-clickers in nurture → thank-you branch for buyers
- **Win-back**: entry trigger = 30+ days inactive → "we miss you" → wait → value reminder → branch on re-engagement → move re-engaged back to nurture, send "last chance" to the rest → sunset (remove from list) if still silent

### Step 2: Define triggers and exits
For the chosen flow, specify: the **entry trigger** (new subscriber, tag added, purchase event, N days inactive), the **exit conditions** (purchase, unsubscribe, moved to a different flow), and the **branch conditions** that will split subscribers mid-flow (opened / didn't open, clicked / didn't click, purchased / didn't purchase).

### Step 3: Build the decision tree
After each key email, add a branch: "Did they open email N?" → yes-path and no-path, each continuing independently. Typical pattern is 2-3 branch points per flow — more than that becomes unmanageable to both write and read as a diagram.

### Step 4: Write every email in every branch
Each email needs: subject line (40-60 characters), preview text (80-100 characters), body copy (200-400 words), one clear CTA, and an FTC disclosure line if the email contains the affiliate link.

### Step 5: Set wait times between sends
Use flow-appropriate pacing, adjusted for how engaged the audience already is:
- Welcome: 0, 1, 2, 3, 5, 7, 10 days
- Nurture: 2, 4, 7, 10, 14 days
- Win-back: 0, 3, 7, 14 days

### Step 6: Assemble the deliverable
Output an ASCII flow diagram of the whole automation (including branches), the full email copy grouped by branch, and platform-specific setup instructions if an ESP was named — otherwise generic trigger/wait/branch logic the user can map onto any tool.

### Step 7: Self-validate before delivering
- Every branch path ends somewhere (no dead ends)
- Every email in every branch is complete (subject, body, CTA)
- Wait times sum to a sensible total flow duration
- FTC disclosure present wherever the affiliate link appears
- Branch conditions are simple booleans (opened/clicked/purchased — yes/no)

Fix silently before showing the user; don't narrate the checklist.

## Output Format

```
## Email Automation: [Product] — [Flow Type]

### Flow Overview
- Total emails: N | Branches: N | Span: N days

### Flow Diagram (ASCII)
[trigger] → [email 1] → wait Nd → [email 2] → branch: opened?
   ├─ yes → [email 3a] → ...
   └─ no  → [email 3b] → ...

### Email Content (by branch)
**Email 1 — [name]**
Subject: ...
Preview: ...
Body: ...
CTA: ...

### Setup Instructions ([ESP name])
1. ...
2. ...

### Tags & Segments
- Tag: ... — applied when ...
```

## Error Handling

- **No product/affiliate link given:** Ask for product name and affiliate URL before writing any copy — the emails can't be written without them.
- **Unnamed or unsupported ESP:** Deliver generic trigger/wait/branch logic that maps to any automation builder, and say so explicitly.
- **User requests more than ~12 emails in one flow:** Cap at 7 with branches and suggest chaining a second flow rather than one sprawling sequence.
- **Upgrading an existing linear drip:** Keep the original email copy intact; only add branch points (typically after email 2 for opens, after email 4 for clicks, after email 5 for a purchase-detection exit).

## Examples

**Example 1:** "Build a welcome automation for HeyGen, my audience downloaded an AI tools guide" → 7-email welcome flow: deliver guide, value email, branch on open at email 2, soft-sell branch vs. re-engagement branch, continuing to email 7, plus ConvertKit setup steps.

**Example 2:** "Add automation logic to the email drip you wrote me earlier" → keeps the existing copy, layers in an opened/not-opened branch after email 2, a clicked/didn't-click branch after email 4, and a purchase exit after email 5.

**Example 3:** "Win-back sequence for subscribers inactive 30 days, I promote Semrush" → 4-email win-back flow with a curiosity-based reopener, a value email, a branch on re-engagement, and a sunset step for non-responders after 7 days.

## Suggested Next Skills

- `conversion-tracker` (S6) — instrument the affiliate links inside the flow so branch conditions and revenue-per-subscriber are measurable
- `multi-program-manager` (S7) — once several automations exist across programs, compare which flows earn the most per subscriber
- `paid-ad-copy-writer` (S7) — drive cold traffic into the top of this automation via paid ads

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
