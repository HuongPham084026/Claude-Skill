---
name: traffic-analyzer
description: Evaluate website traffic health, engagement metrics, and traffic-source mix for one or more domains, producing a 0-100 score and verdict for affiliate promotion, competitor analysis, or advertiser evaluation. Use when the user wants to vet a site's real traffic before partnering with it, compare competitor domains side-by-side, or judge whether a site is a credible advertising/guest-post target.
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Traffic Analyzer

Assess whether a domain's traffic is real, healthy, and relevant before the
user relies on it — as an affiliate promotion channel, a competitor to study,
or an advertiser/partner to evaluate. Produces a weighted 0-100 health score
and a plain-language verdict, using SimilarWeb-style data when available.

## When to Use

- User wants to vet a site's traffic before pitching a partnership, guest post, or ad placement
- User is comparing their own site against 1-4 competitor domains
- User is deciding whether to trust traffic claims made by a potential advertiser or affiliate partner
- Feeds into `competitor-spy` or `affiliate-program-search` when program legitimacy is in question

## Input Schema

```
{
  domains: string[]              # required — 1 to 5 domains to analyze
  purpose: string                 # optional — "affiliate_promotion" | "competitor_analysis" | "advertiser_evaluation"
}
```

## Workflow

### Step 1: Pull Traffic Data
- Primary: SimilarWeb API (or equivalent traffic-intelligence API if configured) for global rank, monthly visits, pages/visit, bounce rate, traffic source split
- Fallback: `web_search` for `"<domain>" traffic estimate similarweb`, cross-referenced with `"<domain>" monthly visitors` — clearly label as estimated when API data isn't available

### Step 2: Analyze Core Metrics
For each domain, capture:
- Global/category rank
- Monthly visits (and trend direction if available: growing/flat/declining)
- Pages per visit (engagement depth)
- Bounce rate
- Traffic source breakdown: direct / search / social / referral / paid

### Step 3: Score Traffic Health

| Dimension | Weight | What it measures |
|---|---|---|
| Rank | 20% | Relative authority within category |
| Volume | 25% | Absolute monthly visits, scaled to niche size |
| Engagement | 25% | Pages/visit and bounce rate combined |
| Source Diversity | 15% | Not overly dependent on one channel (e.g., 90% paid = fragile) |
| Brand Recognition | 15% | Direct-traffic share as a proxy for real brand demand |

### Step 4: Apply Verdict Bands
- **80-100 — Excellent**: established brand, strong engagement, diversified sources
- **60-79 — Good**: solid, credible traffic with minor gaps
- **40-59 — Moderate**: usable but with real caveats — investigate the gap before relying on it
- **20-39 — Weak**: traffic is thin or overly reliant on one channel
- **0-19 — Red Flag**: very low, declining, or suspicious traffic (e.g., near-100% paid or direct with no organic search presence)

### Step 5: Interpret for the Stated Purpose
- **Affiliate promotion**: does this site's audience match the product being promoted, and is the traffic real enough to trust conversion claims?
- **Competitor analysis**: where is their traffic coming from that the user isn't capturing yet?
- **Advertiser evaluation**: are traffic claims in the media kit consistent with what the data shows?

### Step 6: Compare Side-by-Side (if multiple domains)
Build a comparison table normalizing all domains on the same metrics and
scoring rubric so relative strength is immediately visible.

## Output Format

```
## Traffic Analysis: [Domain(s)]

### Traffic Health Score: X/100 — [Verdict Band]

| Metric | Value |
|---|---|
| Global Rank | ... |
| Monthly Visits | ... (trend: ...) |
| Pages/Visit | ... |
| Bounce Rate | ... |
| Traffic Sources | Direct X% / Search X% / Social X% / Referral X% / Paid X% |

### Interpretation ([purpose])
[2-4 sentences tailored to affiliate promotion / competitor analysis / advertiser evaluation]

### If Comparing Multiple Domains
| Domain | Rank | Monthly Visits | Score | Verdict |
|---|---|---|---|---|
| ... | ... | ... | X/100 | ... |

### Data Quality Note
[State whether figures came from API or web-search estimate]
```

## Error Handling

- **No API access**: fall back to `web_search` estimates and prominently label all figures as directional, not precise.
- **Domain too small/new to have traffic data**: state this explicitly rather than fabricating numbers; treat as a data gap, not a zero score.
- **Traffic sources sum to less than ~95% or look inconsistent across sources**: flag the discrepancy rather than silently normalizing it.
- **User is evaluating a domain for a partnership and traffic looks inflated/suspicious**: call this out directly as a red flag with the specific anomaly (e.g., 95% direct traffic with no search presence is atypical for organic sites).

## Examples

**Example 1:** "Is this affiliate network's top-listed site actually getting real traffic?" → Pulls SimilarWeb-style data, finds heavy paid-traffic dependency and low pages/visit, scores 35/100 — Weak, flags the site as unreliable for organic-audience promotion.

**Example 2:** "Compare my blog's traffic against my top 3 competitors" → Analyzes all 4 domains on the same rubric, returns a side-by-side table showing where competitors out-rank the user and in which traffic channel.

## Suggested Next Skills

- `competitor-spy` (S1) — go deeper on a competitor domain once its traffic is confirmed healthy
- `affiliate-program-search` (S1) — cross-check a program's advertised reach against real traffic data
- `content-angle-ranker` (S1) — target the traffic channels/formats shown to be working for top-scoring domains

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
