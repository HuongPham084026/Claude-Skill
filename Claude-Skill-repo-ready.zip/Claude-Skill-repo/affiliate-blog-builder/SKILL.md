---
name: affiliate-blog-builder
description: Write a complete, SEO-structured affiliate blog post (review, tutorial, or listicle) from a product or topic, including proper heading structure, internal linking hooks, and FTC-style disclosure. Use when the user wants a full blog article for their affiliate site, not just a social post.
stage: S3 Blog & SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Affiliate Blog Builder

Write a complete, publish-ready affiliate blog post — review, tutorial, or
listicle — with proper SEO structure, genuine depth, and compliant disclosure.
Long-form blog content is the highest-converting *free* traffic source in
affiliate marketing (organic search converts higher than social), but only if
it's genuinely useful, not thin AI filler.

## When to Use

- User wants a full blog article, not a social post
- User is building or growing an affiliate site/blog
- User wants a product review, tutorial, or listicle post
- User wants content designed to rank in search, not just get social engagement

## Input Schema

```yaml
post_type: string             # REQUIRED — "review" | "tutorial" | "listicle"
topic: string                 # REQUIRED — product name or topic
target_keyword: string        # OPTIONAL — primary SEO keyword to target
word_count: number             # OPTIONAL, default: 1500 (800-3000)
audience: string               # OPTIONAL
research_brief: object         # OPTIONAL — output from content-research-brief, if available
```

## Workflow

### Step 1: Research (if no research_brief provided)

Search "[topic] review", "[topic] pricing features", and "[topic] alternatives"
to gather real, current information. Never write a review from assumed/training-data
knowledge alone — pricing and features change.

### Step 2: Choose the Structure by Post Type

**Review:**
1. Quick verdict (for skimmers)
2. What it is / who it's for
3. Key features (with real detail, not a bullet list of buzzwords)
4. Pricing breakdown
5. Pros and cons (genuine cons required)
6. Who should NOT buy this
7. Final verdict + CTA

**Tutorial ("How to X using Y"):** highest trust-to-conversion format because it
demonstrates real value before asking for anything.
1. What you'll achieve (the outcome, stated concretely)
2. What you need before starting
3. Step-by-step walkthrough (numbered, each step actionable)
4. Common mistakes / troubleshooting
5. Next steps + tool CTA (introduced naturally within the workflow, not bolted on)

**Listicle ("X Best Tools for Y"):**
1. Quick-comparison table at the top
2. Each item: what it does best, pricing, who it's for, one limitation
3. Selection methodology note (how items were chosen — builds trust)
4. Final pick(s) by use case

### Step 3: Write for Depth, Not Length

- Every claim should be specific (a number, a screenshot description, a concrete
  example) — vague AI-filler ("this powerful tool helps you achieve your goals")
  gets penalized by both readers and search engines
- Include at least one genuinely critical point, even in a review — 100% positive
  reviews read as untrustworthy and convert worse
- Match `word_count` but never pad — cut rather than repeat

### Step 4: SEO Structure

- Title includes `target_keyword` naturally (or the product name if no keyword given)
- One H1 (the title), logical H2/H3 hierarchy matching the post_type structure above
- First 100 words answer the core question directly (for search snippets)
- Meta description: 150-160 chars, includes keyword, states the value clearly

### Step 5: Internal Linking Hooks

Flag 2-3 places in the post where an internal link to related content would make
sense (e.g., "link to comparison post here", "link to getting-started guide here")
— even without knowing the user's full site structure, marking these speeds up
their SEO work later.

### Step 6: Add Disclosure

Include a clear, compliant affiliate disclosure near the top of the post (not
buried in a footer only) per standard FTC-style guidance.

### Step 7: Self-Validation

- [ ] At least one genuine limitation/con is included, even in a positive review
- [ ] No vague filler claims — every benefit is backed by a specific detail
- [ ] Heading structure is logical and complete (H1 → H2 → H3)
- [ ] Word count is close to target without padding
- [ ] Disclosure is present near the top
- [ ] Internal linking opportunities are flagged

## Output Format

Full blog post in Markdown with:
- Title (H1)
- Meta description (as a note, not part of the rendered post)
- Disclosure line
- Full body per the post_type structure
- `[Internal link opportunity: ...]` notes inline where relevant
- CTA at the end

## Error Handling

- **No target keyword given**: Use the product/topic name as the working keyword; note that keyword research (`keyword-cluster-architect`) would sharpen targeting.
- **Product has almost no public info**: Be transparent in the post about limited public data rather than inventing specifics.
- **User wants only positive claims, no cons**: Push back — explain that reviews with zero cons convert worse and can violate platform/FTC honesty expectations; include at least one genuine trade-off.
- **Word count requested is very low (<500) for a tutorial**: Flag that tutorials need enough room for real steps; suggest listicle or review format instead, or confirm a shorter scope.

## Examples

**Example 1:** "Write a review of [AI tool] for my blog, ~1500 words" → research pricing/features, quick verdict, feature breakdown, honest pros/cons, who shouldn't buy, disclosure near top.

**Example 2:** "Tutorial: how to build a landing page using [website builder]" → outcome stated upfront, prerequisites, numbered steps with screenshots-description cues, troubleshooting section, natural CTA at the point where the tool is genuinely needed.

**Example 3:** "Best 5 AI writing tools for solopreneurs" listicle → comparison table, each tool's best-fit use case and one limitation, methodology note, final picks by scenario (budget / power user / beginner).

## Suggested Next Skills

- `content-research-brief` (S2) — research before writing, for stronger data-backed content
- `keyword-cluster-architect` (S3) — find the right target keyword and related cluster
- `comparison-post-writer` (S3) — for head-to-head "X vs Y" content instead
- `content-decay-detector` (S3) — refresh this post later as pricing/features change
- `internal-linking-optimizer` (S6) — wire up the flagged internal links

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
