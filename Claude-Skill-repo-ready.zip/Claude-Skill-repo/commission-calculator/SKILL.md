---
name: commission-calculator
description: Project realistic monthly and year-one affiliate earnings from traffic estimates, platform-specific conversion benchmarks, and a program's commission structure. Use when the user wants to know how much money an affiliate program could realistically make them, is comparing programs by earning potential, or has an income goal and needs to know how much traffic it requires.
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Commission Calculator

Turn traffic and program terms into a realistic earnings forecast before the
user invests months of content creation. Uses industry-standard conversion
benchmarks by platform, compounds recurring commissions over time, and flags
income goals that don't match the traffic available.

## When to Use

- User wants to estimate earnings from a specific affiliate program
- User is comparing 2+ programs and needs a side-by-side revenue projection
- User has an income goal ("I want $2,000/month") and needs to know required traffic/sales
- Chaining after `affiliate-program-search` to validate the top pick financially

## Input Schema

```
{
  program: {
    commission_type: string    # "recurring" | "one_time" | "tiered"
    commission_value: string   # % or flat amount
    cookie_days: number
    product_price: number      # optional if unknown — will be researched
  },
  traffic: {
    monthly_visitors: number   # or subscribers/followers depending on platform
    platform: string           # "blog" | "youtube" | "email" | "tiktok" | "instagram"
  },
  income_goal: number           # optional — target monthly revenue
  growth_scenario: string       # optional — "flat" | "moderate" | "aggressive" (default: flat)
}
```

## Workflow

### Step 1: Gather Inputs
Collect program commission terms, current or projected traffic, and platform
type. If `product_price` is missing, `web_search` the product's pricing page.

### Step 2: Apply Platform Conversion Benchmarks

| Platform / Content Type | Click-through | Conversion |
|---|---|---|
| Blog product review | 3-6% | 2-5% |
| YouTube review video | 5-10% | 3-6% |
| Email dedicated send | 10-20% | 3-8% |
| Social post w/ link in bio | 1-3% | 1-3% |

Use the low end of the range for new/unproven audiences, mid-to-high end for
established, trust-built audiences.

### Step 3: Calculate Earnings
1. Visitors/subscribers × click-through rate = clicks
2. Clicks × conversion rate = sales
3. Sales × commission value = one-time revenue for the period
4. For recurring commissions: compound retained customers month-over-month
   using a reasonable churn assumption (state the assumption explicitly, e.g.
   5% monthly churn) rather than assuming 100% retention forever
5. Apply `growth_scenario` multiplier to traffic across the 12-month projection if requested

### Step 4: Reverse-Calculate for Income Goals
If `income_goal` is set, work backward: required sales = goal / commission
value, then required clicks = sales / conversion rate, then required traffic =
clicks / click-through rate. Present this as "what you need" alongside "what
you currently have."

### Step 5: Compare Across Programs
If multiple programs are being evaluated, build a side-by-side table showing
month 1, month 6, month 12, and year-one total for each — recurring
commissions often look worse in month 1 but dramatically better by month 12.

### Step 6: Reality-Check the Output
- Flag if projected earnings assume unrealistic conversion (e.g., using 8%
  conversion for a brand-new audience with no trust built)
- Flag if the income goal requires traffic the user doesn't currently have,
  and state the gap plainly

## Output Format

```
## Commission Projection: [Program Name]

### Assumptions
- Traffic: [X]/month on [platform]
- Conversion benchmark used: [X]% CTR × [X]% conversion (source: platform benchmark)
- Commission: [type] at [value]
- Churn assumption (if recurring): [X]%/month

### Monthly Earnings Projection

| Month | New Sales | Active Customers | Revenue |
|---|---|---|---|
| 1 | ... | ... | $... |
| 6 | ... | ... | $... |
| 12 | ... | ... | $... |

**Year 1 total: $[X]**

### If Comparing Programs
| Program | Month 1 | Month 6 | Month 12 | Year 1 Total |
|---|---|---|---|---|
| ... | $... | $... | $... | $... |

### To Hit Your Goal of $[X]/month
You need approximately [X] clicks/month, which requires [X] visitors/month at
current conversion rates — that's [Xx] your current traffic.

### Reality Check
[Honest note on whether this is achievable in the stated timeframe]
```

## Error Handling

- **Missing product price**: `web_search` the pricing page; if still unavailable, ask the user or use category-average pricing and label it as an estimate.
- **Traffic numbers not provided**: ask for current visitors/subscribers, or offer to project from zero using typical new-creator growth curves.
- **Unrealistic income goal**: don't inflate conversion assumptions to make the math work — state the required traffic honestly, even if it's a large multiple of current traffic.
- **Recurring commission with unknown churn**: default to a conservative 5-8% monthly churn assumption and state it explicitly as an assumption, not fact.

## Examples

**Example 1:** "How much could I make promoting this $49/mo SaaS tool with my 10k blog visitors?" → Applies blog benchmarks (3-6% CTR, 2-5% conversion), compounds the recurring commission with a stated churn assumption, returns month 1/6/12 projections.

**Example 2:** "I want $3,000/month from affiliate income — what traffic do I need?" → Reverse-calculates required clicks and visitors from the target program's commission value, compares against user's current traffic, states the gap.

## Suggested Next Skills

- `affiliate-program-search` (S1) — if projected earnings are too low, look for better-paying alternatives in the niche
- `purple-cow-audit` (S1) — validate the product is worth the projected effort before committing
- `traffic-analyzer` (S1) — check whether the traffic assumptions are realistic for the target platform/domain

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
