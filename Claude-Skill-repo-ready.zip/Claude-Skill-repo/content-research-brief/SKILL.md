---
name: content-research-brief
description: Research a topic by collecting real sources, extracting data points and quotes, and synthesizing multiple unique, source-backed content angles before writing anything. Use before writing any article, blog post, or long-form content, or whenever content needs current data/stats instead of generic AI claims.
stage: S2 Content (research foundation for all content skills)
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Research Brief

Research a topic by collecting 5-10 real source articles, tagging them by theme,
extracting key data points, and synthesizing unique content angles. The output is a
structured research brief that any downstream content skill can consume.

**The problem this solves:** Most AI-written affiliate/marketing content is generic
because it's written from the model's training data — not from real, current sources.
This skill forces research-first content creation: find real articles, extract real
data, then write from those sources. The result is content with specific stats, real
quotes, and current information that readers (and search engines) actually value.

## When to Use

- Before writing any article, blog post, or long-form content
- When you need current data and stats about a topic (not just AI-generated claims)
- When creating comparison content (need real feature/pricing data from sources)
- When writing about a product launch, funding round, or industry trend
- After identifying a trending topic — research it deeper
- When you want unique angles: multiple sources → multiple different content pieces

## Input Schema

```yaml
topic: string                  # (required) "HeyGen AI video tool", "email marketing trends 2026"
source_count: number           # (optional, default: 7) How many sources to collect (3-10)
source_types: string[]         # (optional, default: ["news", "blog"])
                               # Options: "news" | "blog" | "linkedin" | "youtube" | "reddit" | "academic"
freshness: string              # (optional, default: "month") "day" | "week" | "month" | "year" | "any"
product: object                # (optional) Focus research on a specific product
  name: string
  url: string
language: string               # (optional, default: "en") "en" | "vi" | any ISO 639-1 code
angle_count: number             # (optional, default: 3) How many unique content angles to generate
```

## Workflow

### Step 1: Search for Sources

Run multiple searches to find diverse, high-quality sources:
- Primary: search "[topic]"
- If "news" requested: search "[topic] news [current year]"
- If "blog" requested: search "[topic] blog review analysis"
- If "linkedin" requested: search site:linkedin.com for the topic
- If "youtube" requested: search site:youtube.com for the topic
- If "reddit" requested: search site:reddit.com for the topic (real user opinions)
- If "academic" requested: search "[topic] research study data statistics"
- If a specific product is given: search reviews, alternatives/comparisons, pricing, and recent news for it

Collect 15-20 search results, then filter down to `source_count` best sources.

### Step 2: Fetch and Extract Source Content

For each selected source: fetch the full article text (if fetch fails/paywalled, use the search snippet and note the limitation). Extract:
- Title, URL, published date (if available)
- Key data points: stats, numbers, percentages, dollar amounts
- Key quotes: noteworthy statements from experts or users
- Main argument/thesis of the source
- What's unique about this source vs. others

### Step 3: Auto-Tag Sources

Tag each source with 1-3 theme tags such as: AI, Funding, SaaS, Tools, Trends, Startup, Growth, Industry, Pricing, Comparison, Tutorial, Opinion — based on keyword triggers in the content.

### Step 4: Extract Key Data Points

From all sources combined, build a master list of stats & numbers (revenue/valuation, user counts, growth rates, market size, pricing), quotes & insights (expert opinions, testimonials, founder statements), and facts & features (mentioned across multiple sources, recent updates, competitive positioning).

### Step 5: Synthesize Unique Angles

Generate `angle_count` unique content angles:
1. Each angle must use a DIFFERENT primary source as its foundation
2. All angles use ALL sources as context (richer data)
3. Each angle must have a distinct hook and perspective
4. At least one angle should be contrarian or non-obvious

For each angle produce: title, primary source, hook (opening line), 2-3 supporting data points, best format suggestion (LinkedIn post / blog article / TikTok script / Twitter thread), and what makes it different from generic AI-written content.

### Step 6: Compile Research Brief

Organize everything into the structured brief (see Output Format) that downstream skills can consume directly.

### Step 7: Self-Validation

- [ ] All sources are real URLs (not hallucinated)
- [ ] Data points are attributed to specific sources
- [ ] At least 3 sources were successfully fetched (not just search snippets)
- [ ] Angles are genuinely different from each other (not rephrased versions)
- [ ] Tags accurately reflect source content
- [ ] Brief includes both positive and critical/balanced perspectives

## Output Format

```markdown
## Content Research Brief: [Topic]

📚 [X] sources collected | [Y] fully fetched | Freshness: [month]
🏷️ Top tags: AI (5), Tools (3), Pricing (2), Comparison (2)

### 📰 Sources
| # | Title | Tags | Date | Status |
|---|-------|------|------|--------|

### 📊 Key Data Points (from sources)
**Stats:** [stat] — Source: [#]
**Quotes:** "[quote]" — [Person], [Role] (Source: [#])
**Key Facts:** [fact] — mentioned in [X] sources

### 🎯 Content Angles (ready to write)
#### Angle 1: "[Title]"
- Primary source: [#] — [title]
- Hook: "[opening line]"
- Key data: [stat 1], [stat 2]
- Best format: [platform]
- Unique value: [why this isn't generic]

## 🚀 Next Steps
1. Pick an angle and write the content
2. Combine angles into an atomized content set
3. Add a data visual/infographic from the key stats
```

## Error Handling

- **Topic too vague:** Ask user to narrow it down (e.g., "email marketing" → "email marketing automation tools for solopreneurs").
- **Few sources found:** If <3 sources, note the limited depth and suggest broadening the topic.
- **Most sources paywalled:** Use search snippets, note reduced detail.
- **Sources all one-sided:** Flag the bias explicitly and suggest adding "reddit" or "opinion" source types.
- **Outdated sources:** Widen the freshness window and note the gap.
- **Non-English topic:** Research in the specified language; note if source diversity is limited.

## Examples

**Example 1:** "Research HeyGen for a LinkedIn post" → collect 7 sources (news, blog, LinkedIn), tag by theme, extract key stats and 3 distinct angles (funding news angle, personal-test angle, industry-disruption angle).

**Example 2:** "Brief me on email marketing trends for a comparison blog post" → 8 sources on AI personalization, interactive email, privacy changes, deliverability; angle focused on head-to-head comparison with real differentiators.

**Example 3:** "Research what people are really saying about [Product] on Reddit" → Reddit threads + blog reviews; unique angle built from the gap between marketing claims and real user complaints.

## Suggested Next Skills

- `viral-post-writer` / `tiktok-script-writer` / `twitter-thread-writer` (S2) — turn an angle into a platform post
- `affiliate-blog-builder` / `comparison-post-writer` (S3) — turn an angle into long-form content
- `infographic-generator` (S2) — visualize the key stats

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), inspired by the Affitor content-pipeline approach (Topic → Search → Select sources → Synthesize → Write with context). Repackaged as a standalone Claude Skill.
