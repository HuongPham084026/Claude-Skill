---
name: product-showcase-page
description: Builds a long-form, deep-dive single-product showcase page (self-contained HTML) with feature breakdowns, use-case walkthroughs, pricing comparisons, testimonials, and an FAQ accordion, aimed at warm traffic that needs more convincing than a short landing page provides. Use when the user wants a richer, more thorough product page than a standard landing page — a "spotlight," "deep dive," or "full feature" page for one affiliate product.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Product Showcase Page

Produces an extended, single-product deep-dive page as one self-contained HTML
file. Where `landing-page-creator` optimizes for a fast decision, this skill is
for warm or research-minded traffic — visitors who want to see the full feature
set, real use cases, and side-by-side pricing before they click through. It's
longer, more detailed, and built to answer every objection on the page itself.

## When to Use

- User wants a thorough product page, not just a short landing page
- Traffic source is warm (email list, retargeting, existing audience) and needs depth rather than urgency
- User asks for a "product spotlight," "deep dive," or "full feature page"
- The affiliate product has enough features/use cases to justify a long-form page

## Input Schema

```
{
  product: {                 # REQUIRED
    name: string,
    description: string,
    url: string,             # affiliate link
    reward_value: string,
    pricing_tiers: [{ name, price, features: string[] }]
  },
  use_cases: string[],       # OPTIONAL — 3-5 concrete scenarios; auto-researched if omitted
  competitors: [{ name, price, key_diff }],  # OPTIONAL — for the comparison table
  testimonials: [{ quote, name, result }],   # OPTIONAL
  target_audience: string,   # OPTIONAL
  color_scheme: string       # OPTIONAL — default blue (#2563eb)
}
```

## Workflow

### Step 1: Research the Product in Depth
Search for the product's full feature list, pricing tiers, common use cases,
existing reviews/testimonials, direct competitors, and the objections people
raise before buying. Organize findings into: 6-12 core features, 3-5 use cases,
2-4 pricing tiers, comparison points against 1-2 competitors, and 5-8 FAQ
answers pulled from real buyer questions.

### Step 2: Plan the Page Architecture
Longer than a standard landing page, in this order: disclosure → hero → problem
statement (what pain the visitor has) → product overview → full feature grid
(icons + short benefit copy per feature) → use-case section (3-5 scenarios with
before/after framing) → social proof bar (ratings, user counts, press) →
pricing/plan comparison table → 2-3 testimonials → FAQ accordion (5-8 Q&As) →
final CTA block → footer. Plan for 4-5 CTA placements total, spaced through the
page rather than clustered at the top.

### Step 3: Write the Full HTML
- Inline CSS only, system fonts, mobile-first responsive layout.
- Alternate section background shades to create visual rhythm across a long page.
- Icons and avatars built from pure CSS/SVG shapes — no external image assets.
- Minimal JavaScript, used only for the FAQ accordion.
- Disclosure visible above the hero section.
- Set the page to non-indexable (`noindex`) if it's meant as a private/traffic-source-specific page rather than a public SEO page — otherwise omit.
- Every affiliate link opens `target="_blank" rel="noopener"`.
- Aim for genuine depth: this page should read like a resource, not a squeeze — expect a substantially longer HTML output than a short landing page.

### Step 4: Output
Three parts: page summary, full HTML in a fenced block, deploy instructions
(same static-host options as other landing pages: open locally, Netlify Drop,
Vercel, GitHub Pages).

### Step 5: Self-Check
- Disclosure above the hero
- 4+ CTAs distributed through the page
- No external resources
- Footer credit line present
- Comparison table (if used) has accurate, sourced pricing

## Output Format

```
## Page Summary
- Product: ...
- Use cases covered: ...
- Competitors compared: ...
- CTA count: ...
- Sections: ...

## HTML
```html
<!-- complete self-contained file -->
```

## Deploy
1. Save as `[product-slug]-showcase.html`
2. Preview locally, then deploy to Netlify Drop / Vercel / GitHub Pages
3. Link to it from bio hub or paid traffic campaigns
```

## Error Handling

- **No product provided:** ask for the product name, or use one already established earlier in the conversation.
- **Not enough features to fill a long page:** research further before writing; if the product is genuinely simple, recommend `landing-page-creator` instead and explain why a short page fits better.
- **No competitor data:** search for 1-2 alternatives; if none exist, drop the comparison table and expand the use-case section instead.
- **No real testimonials available:** use clearly-labeled illustrative examples rather than fabricated attributed quotes, or omit the section.
- **Pricing not published:** replace fixed prices with "Check current pricing" CTAs rather than guessing numbers.

## Examples

**Example 1:** "Build a full showcase page for [an AI writing tool] for my email list" → long-form page with 8 features, 4 use cases, pricing table, FAQ, 5 CTAs, sent as a warm-traffic destination.

**Example 2:** "I need a deep-dive page comparing pricing tiers for [a SaaS tool]" → showcase page with a detailed plan-comparison table as the centerpiece, feature grid supporting it.

**Example 3:** "Make a spotlight page for [a course]" with no other detail → skill researches the product, infers 3-5 use cases and audience, builds the full page and flags any guessed sections.

## Suggested Next Skills

- `bio-link-deployer` (S5) — publish the showcase page URL to a link hub
- `email-drip-sequence` (S5) — send warm subscribers to this page mid-sequence
- `guarantee-generator` (S4) — add a personal guarantee section to strengthen the close
- `value-ladder-architect` (S4) — position this page as the "core" rung in a larger funnel

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
