---
name: competitor-spy
description: Analyze competitor affiliate sites, YouTube channels, and social profiles to reverse-engineer which programs they promote, what content drives their traffic, and which content gaps you can exploit. Use when the user wants to know what's working in a niche, has a specific competitor in mind, or asks "how do top affiliates in X make money?"
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Competitor Spy

Analyze competitor affiliate sites, YouTube channels, and social profiles to
surface which programs they promote, what content drives their traffic, and
which strategies are worth replicating. Outputs an actionable reverse-engineering
report so you can skip years of trial and error.

## When to Use

- User wants to know what programs are working in a specific niche
- User has a competitor site/channel in mind and wants to understand their strategy
- User is entering a new niche and wants a shortcut to what works
- User wants to find underserved content gaps a competitor hasn't covered
- User asks "how do top affiliates in [niche] make money?"

## Input Schema

```
{
  competitor_url: string      # (optional) Direct URL to competitor site, channel, or profile
  niche: string                # (optional) Niche to analyze if no specific competitor given
  platform: string             # (optional) "blog" | "youtube" | "tiktok" | "twitter" | "newsletter"
  depth: string                # (optional, default: "standard") "quick" | "standard" | "deep"
  focus: string                # (optional) "programs" | "content" | "traffic" | "all"
}
```

## Workflow

### Step 1: Identify Competitors to Analyze

If `competitor_url` is provided, skip to Step 2.

If only `niche` is provided, find 3-5 top competitors via search:
1. "best [niche] affiliate sites" — review/comparison sites
2. "[niche] review site affiliate" — review-first monetization models
3. "[niche] blog affiliate income report" — income reports reveal programs
4. "youtube [niche] affiliate" — find channels

Pick 3 competitors that are clearly affiliate-driven (review pages, comparison tables, "best X" content, visible affiliate disclaimers).

### Step 2: Identify Affiliate Programs They Promote

**Method A — Link analysis:** Fetch the competitor URL and scan for outbound links. Look for patterns like `?ref=`, `?via=`, `/go/`, `aff_id=`, `?affiliate=`, and known affiliate network domains. These patterns indicate affiliate links.

**Method B — Content analysis:** Look at their top content: "Best X", "X vs Y", "X Review", "X Alternatives". Every product featured prominently = likely affiliate relationship. Products mentioned with a CTA button ("Try X Free") = strong affiliate signal.

**Method C — Disclosure scan:** Search the page for "affiliate", "commission", "sponsored", "partner" disclosures. These legally required disclosures often reveal programs.

**Method D — Income reports:** Search "[site name] income report affiliate" or "[creator name] how I make money affiliate" — some affiliates publish transparent earnings breakdowns.

Extract for each program found: name, estimated prominence (primary/secondary/mentioned), and content type promoting it.

### Step 2.5: Analyze Competitor Content Engagement

For each competitor, assess content performance across social platforms — not just what they create, but how well it performs:

- Search for their YouTube channel/TikTok and note view counts on top videos
- Identify their strongest platform and weakest platform (gap to exploit)
- Note the 3-5 best-performing pieces and what format they use

### Step 3: Analyze Their Content Strategy

Extract for each competitor:
- **Content patterns**: most common formats (listicles, comparisons, tutorials, reviews)
- **Depth**: shallow (<1000 words), standard (1000-3000), deep (3000+)
- **Publishing frequency**: estimate from visible dates
- **SEO signals**: do they rank for "[product] review" terms? Active social/newsletter?

### Step 4: Find Content Gaps

Compare competitor content to what's NOT covered:
1. Products they promote but haven't done deep comparison posts for
2. Common user questions (from forums, comments) they haven't answered
3. New product launches competitors haven't covered yet
4. Angles competitors avoid (honest cons, "X is not for everyone")

Search "reddit [niche] [product] problems" to find pain points no affiliate has addressed honestly — these make high-converting, low-competition content.

### Step 5: Score Competitor Strategies

| Dimension | Score (1-10) | Assessment |
| --- | --- | --- |
| Program Quality | — | High-commission recurring vs. low-margin one-off |
| Content Quality | — | Shallow listicles vs. deep genuine reviews |
| SEO Sophistication | — | Thin content vs. well-structured, keyword-targeted |
| Monetization Diversity | — | One program vs. multiple revenue streams |
| Replicability | — | How hard is it to do what they do, but better? |

Higher replicability score = easier to beat them.

### Step 6: Build the Intelligence Report

Synthesize into 3 parts: (1) Programs worth stealing, (2) Content formats that clearly work, (3) Gaps to exploit.

### Step 7: Self-Validation

- [ ] Confidence levels match evidence strength (confirmed / likely / possible)
- [ ] Replicability score accounts for real barriers (domain authority, team size)
- [ ] No hallucinated competitor data — all claims traceable to search results

## Output Format

```
## Competitor Intelligence Report: [Niche]

### Competitors Analyzed
| Competitor | Programs Found | Content Focus | Replicability |
|-----------|---------------|---------------|---------------|

### Programs Worth Promoting (Validated by Competitors)
| Program | Promoted By | Evidence |
|---------|------------|----------|

### Content Formats That Work in This Niche
1. [Format 1]: [what it is, why it works, example]

### Content Gaps You Can Exploit
1. [Gap 1]: [what's missing, why it's valuable, how to fill it]

## Next Steps
1. Evaluate the top validated programs
2. Compare earnings potential across programs
3. Start with the highest-gap content angle
```

## Error Handling

- **Competitor URL blocked/paywalled:** Fall back to search-based signals. Note limitations.
- **No obvious affiliate links found:** Competitor may use native ads/direct sponsorships. Flag and look for brand mention patterns.
- **Niche too broad:** Ask user to narrow to a sub-niche or platform.
- **No competitors found:** Niche may be too new/narrow — itself a signal of a gap opportunity.
- **Competitor is a large media company:** Not replicable — find indie affiliate sites instead.

## Examples

**Example 1:** "Spy on what affiliate programs [income-focused blog] recommends" → fetch site, look for disclosures/outbound links, map to real programs, output report with content gaps.

**Example 2:** "What affiliate strategy do top YouTubers use in the AI tools niche?" → find 3-5 AI tools YouTubers, analyze video descriptions for affiliate links, extract common patterns, identify gap (e.g., no one doing "best AI tools for [specific job role]").

**Example 3:** "I'm entering the email marketing niche, spy on competitors" → find competitor review sites, extract programs (ConvertKit, ActiveCampaign, etc.), find content gap (e.g., "email marketing ROI by industry"), recommend starting program + gap to fill.

## Suggested Next Skills

- `content-angle-ranker` (S1) — turn competitor gaps into ranked angles
- `content-research-brief` (S2) — research the gap topic with real sources
- `grand-slam-offer` (S4) — use competitive gaps to sharpen your offer
- `affiliate-blog-builder` (S3) — write the content that fills the gap

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
