---
name: content-angle-ranker
description: Generate 8-12 concrete content angle candidates and score them on platform fit, competition level, predicted engagement, and creator fit to pick the strongest one data-first instead of by gut feeling. Use when the user has multiple content ideas and needs to decide what to actually create, or after trending-content-scout has surfaced patterns and gaps that need to be turned into a ranked shortlist.
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Angle Ranker

Replace "which idea feels right?" with a scored, ranked shortlist. Generates
specific, headline-ready angle candidates and evaluates each on four weighted
dimensions so the user commits their limited content-creation time to the
highest-probability winner — plus a deliberate contrarian option in reserve.

## When to Use

- User has several content ideas and can't decide which to produce first
- User needs to pick a hook/format/platform for a given keyword or product
- Directly downstream of `trending-content-scout` — turning raw patterns/gaps into a decision
- User wants a data-backed argument for why one angle beats another, not just intuition

## Input Schema

```
{
  topic: string                    # required — keyword, product, or niche the angle is about
  scout_data: object               # optional — output from trending-content-scout
  platforms: string[]              # optional — target platforms to weigh angles against
  creator_strengths: string[]      # optional — what the user is personally good at (on-camera, writing, editing, etc.)
}
```

## Workflow

### Step 1: Gather Engagement Intelligence
Use `scout_data` if provided. Otherwise run quick `web_search` queries per
target platform to understand what's currently performing for the topic.

### Step 2: Generate 8-12 Angle Candidates
Write each candidate as an actual headline/title — specific enough to publish
as-is, not a vague theme. E.g., not "review the product" but "I used [product]
for 30 days as a [specific audience] — here's what nobody tells you."

### Step 3: Score Each Angle

```
angle_score = (platform_fit × 0.25) + (competition_level × 0.30) +
              (engagement_prediction × 0.30) + (creator_fit × 0.15)
```

| Dimension | Weight | What it measures |
|---|---|---|
| Platform Fit | 25% | Does this angle's format suit the target platform's native content style? |
| Competition Level | 30% | Inverse of saturation — score higher when fewer strong existing pieces cover this exact angle |
| Engagement Prediction | 30% | Based on scout data patterns (hook type, format) known to perform in this niche |
| Creator Fit | 15% | Does this play to the user's stated strengths (on-camera comfort, writing skill, editing ability)? |

### Step 4: Rank and Estimate Effort
Sort by `angle_score` descending. For each of the top 5, estimate relative
difficulty (low/medium/high) and rough time-to-produce, since the highest
score isn't useful if it's a 40-hour production the user can't sustain.

### Step 5: Validate Differentiation
- [ ] Top angle isn't a near-duplicate of something already saturating the niche
- [ ] At least one candidate offers a genuinely contrarian take, not just a rephrase
- [ ] Scores are justified by cited data/patterns, not assumed

## Output Format

```
## Content Angle Ranking: [Topic]

### Top Angle: [Headline-ready title]
**Score: X/10**
- Platform fit: X — [why]
- Competition: X — [why, cite gap]
- Engagement prediction: X — [why, cite pattern]
- Creator fit: X — [why]
**Estimated effort**: [low/medium/high], ~[time]

### Full Ranked Table
| Rank | Angle | Platform Fit | Competition | Engagement | Creator Fit | Score |
|---|---|---|---|---|---|---|
| 1 | ... | ... | ... | ... | ... | X |
| 2 | ... | ... | ... | ... | ... | X |

### Strategic Alternatives
- **Quick win**: [lowest-effort angle with a decent score] — ship this first for momentum
- **Best bet**: [top-ranked angle] — highest expected return, worth the effort
- **Contrarian play**: [angle that pushes against the niche consensus] — higher risk, higher differentiation

### Ready for Production
[Chosen angle] with title, platform, format, and hook type — pass directly to a content-writing skill.
```

## Error Handling

- **Fewer than 8 viable angle ideas generated**: broaden the topic scope or pull more scout data before scoring; a ranking of 3-4 candidates is too thin to be meaningful.
- **All angles score similarly (no clear winner)**: surface this explicitly and let the user choose based on creator fit or personal interest, since the data isn't differentiating.
- **No scout data and no platform data available**: fall back to general content-marketing heuristics and clearly flag the engagement predictions as lower-confidence estimates.
- **User's stated creator strengths conflict with the top-scoring angle's format**: flag the tension directly (e.g., "top angle is video-first but you said you prefer writing") and surface the best-fit alternative alongside it.

## Examples

**Example 1:** "I have 10 ideas for my AI tools blog, which should I write first?" → Generates headline-ready versions of each, scores on the four dimensions using scout data, returns a ranked table plus a "quick win" recommendation.

**Example 2:** "What angle should I use for a TikTok about this new SaaS tool?" → Generates 8-12 TikTok-native angle candidates (hook-first), scores for competition and predicted engagement, recommends the top angle with hook type specified.

## Suggested Next Skills

- `trending-content-scout` (S1) — run first if angle candidates need real engagement data to score against
- `tiktok-script-writer` (S2) — turn the winning angle into an actual script
- `affiliate-blog-builder` (S2) — turn the winning angle into a full blog post

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
