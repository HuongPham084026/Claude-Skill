---
name: proprietary-data-generator
description: Design and automate the collection of original surveys, benchmark studies, or aggregated datasets that don't exist yet in a niche, so the resulting content becomes a moat competitors can't copy. Use when the user wants a content asset that earns backlinks and authority rather than another opinion post, or after identifying that a niche's content is saturated with generic writing but has no original data.
stage: S7 Automation
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Proprietary Data Generator

Competitors can copy a writing style in an afternoon; they cannot copy data
they don't have. This skill finds the data gap in a niche, designs a
collection method that fits the user's actual audience access and budget
(including $0), produces ready-to-run collection assets, and turns the plan
into a repeatable, automatable system rather than a one-off survey.

## When to Use

- User wants content that can't be trivially replicated by competitors
- User mentions "original research," "survey," "benchmark," "data moat," or "first-party data"
- Downstream of a content-moat analysis that found the niche is saturated with generic, non-data-backed writing
- User wants a linkable asset designed to earn backlinks and build topical authority

## Input Schema

```
{
  niche: string,              # REQUIRED — topic area for data collection
  data_type: string,          # OPTIONAL — "survey" | "benchmark" | "aggregation" | "case_study"
                              # default: recommend based on niche + resources
  audience_access: string,    # OPTIONAL — e.g. "email list of 500", "Reddit community", "Twitter followers"
  budget: string,             # OPTIONAL — "zero" | "low ($0-100)" | "medium ($100-500)" | "high ($500+)"
                              # default: "zero"
  goal: string                # OPTIONAL — "content_moat" | "backlink_magnet" | "authority" | "lead_gen"
                              # default: "content_moat"
}
```

## Workflow

### Step 1: Find the real data gap
Search for what data already exists in the niche (published stats, surveys, benchmarks) to avoid duplicating it. Then look at what questions the community keeps asking without a data-backed answer — forum threads with "does anyone know" or "I wish I knew" phrasing are reliable signals of an unmet data need.

### Step 2: Design the collection method
Pick the format that fits the data type (or recommend one):
- **Survey**: 8-12 questions (short surveys finish; long ones don't), roughly 70% multiple choice / 20% 1-5 scale / 10% open-ended, include one deliberately "surprising" question built to produce a headline-worthy stat, target 100+ responses for credibility.
- **Benchmark study**: define 3-5 concrete metrics, identify data sources (public data, APIs, manual pulls), set a collection cadence, and define the comparison framework for presenting results.
- **Data aggregation**: identify sources to combine (public databases, APIs, scraping targets that are actually permitted), define normalization logic, set update frequency (one-time vs. recurring), and sketch the visualization.
- **Case study collection**: a 5-7 question structured template for interviewees, an outreach message for recruiting them, anonymization rules, and a minimum viable sample of 10+ cases.

### Step 3: Produce the actual collection assets
Not just a plan — deliver the survey question list with answer options, the collection template (spreadsheet/form structure), the outreach message to recruit respondents, and an analysis plan describing how raw responses become insights.

### Step 4: Design the automation layer
This is what separates it from a one-off survey: define a collection schedule (monthly/quarterly/annual), the tools to run it (Google Forms, Typeform, Airtable), how collection and reporting get automated, and the process for refreshing and republishing with new data each cycle.

### Step 5: Self-validate before delivering
- [ ] The data gap is real — confirmed by search, not assumed
- [ ] Sample size target is realistic given stated audience access
- [ ] Questions are unbiased and unambiguous
- [ ] Collection method is actually feasible at the stated budget
- [ ] The content plan names specific outputs, not "write a blog post"
- [ ] Collection is ethical — no scraping private data, surveys include consent

## Output Format

```
## Proprietary Data Plan: [Niche]

### The Data Gap
Nobody has answered: [question]
Why it matters: [reason]
Headline potential: "[surprising finding template]"

### Collection Design
Type / target sample / timeline / budget / tools

### Survey Questions (or Collection Template)
1. [Question] — [answer type] — [why this question]
...

### Outreach Template
Subject: ...
[message body]

### Content Plan
1. Blog post: "[Title]" → build with a blog/article-writing skill
2. Social thread: key findings → atomize for distribution
3. Lead magnet: full report → gate behind a landing page

### Automation Schedule
Collection frequency / analysis timing / publication timing / refresh cadence
```

## Error Handling

- **No niche given:** Ask for the niche before doing anything else — data-gap analysis is meaningless without a topic to search against.
- **No audience access:** Point to free distribution: Reddit, Twitter/X, niche forums, ProductHunt. A useful 100+ response survey does not require an existing email list.
- **Zero budget:** Design the entire plan around free tools (Google Forms, Google Sheets, manual aggregation) — cost should never be the blocker, only time and follow-through.
- **Niche looks already well-researched:** Don't give up — dig for the narrower unanswered angle within it. Broad stats existing doesn't mean the specific angle the user cares about has been measured.

## Examples

**Example 1:** "I want original data about AI video tools" → designs a 10-question usage/satisfaction/spend survey, distribution plan across Reddit r/aivideo, Twitter, and LinkedIn, target of 150 responses, output plan: "State of AI Video [year]" post plus an infographic.

**Example 2:** "Create a benchmark for affiliate marketing earnings" → aggregates existing public case-study data, layers in an original survey, sets up a recurring quarterly collection cycle, output: "Affiliate Marketing Earnings Benchmark" series.

**Example 3:** "I need a data moat, competitors all have generic listicles" → identifies that nobody in the niche has published real outcome data, designs a case-study collection ("How 50 Affiliate Marketers Made Their First $1,000") as an instant-authority asset.

## Suggested Next Skills

- `content-repurposer` (S7) — once the data is collected, spin the findings into a blog post, thread, and newsletter section simultaneously
- `email-automation-builder` (S7) — recruit survey respondents and later distribute the findings through a branching flow
- `multi-program-manager` (S7) — anonymized portfolio/earnings data from this skill can itself become a benchmark dataset

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
