---
name: listicle-generator
description: Write "Top N Best [Category]" roundup articles for affiliate marketing, with SEO-optimized structure, mini-reviews per product (features, pricing, pros/cons), comparison tables, and CTAs. Use when the user wants a "best of" list, a product roundup, an alternatives article, or wants to cover an entire category with multiple affiliate links in one high-ranking post.
stage: S3 Blog/SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Listicle Generator

Write "Top N Best [Category]" roundup articles that rank on Google, win featured
snippets, and drive affiliate conversions across several products at once. Each
entry is a self-contained mini-review — features, pricing, pros/cons, audience
fit, and a CTA — structured to capture both the featured snippet and the
"People Also Ask" box.

## When to Use

- User wants one article that covers an entire product category with multiple affiliate links
- User's request contains "best", "top", "roundup", "list of", or a number plus a category
- User wants to target a broad, high-volume generic keyword ("best email marketing tools") rather than a single product name
- User has several affiliate programs in the same category and wants them all featured credibly
- User wants a format that's easy to refresh periodically as the market changes

## Input Schema

```
{
  category: string              # REQUIRED — product category, e.g. "AI video generators"
  primary_product: {            # RECOMMENDED — the affiliate product to feature at #1
    name: string, url: string, reward_value: string, description: string
  }
  additional_affiliates: []     # OPTIONAL — other affiliate products to include
  list_size: number             # OPTIONAL — 5-12, auto-selected if omitted
  target_audience: string       # OPTIONAL — "beginners" | "enterprise" | "freelancers" | ...
  year: number                  # OPTIONAL — defaults to current year
  tone: string                  # OPTIONAL — "conversational" (default) | "professional"
}
```

## Workflow

### Step 1: Determine List Parameters
Parse category, list size, target audience, and year from the request.
- Niche/specialized category → 5-7 products
- Broad/competitive category → 7-10 products
- Very broad category ("project management tools") → 10-12 products
Always use the current year in the title for a freshness signal. If no affiliate
product is given, ask which one the user is promoting — or proceed with a
balanced editorial list and flag where to insert the tracking link.

### Step 2: Research the Product Landscape
Search to build the candidate list:
1. `"best [category] tools [year]" site:g2.com OR site:capterra.com OR site:trustradius.com`
2. `"best [category]"` — check common phrasings/autocomplete
3. `"[category] affiliate program"` — confirm which products pay commissions

For each candidate, capture: name + one-liner, starting price, free-plan
availability, review-site rating, its single best differentiator, and its ideal
user.

**Affiliate positioning rules:**
- Put the user's primary affiliate product at #1 or #2 — never lower than #3 unless it genuinely can't be defended there
- Use the #1 slot for the highest-commission or best-converting product
- Spread multiple affiliate programs across positions 1, 2, and 4
- Fill remaining slots with strong non-affiliate products to keep the list credible

### Step 3: Plan the Article Structure
1. Title (year + number + category)
2. FTC disclosure
3. Introduction (150-200 words)
4. "At a Glance" summary table
5. Evaluation Criteria (H2)
6. Individual product entries × N (H2 each)
7. Master comparison table
8. How to Choose (H2)
9. FAQ (H2)
10. Final Recommendation (H2)

Per-entry structure (400-600 words): H2 `[Rank]. [Product] — [Value Prop]`,
opening paragraph, 3-5 key features, pricing table, 4-5 pros, 2-3 honest cons,
"Best for:" sentence, affiliate CTA.

### Step 4: Write the Full Article
- **Title formula:** `[N] Best [Category] Tools in [Year] (Ranked and Reviewed)`
- **Intro:** open with the problem the category solves, note how many tools were evaluated, name-drop 2-3 list members, end with a transition line
- **At a Glance table** (right after intro, targets the featured snippet):

```
| Tool | Best For | Starting Price | Free Plan |
|---|---|---|---|
| [Product 1] | [Use case] | $X/mo | Yes |
```

- **Evaluation Criteria:** list 4-6 ranking criteria (ease of use, feature depth, pricing value, support quality, integrations, scalability) to justify the #1 pick
- **Entries:** vary opening sentences; use real, verifiable feature names and pricing — no generic praise
- **Master comparison table:** feature matrix across all products with checkmarks/ratings
- **How to Choose:** "If you're X → Product A", "If you need Y → Product B" decision framework (300-400 words)
- **FAQ (5-7 Qs):** "What is the best [category] tool?", "What's the cheapest?", "Which has the best free plan?", "Is [top product] worth it?"
- **Final Recommendation:** restate #1 pick with reasoning, offer a backup pick for a different audience, close with a strong CTA

Target length: 3,000-5,000 words (roughly 400-500 words per entry plus structure).

### Step 5: Self-Validate Before Delivering
- FTC disclosure appears before product entries
- "At a Glance" table present with Tool/Best For/Price/Free Plan columns
- Primary affiliate product ranked #1-3
- Every entry has features, pricing, pros, cons, and a "best for" line
- Title includes the current year

Fix silently — don't show the checklist to the user.

## Output Format

```
## SEO Metadata
Title: ...
Slug: best-[category]-tools
Meta Description: (150-160 chars)
Target Keyword: best [category] tools
Secondary Keywords: ...
Word Count: ...

## Article
[full publishable markdown]

## Supplementary
- FAQ questions for schema markup
- Image/screenshot suggestions
- Affiliate URLs by product, flagged by role (primary/secondary/editorial)
- Update reminder: refresh every 6 months
```

## Error Handling

- **No category provided:** Ask for it, with an example ("best email marketing tools").
- **No affiliate product specified:** Write a balanced editorial list; flag clearly that a tracking URL still needs to be inserted for the top pick.
- **Category too broad ("best software"):** Ask the user to narrow it to a sub-niche or use case.
- **Category too niche (fewer than 5 good products exist):** Shrink the list size and say so honestly rather than padding with weak entries.
- **Product research turns up thin results:** Try 2-3 query variations; fall back to official product pages plus review-site data.

## Examples

**Example 1:** "Write a top 10 best AI video tools article" → category="AI video generators", list_size=10, research candidates, place the user's affiliate product at #1, deliver a ~4,500-word listicle targeting "best ai video tools [year]".

**Example 2:** "Best email marketing tools for e-commerce, I'm promoting Klaviyo" → target_audience="e-commerce store owners", list_size=7, Klaviyo ranked #1, honest pros/cons for every entry.

**Example 3:** "Write a 'best alternatives to Mailchimp' article" → treat as an alternatives listicle with Mailchimp as the incumbent, title framed as "7 Best Mailchimp Alternatives in [Year] (Cheaper + More Powerful)".

## Suggested Next Skills

- `landing-page-creator` (S4) — build a dedicated landing page for the #1-ranked product
- `content-pillar-atomizer` (S2) — slice the listicle into social clips and short-form tips
- `internal-linking-optimizer` (S6) — link the new listicle into the rest of the site
- `keyword-cluster-architect` (S3) — supply commercial-intent clusters for future listicle topics

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
