---
name: keyword-cluster-architect
description: Map 50-200+ keywords into topical clusters by search intent, then build a hub-and-spoke content roadmap for SEO topical authority. Use when the user wants to plan an SEO content strategy, asks for keyword research or clustering, or needs to know which articles to write first and in what order to dominate a topic.
stage: S3 Blog/SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Keyword Cluster Architect

Map 50-200+ keywords into topical clusters grouped by search intent, then turn
that map into a hub-and-spoke content roadmap. Google rewards topical
authority — this skill produces the strategic blueprint that tells you exactly
what to write and in what order, before a single article gets drafted.

## When to Use

- User wants to plan an SEO content strategy for a niche
- User asks about keyword research, clustering, or topical authority
- Request mentions "keyword", "SEO plan", "content roadmap", "topic cluster", "hub and spoke"
- Before running a blog-writing skill — to decide which articles to write first
- After a niche-selection exercise — to map the keyword universe for the chosen niche

## Input Schema

```
{
  niche: string                # REQUIRED — the topic to cluster, e.g. "AI video tools"
  seed_keywords: string[]      # OPTIONAL — starting keywords; auto-generated if omitted
  depth: string                # OPTIONAL — "quick" (50) | "standard" (100, default) | "deep" (200+)
  affiliate_products: string[] # OPTIONAL — products promoted, to prioritize commercial keywords
}
```

## Workflow

### Step 1: Generate Seed Keywords
If none are provided, generate 5-10 covering four angles:
- Product-focused: "[product] review", "best [category]"
- Problem-focused: "how to [solve problem]", "[problem] solution"
- Comparison: "[product A] vs [product B]", "alternatives to [product]"
- Tutorial: "how to use [product]", "[product] tutorial"

### Step 2: Expand Keywords
For each seed, search and harvest related terms:
1. `"[seed keyword]"` — note related searches and "People Also Ask"
2. `"[seed keyword] guide" OR "[seed keyword] tutorial"` — informational variants
3. `"best [seed keyword]" OR "[seed keyword] review"` — commercial variants

Collect 50-200+ unique keywords depending on `depth`.

### Step 3: Classify by Intent
- **Informational (I):** learning, how-to, "what is" → blog posts, tutorials
- **Commercial (C):** comparing, evaluating, reviewing → comparisons, reviews
- **Transactional (T):** ready to buy, pricing, discount → landing/deal pages
- **Navigational (N):** brand/login searches → skip, not capturable traffic

### Step 4: Cluster by Topic
Group keywords that would all be satisfied by the same page:

```
Cluster: "[Main Topic]"
  Type: [I/C/T]
  Hub keyword: [highest-volume keyword]
  Supporting keywords: [keyword — est. volume, ...]
  Content type: [blog / comparison / review / tutorial / landing page]
  Priority: [1-5, based on volume x intent x competition]
```

### Step 5: Build the Content Roadmap
1. Identify the hub page — broadest, highest-volume cluster
2. Connect spoke pages — narrower clusters that link back to the hub
3. Prioritize commercial intent first (revenue), then informational (traffic)
4. Estimate the number of articles needed and a realistic publishing cadence

### Step 6: Self-Validate
- Clusters reflect real search data, not guesses
- Every cluster has a clear intent label (I, C, or T)
- Hub-and-spoke structure is logical — hub is broad, spokes are specific
- Priority order makes business sense (revenue-driving content first)
- Total content volume is realistic for the user's publishing capacity

## Output Format

```
## Keyword Cluster Map: [Niche]

### Overview
- Total keywords: XXX | Clusters: XX | Hub topic: [name] | Articles needed: XX

### Hub & Spoke Map
           [HUB: Main Topic]
          /    |    |    \
     [Spoke] [Spoke] [Spoke] [Spoke]

### Clusters by Priority

#### Priority 1: [Cluster Name] (Commercial Intent)
- Hub keyword: [keyword] — [volume]
- Content type: [comparison/review]
- Keywords: [list]
- Article idea: [specific title]

(repeat per cluster, descending priority)

### Content Roadmap
| Week | Cluster | Article | Intent | Priority |
|---|---|---|---|---|
| 1 | [cluster] | [title] | C | 1 |

### Next Steps
- Estimate topical-authority effort for this map
- Draft Priority 1 articles first
- Turn commercial clusters into comparison posts
```

## Error Handling

- **Niche too broad:** narrow to a sub-niche for actionable clusters before proceeding.
- **No measurable search volume:** flag that the niche may be too narrow; suggest broadening slightly.
- **Too many keywords to handle cleanly:** cluster more aggressively — quality of grouping beats raw keyword count.
- **No commercial-intent keywords found:** flag as a monetization risk and suggest adjacent, more commercial niches.

## Examples

**Example 1:** "Map keywords for AI video tools" → seeds like "best AI video tools", "AI video generator", "HeyGen review"; expand to 100+ keywords; clusters: "AI video reviews" (C), "how to make AI videos" (I), "AI video pricing" (T), "AI video vs traditional" (C); hub: "Best AI Video Tools 2025".

**Example 2:** "Keyword strategy for my email marketing affiliate blog" → deep clustering into "email marketing platforms" (C), "email automation tutorials" (I), "email marketing pricing comparison" (T), "email deliverability guides" (I).

**Example 3:** "Plan my content roadmap" (continuing from niche research) → map 100+ keywords in the chosen niche, prioritize clusters by revenue potential.

## Suggested Next Skills

- `content-moat-calculator` (S3) — estimate how much content is actually needed to win this cluster map
- `comparison-post-writer` (S3) — turn commercial clusters into head-to-head comparison articles
- `listicle-generator` (S3) — turn broad commercial clusters into "best of" roundups
- `internal-linking-optimizer` (S6) — use the cluster structure to define the site's link architecture

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
