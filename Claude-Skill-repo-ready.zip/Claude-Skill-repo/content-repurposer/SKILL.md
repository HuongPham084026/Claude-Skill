---
name: content-repurposer
description: Turn one piece of affiliate content (blog post, landing page, video script, social post) into multiple platform-native formats — tweet threads, LinkedIn posts, TikTok scripts, newsletters, Reddit posts, emails, Pinterest pins — each respecting that platform's length limits, tone, and disclosure rules. Use when the user has already-published content and wants to multiply its reach without writing everything from scratch again.
stage: S7 Automation
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Repurposer

Multiply the reach of a single piece of affiliate content by adapting it — not
just cross-posting it — into the native format of each target platform. One
blog post becomes a tweet thread, a LinkedIn post, a TikTok script, a
newsletter section, and a Pinterest pin, each rewritten to fit that platform's
constraints while keeping the same value proposition, proof points, and
affiliate CTA.

## When to Use

- User has a published blog post, landing page, video script, or social post and wants it repackaged for other channels
- User says "repurpose this," "turn this into a thread," or "get more mileage out of this content"
- User is publishing on one channel only and wants to diversify traffic sources for the same offer
- Feeds naturally from `affiliate-blog-builder` or `squeeze-page-builder` output, and feeds into social schedulers and `conversion-tracker`

## Input Schema

```
{
  source_content: string,       # REQUIRED — the original text (or a URL/summary of it)
  source_format: string,        # REQUIRED — "blog" | "landing_page" | "video_script" | "social_post"
  target_formats: string[],     # OPTIONAL — subset of the supported list below; default: all
  affiliate_link: string,       # REQUIRED if the source contains one
  tone: string                  # OPTIONAL — override detected tone (e.g., "casual", "authoritative")
}
```

Supported target formats: tweet thread, LinkedIn post, TikTok/Reels script, email newsletter section, Reddit post, blog summary, Pinterest pin.

## Workflow

### Step 1: Extract the source's core assets
Pull out the central value proposition, the 2-3 strongest proof points or stats, the hook/opening line, and the existing CTA. This extracted core is what gets carried into every derivative — the repurposing should never dilute the original argument.

### Step 2: Map each target format's constraints
Before writing, note the hard limits per platform:
- **Twitter/X thread**: 5-9 tweets, ~250 chars each, hook tweet must stand alone
- **LinkedIn post**: 1,300-1,600 chars, line breaks for readability, no external link in the first line (algorithm penalty) — put the affiliate link in a comment or "link in bio"
- **TikTok/Reels script**: 15-30 seconds, 3-second hook, on-screen text cues, spoken CTA
- **Newsletter section**: 150-250 words, one clear CTA button
- **Reddit post**: value-first, near-zero overt selling, disclosure required if a link is included, match subreddit norms
- **Blog summary**: 100-150 word TL;DR for embedding at the top of a longer piece
- **Pinterest pin**: title ≤100 chars, description ≤500 chars, overlay text on the image

### Step 3: Adapt voice and structure per platform
Rewrite — don't truncate. A LinkedIn post reads like professional storytelling; a tweet thread reads like a punchy narrative with a cliffhanger per tweet; a Reddit post reads like a genuine community answer. Reuse the extracted proof points from Step 1 but re-sequence them to fit each format's pacing.

### Step 4: Attach platform-specific posting guidance
For each output, add practical notes: best posting time/day, relevant hashtags (2-4 for LinkedIn/Instagram, up to 10 for TikTok), and where the affiliate link goes (bio link, comment, swipe-up, direct in copy) since several platforms restrict direct affiliate links in the post body.

### Step 5: Batch-deliver copy-paste-ready blocks
Present every requested format as a separate, clearly labeled, ready-to-post block — no further editing should be required before publishing.

### Step 6: Compliance and consistency check
- [ ] FTC disclosure present wherever the affiliate link appears, worded appropriately for that platform (e.g., "#ad" fits Twitter; Reddit needs a full sentence disclosure)
- [ ] Character/length limits respected for every format
- [ ] Core value proposition consistent across all variants
- [ ] No format links directly to the affiliate URL where the platform prohibits it (route through a bridge page instead)

## Output Format

```
## Repurposed Content: [Source Title]

### Source Summary
- Core value prop: ...
- Proof points used: ...

### [Format Name]
[Ready-to-post copy block]
**Posting notes:** timing / hashtags / link placement

(repeat per requested format)

### Distribution Priority
Ranked suggestion of which formats to post first based on effort-to-reach ratio.
```

## Error Handling

- **No source content provided:** Ask for the original piece (paste text or URL) — repurposing needs real material to extract from, not a topic alone.
- **Source has no clear CTA or affiliate link:** Flag it and ask whether to add one, since several target formats (email, LinkedIn) expect a clear next action.
- **Target format not supported natively by the platform's link policy (e.g., Reddit, TikTok bio-only links):** Route the CTA through a bridge/landing page and say so explicitly rather than embedding the raw affiliate link.
- **Source content is too short to fill a format** (e.g., a 100-word post being turned into a full newsletter): Say so and offer to expand with additional context rather than padding artificially.

## Examples

**Example 1:** "Repurpose my HeyGen review blog post into a Twitter thread and a LinkedIn post" → extracts the 3 strongest proof points from the review, writes a 7-tweet thread with a hook tweet, and a LinkedIn post with a professional framing and link-in-comment note.

**Example 2:** "Turn my landing page into a newsletter blurb and a Pinterest pin" → 200-word newsletter section with one CTA button, plus a Pinterest pin title/description/overlay-text set targeting the same keyword the landing page ranks for.

**Example 3:** "I only have one TikTok script for this product, get it onto more channels" → reverse-repurposes the script into a blog summary, a Reddit-native post for a relevant subreddit, and an email section, preserving the hook line across all three.

## Suggested Next Skills

- `content-pillar-atomizer` (S2) — for breaking one pillar piece into many micro-posts at the ideation stage, upstream of this skill
- `conversion-tracker` (S6) — tag each repurposed variant's link separately to see which channel actually converts
- `email-automation-builder` (S7) — feed the newsletter-format output into a full branching sequence instead of a one-off blast

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
