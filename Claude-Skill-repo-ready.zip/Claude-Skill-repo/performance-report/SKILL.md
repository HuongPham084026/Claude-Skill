---
name: performance-report
description: Turn raw affiliate program data (clicks, conversions, revenue) into a weekly/monthly performance report with KPI calculations (EPC, conversion rate, ROAS), a Star/Cash Cow/Question Mark/Dog ranking of programs, trend analysis, and prioritized recommendations. Use when the user wants to review affiliate earnings, asks "how are my programs doing?", or has raw numbers and wants to know where to focus effort next.
stage: S6 Analytics
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Performance Report

Turns a pile of raw affiliate numbers into a decision-ready report: which
programs to double down on, which to fix, and which to drop. Professional
affiliates review this weekly or monthly — data without analysis is just
noise, and small portfolio reallocation decisions compound fast.

## When to Use

- User wants a periodic (weekly/monthly/quarterly) review of affiliate earnings
- User asks "how are my programs doing?" or "show me my affiliate report"
- User has click/conversion/revenue numbers across multiple programs and wants them ranked
- User wants to compare this period against a previous one
- Chaining from a conversion-tracking skill — analyze the data collected there

## Input Schema

```
{
  programs: [
    { name: string, clicks?: number, conversions?: number, revenue?: number,
      commission?: number, spend?: number }
  ],
  period: string,              # optional - "week" | "month" | "quarter" (default: month)
  goals: {
    revenue_target?: number,
    conversion_target?: number
  },
  previous_period?: [ { name: string, clicks: number, conversions: number, revenue: number } ],
  notes: string                # optional - context, e.g. "launched new post week 2"
}
```

Work with whatever subset of fields is available — note explicitly which KPIs can't be computed given the gaps.

## Workflow

### Step 1: Collect and Validate Data
Gather whatever program-level numbers the user provides. If clicks or conversions are missing, state plainly which KPIs are unavailable ("you gave revenue but not clicks, so I can rank by revenue but not EPC").

### Step 2: Calculate KPIs
Per program:
- **EPC** (earnings per click) = revenue / clicks
- **Conversion rate** = conversions / clicks × 100
- **Revenue share** = program revenue / total revenue × 100
- **CPA** = spend / conversions (if spend given)
- **ROAS** = revenue / spend (if spend given)
- **Commission per sale** = revenue / conversions

Portfolio-level: total revenue, blended EPC, blended conversion rate, top performer, weakest performer.

### Step 3: Rank and Label Programs
Sort by EPC (primary), total revenue (secondary), conversion rate (tertiary). Assign a quadrant label:
- **Star** — high EPC + high volume → double down
- **Cash Cow** — moderate EPC + high volume → maintain
- **Question Mark** — high EPC + low volume → scale up, more traffic needed
- **Dog** — low EPC + low volume → candidate to phase out

### Step 4: Trend Analysis
If `previous_period` is supplied, compute period-over-period % change for revenue, clicks, and conversions, both portfolio-wide and per program. Flag anomalies (sudden drops/spikes) for investigation.

### Step 5: Recommendations
Map each program to an action:
- **Double down** — high EPC, needs more traffic
- **Optimize** — good traffic, weak conversion (points to a content/landing-page problem, not a traffic problem)
- **Phase out** — low EPC and low volume with no improving trend
- **Investigate** — an unexplained drop or spike

### Step 6: Self-Check Before Delivering
- EPC = revenue ÷ clicks, correctly computed
- Revenue shares across programs sum to ~100%
- Labels are consistent with the metrics that produced them
- Every recommendation names a concrete next step, not just a verdict

## Output Format

```
## Performance Report — <period>

### KPI Dashboard
| Total Revenue | Total Clicks | Total Conversions | Blended EPC | Blended CR | Goal Progress |
|---|---|---|---|---|---|

### Program Rankings
| Program | Clicks | Conversions | Revenue | EPC | CR | Revenue Share | Label | Trend |
|---|---|---|---|---|---|---|---|---|

### Trend Analysis
<period-over-period narrative, if previous_period supplied>

### Recommendations
| Program | Action | Reason | Next Step |
|---|---|---|---|
```

## Error Handling

- **No data at all:** ask for at minimum program names + revenue; ideally also clicks and conversions.
- **Only one program provided:** still generate the single-program report, but flag the lack of comparative analysis and suggest diversifying into more programs.
- **Revenue only, no clicks:** rank by revenue and revenue share, but explain EPC (the most important affiliate metric) can't be computed without click data, and recommend setting up click tracking.
- **Unusual spike or drop with no explanation:** label it "investigate" rather than guessing a cause, and list plausible reasons (traffic source change, tracking break, seasonality, program payout change).
- **Goals provided but no previous_period:** report goal progress as a simple percentage of target reached; skip trend claims since there's no baseline.

## Examples

**Example 1:** "Monthly report: HeyGen — 500 clicks, 15 conversions, $450. Semrush — 1200 clicks, 8 conversions, $320. Notion — 300 clicks, 25 conversions, $125." → Computes EPC/CR per program, labels HeyGen a Star, Semrush a Question Mark (high traffic, weak conversion — landing page issue), Notion a Cash Cow, and recommends scaling HeyGen traffic while fixing Semrush's landing page.

**Example 2:** "This week vs last week: HeyGen clicks went 100→150 but conversions dropped 5→3." → Flags the conversion-rate drop (5%→2%) as "investigate," suggests checking traffic source quality and testing the CTA.

**Example 3:** "My programs last month: HeyGen $450, Semrush $320, Notion $125, Canva $80." → Revenue-only breakdown with revenue share, flags 79% concentration risk in two programs, recommends adding click tracking and diversifying.

## Suggested Next Skills

- `ab-test-generator` (S6 Analytics) — for any "Optimize" program flagged with good traffic but weak conversion, generate CTA/headline variants to test
- `seo-audit` (S6 Analytics) — for underperforming content-driven programs, audit the page itself for on-page issues
- `internal-linking-optimizer` (S6 Analytics) — if a high-EPC "Question Mark" program needs more traffic, check whether its page is under-linked internally

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
