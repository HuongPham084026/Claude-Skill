---
name: twitter-thread-writer
description: Write research-backed X/Twitter threads that hook readers on tweet 1, deliver real value across the body, and drive clicks to a product or affiliate link without feeling like an ad. Use when the user wants a Twitter/X thread promoting a product, insight, or personal-brand topic.
stage: S2 Content
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Twitter/X Thread Writer

Write multi-tweet threads that hook on tweet 1, deliver genuine value across the
body, and end with a natural, non-pushy link out. Threads that read like ads get
scrolled past — threads that teach something get bookmarked and shared.

## When to Use

- User wants a Twitter/X thread promoting a product or affiliate link
- User wants to build personal-brand authority via a teaching thread
- User has research (ideally from `content-research-brief`) and needs it turned into a thread
- User asks for "a thread about X" or "break this down into tweets"

## Input Schema

```yaml
topic: string                 # REQUIRED
angle: string                  # OPTIONAL — specific angle/hook if already decided
product:                       # OPTIONAL — if this thread promotes something
  name: string
  link: string
data_points: string[]          # OPTIONAL — stats/facts to use (ideally from research)
thread_length: number          # OPTIONAL, default: 8 (tweets, 5-15)
tone: string                   # OPTIONAL — "bold" | "professional" | "contrarian" | "storytelling" (default: bold)
```

## Workflow

### Step 1: Confirm the Hook Is Strong Enough

Tweet 1 must do ALL of these:
- Make a specific, surprising claim (not "let's talk about X")
- Create curiosity or tension ("Everyone does X wrong. Here's what actually works.")
- Be understandable with zero context — it's the only tweet many people will see

If a research brief is available, pull the most counter-intuitive data point for the hook.

### Step 2: Structure the Body

- **Tweet 1**: Hook (see above)
- **Tweets 2-3**: Set up the problem/context — why this matters
- **Middle tweets**: The actual value — steps, data, examples, one idea per tweet
- **Second-to-last tweet**: The payoff/result — tie back to the hook's promise
- **Last tweet**: Soft CTA + link (only here, not earlier)

Rule: every tweet must be able to stand alone and make sense if retweeted in isolation.

### Step 3: Write in Native X Voice

- Short lines, line breaks for rhythm, no corporate tone
- One idea per tweet — if a tweet needs "and", it's probably two tweets
- Use numbers and specifics over vague claims ("saved me 6 hours/week" not "saved a lot of time")
- Avoid hashtag stuffing — 0-1 hashtag max, native platform behavior performs better

### Step 4: Place the Link Correctly

- Never put the link in tweet 1 (kills reach on X's algorithm)
- Place it in the last tweet, or as a reply to the last tweet
- Frame the CTA as a natural next step, not a sales pitch: "I put the full breakdown/tool here →" not "BUY NOW using my link!!"

### Step 5: Self-Validation

- [ ] Tweet 1 works with zero context and creates real curiosity
- [ ] Every middle tweet delivers one clear, standalone idea
- [ ] No link before the final tweet
- [ ] Reads like a person sharing something useful, not an ad
- [ ] Data points are attributed/accurate if research was provided

## Output Format

```
## X Thread: [Topic]

1/ [Hook tweet]

2/ [tweet]

3/ [tweet]

...

[N]/ [Payoff tweet]

[N+1]/ [Soft CTA + link]

---
**Best posting time note:** [if relevant]
**Suggested reply-to-self:** [optional extra resource to drop as a reply]
```

## Error Handling

- **No angle/data provided**: Ask for the core insight, or recommend running `content-research-brief` first for a research-backed thread.
- **Topic too broad**: Narrow to one specific claim or lesson — threads that try to cover everything perform worse than ones that nail one idea.
- **Product-only thread with nothing to teach**: Reframe around a genuine insight/lesson the product enabled, not a feature list.
- **Thread reads like an ad**: Rewrite the middle tweets to remove sales language; add a specific personal detail or number.

## Examples

**Example 1:** "Write a thread about an AI writing tool I promote" → hook built on a counter-intuitive result ("I stopped writing my own first drafts. Here's why that made my writing better, not worse."), body walks through the real workflow, soft CTA at the end.

**Example 2:** "Turn this research brief into a thread" → pull the strongest data point for the hook, use 2-3 other stats across the body, cite sources naturally.

**Example 3:** "I want a thread that builds my personal brand, not sell anything" → same structure, no product/link section — CTA becomes "follow for more" instead.

## Suggested Next Skills

- `content-research-brief` (S2) — feed real data into the thread before writing
- `social-media-scheduler` (S5) — schedule the thread
- `content-pillar-atomizer` (S7) — repurpose into LinkedIn post or TikTok script

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
