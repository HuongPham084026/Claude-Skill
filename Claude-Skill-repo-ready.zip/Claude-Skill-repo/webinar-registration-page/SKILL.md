---
name: webinar-registration-page
description: Builds a self-contained HTML webinar or live-event registration page with a live JavaScript countdown timer, speaker bio, agenda, and an email-capture form, designed to feed a "free training" funnel that promotes an affiliate product during the event itself. Use when the user is hosting a webinar, workshop, live demo, or challenge and needs a registration page, or wants to warm up leads before an affiliate pitch delivered live.
stage: S4 Offer/Landing
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Webinar Registration Page

Produces a high-converting registration page for a webinar, live training, or
workshop as one self-contained HTML file: countdown timer, speaker credibility
section, agenda, and a lead-capturing registration form. The page itself should
stay soft on the affiliate pitch — it teases the product, but the actual sale
happens live during the event.

## When to Use

- User is hosting a webinar, live training, demo, or workshop
- User wants to build a list of warm leads ahead of an affiliate promotion
- User says "webinar page," "event registration," "live training page," "workshop signup"
- The affiliate product will be revealed or recommended live during the session

## Input Schema

```
{
  event: { title, topic, date: "ISO8601 or evergreen", time, duration_minutes },  # REQUIRED
  presenter: { name, title, bio, social_proof },                                  # REQUIRED
  affiliate_product: { name, url, description, reward_value },                    # REQUIRED
  what_you_will_learn: string[],   # OPTIONAL, 4-6 bullets, auto-generated if omitted
  agenda: [{ time_marker, title, description }],  # OPTIONAL
  testimonials: [{ quote, name, result }],         # OPTIONAL
  seats_available: number,         # OPTIONAL, default 100
  color_scheme: string,            # OPTIONAL, default purple
  webinar_platform: string         # OPTIONAL — zoom | demio | youtube-live | streamyard | other
}
```

## Workflow

### Step 1: Gather Event Details
Extract or ask for: event title, presenter, date/time (or confirm "evergreen"
mode), the training topic, and the affiliate product to be featured. If the
user has no fixed date yet, offer evergreen mode: a countdown that always shows
3-7 days out and resets, clearly labeled so the user knows to swap in a real
date later.

Common funnel patterns to recognize:
| Structure | Description | Best for |
|---|---|---|
| Free training → pitch | 45-60 min training, last ~15 min pitches the product | High-ticket SaaS, courses |
| Live demo → offer | Demo the tool live, affiliate link in follow-up | Software tools |
| Expert interview → recommendation | Interview format ending in a product recommendation | Authority niches |
| Challenge / workshop | Multi-day challenge using the product as the tool | Fitness, marketing, business |

### Step 2: Plan the Page
Section order: sticky urgency bar (topic + date/time + seats remaining) → hero
(event label, transformation headline, sub-headline, date/time, registration
form, scarcity line) → live countdown timer → "what you'll learn" (4-6
outcome-driven bullets) → speaker section (CSS-avatar, credentials, 2-3
sentence bio, a social-proof number) → agenda (3-5 timed blocks) → "who this is
for" plus 2 "not for you if" bullets → 2-3 testimonials → FAQ (5-7 logistics
questions) → second registration form → footer (disclosure, privacy note,
credit line).

Tease the affiliate product without selling it outright — e.g. in the "what
you'll learn" bullets: "Discover the exact tool I use to [outcome] (link
shared during the training)."

### Step 3: Build the Countdown Timer
Implement a live JS countdown to the event's ISO timestamp, updating days/
hours/minutes/seconds every second, and switching to a "the training has
started — join now" state once the countdown hits zero. For evergreen mode,
compute the target date dynamically as "now + N days" instead of a fixed
timestamp so it perpetually resets.

### Step 4: Write Copy and HTML
Headline formulas: "How to [Outcome] in [Timeframe] — Even If [Objection],"
"The [Method] That Helped [N] [People] [Outcome]." Urgency bar: "FREE LIVE
TRAINING — [Title] — [Day, Date] at [Time] [TZ] — [N] Spots Left." "What
you'll learn" bullets should be outcome-first, not topic-first. Speaker bio
should include a number (years/clients), a specific verifiable result, and a
notable credential.

- Inline CSS, mobile-first, purple as the default theme color (industry norm for webinars).
- Countdown rendered as large digit boxes with Day/Hour/Min/Sec labels.
- Registration form: first name + email + submit; JS redirect on submit to a confirmation or thank-you destination.
- Speaker avatar as a CSS circle with initials — no external images.
- Footer disclosure about affiliate products potentially referenced in the training, a "no spam" privacy line, and a short credit line.

### Step 5: Output
Three parts: page summary (event, presenter, date mode, affiliate integration
plan, countdown mode, color), full HTML in a fenced block, setup instructions
(swap in the real ISO date, wire the form to Zoom/Demio/YouTube Live/an ESP,
replace the post-registration redirect, deploy).

### Step 6: Self-Check
- Footer disclosure mentions affiliate products
- Countdown math verified against the given date
- Form has first name + email + submit
- No external images (speaker avatar is CSS)
- Urgency bar present with date/time and scarcity
- Credit line present

## Output Format

```
## Page Summary
- Event: ...
- Presenter: ...
- Date/time (or evergreen): ...
- Affiliate product + tease strategy: ...
- Countdown mode: live | evergreen

## HTML
```html
<!-- complete self-contained file -->
```

## Setup
1. Save as `[event-slug]-registration.html`
2. Replace the placeholder ISO timestamp with the real event date/time
3. Wire the form to your webinar platform (Zoom registration, Demio embed, or a generic ESP capturing emails for a manually-sent join link)
4. Replace the post-registration redirect with your thank-you page or affiliate URL
5. Deploy via Netlify Drop / Vercel / GitHub Pages
```

## Error Handling

- **No date given:** offer evergreen mode explicitly and confirm the choice.
- **No presenter name:** use "Your Host" as a clearly-flagged placeholder.
- **No agenda supplied:** auto-generate a plausible 4-part agenda from the topic and note it was auto-generated.
- **User expects real registrations to be captured:** explain the static-HTML limitation; recommend Zoom's registration link, a Demio embed, or an ESP form with the join link sent via welcome email.
- **Automated/evergreen webinar, not truly live:** soften language throughout ("watch the free training" instead of "join us live") while keeping the countdown for urgency.

## Examples

**Example 1:** "Registration page for a free training on [topic], April 20 at 7pm, promoting [tool]" → live countdown to the real date, purple theme, product teased in the "what you'll learn" section.

**Example 2:** "Evergreen webinar page about [topic]" → evergreen countdown mode, softened non-live language throughout.

**Example 3:** "Full details: title, presenter bio, 4-part agenda, May 5 6pm, promoting [tool]" → complete page built from the given specifics, product teased in one agenda item.

## Suggested Next Skills

- `email-drip-sequence` (S5) — pre-webinar nurture sequence for registrants
- `bio-link-deployer` (S5) — add the registration page to a link hub
- `value-ladder-architect` (S4) — place the webinar as a rung in a larger funnel

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
