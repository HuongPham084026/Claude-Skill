---
name: paid-ad-copy-writer
description: Generate compliant, platform-formatted paid ad copy (Facebook, Google Search/Display, TikTok, Pinterest) for affiliate offers — 3-5 variants per platform testing different angles (pain point, benefit, social proof, curiosity, urgency), routed through a bridge landing page since most ad platforms ban direct affiliate links. Use when the user wants to run paid traffic to an affiliate offer and needs ad copy, compliance checks, targeting suggestions, or budget guidance.
stage: S7 Automation
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Paid Ad Copy Writer

Write ready-to-launch ad copy for scaling an affiliate offer with paid traffic.
Covers Facebook, Google Search, Google Display, TikTok, and Pinterest, each
with format-correct character counts and platform-specific compliance
guardrails — because most ad networks flag or ban direct affiliate links, so
every campaign here routes through a bridge/landing page instead.

## When to Use

- User wants to run paid ads (Facebook, Google, TikTok, Pinterest) for an affiliate product
- User asks for "ad copy," "ad variants," or "campaign copy" for a specific platform
- User already has a landing page and wants traffic-ready creative to send to it
- User wants A/B test variants around different psychological angles for the same offer

## Input Schema

```
{
  product_name: string,       # REQUIRED
  platform: string,           # REQUIRED — "facebook" | "google_search" | "google_display" | "tiktok" | "pinterest"
  landing_page_url: string,   # STRONGLY RECOMMENDED — never the raw affiliate link
  audience: string,           # OPTIONAL — description of target audience
  budget: string,             # OPTIONAL — daily/total budget for allocation guidance
  angles: string[]            # OPTIONAL — subset of ["pain_point","benefit","social_proof","curiosity","urgency"]
}
```

## Workflow

### Step 1: Analyze the product and audience
Identify the core benefit, the primary pain point it solves, and 1-2 believable social-proof angles (numbers, testimonials, before/after framed honestly). This becomes the raw material for every variant.

### Step 2: Apply the platform's format requirements
- **Facebook**: primary text 500+ chars (front-loaded, first line does the work), headline ≤40 chars, description ≤30 chars, native CTA button (e.g., "Learn More," "Sign Up")
- **Google Search**: 3 headlines ≤30 chars each, 2 descriptions ≤90 chars each, plus sitelink extension ideas
- **Google Display**: short headline, long headline, one description, business name, paired with an image concept
- **TikTok**: 15-30 second video script — 3-second hook, on-screen overlay CTA, native/UGC tone (ads that look like ads get skipped)
- **Pinterest**: pin title ≤100 chars, description ≤500 chars, on-image text overlay, keyword-optimized for Pinterest search

### Step 3: Generate 3-5 variants around different angles
Each variant tests one primary angle: pain point ("still struggling with X?"), benefit ("get X in half the time"), social proof ("10,000+ marketers switched to X"), curiosity ("the tool most creators won't tell you about"), or urgency ("price goes up after this week"). Keep the offer identical across variants — only the hook and framing change, so results are attributable to the angle.

### Step 4: Run the compliance pass
- Affiliate links are not used directly in the ad — always route to a bridge/landing page
- No unsubstantiated income or health claims; no before/after imagery without evidence
- FTC-style disclosure present on the landing page (and in-ad where the platform requires it, e.g., Facebook's "Paid Partnership" label)
- Ad copy's core claim matches what the landing page actually says — mismatches get accounts flagged and tank Quality Score

### Step 5: Suggest targeting and budget allocation
Recommend targeting parameters appropriate to the platform (interests/lookalikes for Facebook, keywords/match types for Google, hashtag/interest categories for TikTok, keyword-rich boards for Pinterest). Propose a **test phase** at roughly $10/day per variant, then a **scale phase**: kill any variant with <0.5% CTR after 500+ impressions, and increase budget ~50% on any variant sustaining 2x+ ROAS after 5 days.

### Step 6: Self-validate before delivering
- [ ] Every headline/description is within its platform's character limit
- [ ] No raw affiliate link anywhere in ad copy — landing page URL only
- [ ] No prohibited claim language (guarantees, unverified before/after, medical/income promises)
- [ ] Each variant tests a genuinely distinct angle, not a cosmetic rewrite of the same hook
- [ ] Compliance notes are specific to the named platform, not generic

## Output Format

```
## Paid Ad Copy: [Product] on [Platform]

### Campaign Overview
Goal / landing page / budget assumptions

### Ad Variants
**Variant 1 — [Angle]**
[Platform-formatted fields with char counts noted, e.g. Headline (28/30 chars): ...]

**Variant 2 — [Angle]**
...
(3-5 total)

### Compliance Checklist
- [x] / [ ] item — note if flagged

### Targeting Suggestions
- ...

### Budget Plan
- Test phase: $X/day per variant for N days
- Kill criteria: ...
- Scale criteria: ...
```

## Error Handling

- **No landing page URL provided:** Warn explicitly that using the raw affiliate link risks the ad account being banned, and either request a landing page or hand off to a landing-page-builder skill first.
- **Platform not specified:** Ask which platform, since format requirements are too different to guess (a Google headline and a TikTok script share nothing structurally).
- **Product involves health, finance, or income claims:** Apply stricter compliance language, strip any implied guarantee, and flag that these verticals face extra platform scrutiny (higher rejection risk) regardless of how the copy is worded.
- **User wants only 1 variant:** Deliver it, but recommend at least 3 for meaningful A/B signal and explain that single-variant tests can't isolate what's working.

## Examples

**Example 1:** "Write Facebook ads for my HeyGen affiliate offer, landing page is heygenreview.com" → 4 variants (pain point, benefit, social proof, urgency) each with primary text/headline/description at correct lengths, plus a compliance note to add the "Paid Partnership" label.

**Example 2:** "Google Search ads for a VPN affiliate program, $20/day budget" → 3 headline/2 description sets per variant, keyword-based targeting suggestions, and a test-phase budget split across 3 variants at ~$6-7/day each.

**Example 3:** "TikTok ad script for an AI writing tool" → 20-second UGC-style script with a 3-second pattern-interrupt hook, on-screen overlay text cues, and a native spoken CTA, plus a note that TikTok penalizes overly polished "ad-looking" creative.

## Suggested Next Skills

- `conversion-tracker` (S6) — tag each ad variant's landing-page link separately to measure ROAS per angle
- `email-automation-builder` (S7) — capture paid-traffic leads into a branching nurture flow instead of a one-touch ad click
- `content-repurposer` (S7) — turn the winning ad angle into organic social/blog content once it's proven

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
