---
name: content-decay-detector
description: Audit existing blog content for ranking drops, outdated information, and competitor freshness gaps, then produce a prioritized refresh queue. Use for monthly content maintenance, when traffic is declining on specific pages, or when the user asks which articles need updating — refreshing decaying content is typically the highest-ROI SEO activity available.
stage: S3 Blog/SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Decay Detector

Monitor existing content for ranking drops and generate a prioritized refresh
queue. Refreshing decaying content is typically the highest-ROI SEO activity
available — it's faster and cheaper than writing new content, and recovering a
lost ranking position is usually easier than earning a brand-new one.

## When to Use

- User has an existing blog and wants a decay check
- Traffic is visibly declining on specific pages
- User asks "what content needs updating?"
- Request mentions "content decay", "ranking drops", "stale content", "refresh", "content audit"
- Routine monthly maintenance — worth running every 30 days on an active blog
- After an SEO audit surfaces pages losing rank

## Input Schema

```
{
  site_url: string           # REQUIRED — the site to audit
  content_list: [            # OPTIONAL — specific pages to check
    { url, title, publish_date, last_updated, target_keyword }
  ]
  check_competitors: boolean # OPTIONAL — check if rivals published fresher content (default true)
  timeframe: string          # OPTIONAL — "30d" | "90d" (default) | "6m" | "1y"
}
```

## Workflow

### Step 1: Gather Content Data
If `content_list` isn't supplied:
1. `site:[site_url]` to discover indexed pages
2. Identify the 15-20 most important pages by topic relevance
3. For each, note title, URL, and apparent publish/update date

### Step 2: Check for Decay Signals
For each page:
1. Search its target keyword and check its current ranking position
2. Look for:
   - **Outdated information** — old pricing, discontinued features, stale dates
   - **Competitor freshness** — newer, better competitor content now outranking it
   - **Missing elements** — no images/data, thinner than the current SERP average
   - **Broken freshness signals** — a "2023" in the title/date when it's well past that year

### Step 3: Score Decay Priority
| Factor | Score | Criteria |
|---|---|---|
| Revenue impact | 1-5 | Has affiliate links + had real traffic = high |
| Decay severity | 1-5 | Major outdated info = 5, cosmetic issue = 1 |
| Fix effort (inverted) | 1-5 | Quick edit = 5, full rewrite = 1 |
| Competitor threat | 1-5 | A rival published a clearly better version = 5 |

`Priority = Revenue x Decay x Fix_Ease x Competitor_Threat` (normalized across pages).

### Step 4: Generate Refresh Instructions
For each decaying page, in priority order, specify:
1. **What's decayed** — the specific outdated elements
2. **What to update** — concrete changes to make
3. **What to add** — sections/data/elements competitors now have that this page lacks
4. **Internal linking** — new pages published since that should link to/from this one
5. **Estimated effort** — realistic time to refresh

### Step 5: Self-Validate
- Decay signals are evidence-based, not guessed
- Priority order makes business sense — revenue-impacting pages come first
- Refresh instructions are specific and actionable, not vague
- Effort estimates are realistic
- Pages that are performing fine are NOT flagged for refresh

## Output Format

```
## Content Decay Report: [Site]

### Summary
- Pages analyzed: XX | Pages decaying: XX | Total refresh effort: XX hours
- Estimated traffic recovery: XX%

### Priority Refresh Queue

#### P0 — Critical (this week)
**[Page Title]** — [URL]
- Decay: [what's wrong]
- Action: [what to do]
- Effort: [time estimate]
- Impact: [expected result]

#### P1 — High (this month)
[same structure]

#### P2 — Medium (schedule)
[same structure]

### Healthy Pages (no action needed)
- [Page] — still ranking, content fresh

### Monthly Maintenance Schedule
- Week 1: refresh P0 pages
- Week 2: refresh P1 pages
- Week 3: create new content for gaps found
- Week 4: internal linking review
```

## Error Handling

- **No site URL given:** ask for the blog's URL before doing anything else.
- **No indexed pages found:** flag that the site may not be public or indexed, and ask the user to confirm.
- **All content is fresh:** report that no significant decay was found and suggest re-running the check in 30 days.
- **Can't determine exact ranking positions:** fall back to available signals — content age, competitor freshness, outdated facts — to prioritize instead.

## Examples

**Example 1:** "Check my blog for content decay" → crawl indexed pages, screen each for decay signals, return a prioritized refresh queue with specific per-page actions.

**Example 2:** "Which of my articles need updating?" → analyze the supplied content list, flag outdated pricing/stale comparisons/missing new products, rank by revenue impact.

**Example 3:** "Content decay check" (after an SEO audit) → pick up the declining pages the audit surfaced, deep-dive each with competitor comparison and concrete refresh instructions.

## Suggested Next Skills

- `keyword-cluster-architect` (S3) — content gaps found during decay analysis often reveal missing clusters
- `content-moat-calculator` (S3) — factor refreshed pages into the topical-authority page count
- `internal-linking-optimizer` (S6) — decaying pages often also have weak internal link structure
- `how-to-tutorial-writer` (S3) / `listicle-generator` (S3) — rewrite severely decayed pages using a stronger format

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
