---
name: github-pages-deployer
description: Generate a complete, ready-to-deploy GitHub Pages setup (repo structure, CI/CD workflow, custom domain/SSL config) for a landing page, bio-link hub, or blog. Use when the user wants free hosting for HTML they already have, or wants to deploy a page built earlier in the conversation.
stage: S5 Distribution
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# GitHub Pages Deployer

Generate a complete, ready-to-deploy GitHub Pages setup for landing pages, bio
link hubs, and blog posts. Outputs the full repo file structure, a GitHub Actions
CI/CD workflow for automatic deploys, and step-by-step instructions for custom
domain configuration with SSL. Free hosting, no credit card required.

## When to Use

- User wants to deploy a landing page or bio-link page to a free host
- User wants free static hosting with a custom domain and SSL
- User already has HTML files and wants to publish them without paying for hosting
- User wants automated deploys so pushing to `main` auto-updates the live site
- User wants to host a simple blog or resource page for free

## Input Schema

```yaml
site:
  type: string              # REQUIRED — "landing-page" | "bio-link" | "blog" | "resource-page"
  html_content: string      # REQUIRED — the HTML content to deploy (full file or description)
  title: string              # REQUIRED — site title (used in repo name and meta)
  description: string        # OPTIONAL — meta description for SEO

repo:
  name: string               # OPTIONAL — repo name (auto-generated from title if omitted)
  username: string           # OPTIONAL — GitHub username, used in generated URLs
  visibility: string         # OPTIONAL — "public" | "private" (default: public; private needs GitHub Pro)

domain:
  custom: string             # OPTIONAL — custom domain (e.g., "links.yourdomain.com")
  subdomain: string          # OPTIONAL — "apex" | "subdomain"

deploy:
  method: string             # OPTIONAL — "github-actions" | "manual" (default: github-actions)
  branch: string             # OPTIONAL — source branch (default: "main")
```

## Workflow

### Step 1: Gather Inputs

Check if HTML was generated earlier in the conversation. If yes, confirm and ask for the GitHub username. If not, ask for HTML content or offer to create the page first.

### Step 2: Generate Repo Structure

Standard structure for a single-page site:
```
[repo-name]/
├── index.html
├── assets/
│   ├── css/style.css
│   └── images/.gitkeep
├── CNAME                   # only if custom domain
├── .github/workflows/deploy.yml
├── .gitignore
└── README.md
```
For multi-page blogs, add `blog/`, `about/`, and `sitemap.xml`.

### Step 3: Generate the GitHub Actions Workflow

```yaml
# .github/workflows/deploy.yml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4
      - name: Setup Pages
        uses: actions/configure-pages@v5
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: '.'
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

### Step 4: Generate CNAME File (if custom domain)

Just the domain, e.g. `links.yourdomain.com`.

### Step 5: Generate DNS Instructions

**Subdomain (e.g., links.yourdomain.com):**
```
Type: CNAME
Name: links
Value: [username].github.io
```

**Apex domain (yourdomain.com):**
```
Type: A     Name: @   Value: 185.199.108.153
Type: A     Name: @   Value: 185.199.109.153
Type: A     Name: @   Value: 185.199.110.153
Type: A     Name: @   Value: 185.199.111.153
Type: AAAA  Name: @   Value: 2606:50c0:8000::153
Type: AAAA  Name: @   Value: 2606:50c0:8001::153
Type: AAAA  Name: @   Value: 2606:50c0:8002::153
Type: AAAA  Name: @   Value: 2606:50c0:8003::153
```
Always verify current IPs at GitHub Pages' official custom-domain documentation.

### Step 6: Generate README.md

Simple README with live URL, deploy method, and credits.

### Step 7: Output the Complete Setup

Present in numbered sections with clear file labels — copy-paste ready.

### Step 8: Self-Validation

- [ ] GitHub Actions YAML is valid syntax
- [ ] CNAME file is correct format if custom domain configured
- [ ] All file paths are valid and consistent
- [ ] Deployment commands are copy-paste ready
- [ ] README.md is included

## Output Format

**Section 1: Summary** — repo name, live URL, custom domain URL, estimated time to go live
**Section 2: Files to Create** — each file in its own labeled code block
**Section 3: GitHub Setup Steps** — numbered: create repo → push → enable Pages → set source to GitHub Actions
**Section 4: DNS Setup** (if custom domain) — exact records as a table, with a Cloudflare proxy-off note
**Section 5: Verification** — how to confirm the deploy worked and SSL is active

## Error Handling

- **No HTML content and nothing built earlier**: ask whether to build a page first or paste HTML.
- **Private repo on free GitHub account**: private repos need GitHub Pro for Pages; offer public repo or an alternative free host as options.
- **Custom domain not propagating**: DNS can take 1-48h; check CNAME file has no `https://` prefix and the DNS value has no trailing slash; Cloudflare proxy must be OFF (grey cloud).
- **GitHub Actions failing**: common causes — Pages not enabled in Settings, branch mismatch, missing `pages: write` permission.
- **User wants WordPress/dynamic site**: GitHub Pages is static only — recommend Cloudflare Pages/Netlify/a VPS instead, or note static is faster/better for SEO for a simple page.
- **Repo name taken**: suggest appending year or niche to the name.

## Examples

**Example 1:** Deploy a landing page built earlier, username given → auto-use that HTML, generate repo + Pages URL + full file set.

**Example 2:** Deploy a bio-link page with a custom domain (e.g., `links.mysite.com`) → repo + CNAME file, DNS instructions, Cloudflare proxy-off note.

**Example 3:** Multi-page resource site with homepage, about page, 3 posts → generate the multi-page structure and note that a static site generator (Jekyll/Eleventy) is worth it once posts exceed ~10.

## Suggested Next Skills

- Set up conversion/UTM tracking on the deployed URL
- Run an SEO audit once indexed

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT-style, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
