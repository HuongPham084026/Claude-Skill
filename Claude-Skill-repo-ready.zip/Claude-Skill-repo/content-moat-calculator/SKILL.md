---
name: content-moat-calculator
description: Estimate how many pages of content are needed to build topical authority in a niche, by benchmarking against top-ranking competitors, and deliver a go/no-go feasibility verdict before months of writing effort are committed. Use when the user is deciding whether a niche is worth investing in or asks how many articles it takes to rank.
stage: S3 Blog/SEO
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Content Moat Calculator

Estimate the total content investment required to establish topical authority
in a niche by analyzing competitors' content volume and quality, then deliver a
clear go/no-go call before months of writing get committed. Answers: "how many
pages do I actually need to dominate this topic?"

## When to Use

- User is deciding whether to commit to a niche or topic
- User asks "how many articles do I need to rank?"
- User wants to understand the content investment a niche requires
- Request mentions "content moat", "topical authority", "feasibility", "content gap"
- After keyword clustering, to size the effort behind the planned clusters
- Before committing to any major content initiative

## Input Schema

```
{
  niche: string              # REQUIRED — the topic to analyze
  hub_keyword: string        # OPTIONAL — main keyword to benchmark competitors on
  your_current_pages: number # OPTIONAL — pages you already have on this topic (default 0)
  publishing_capacity: string # OPTIONAL — "1/week" | "2/week" (default) | "3/week" | "5/week"
}
```

## Workflow

### Step 1: Analyze Top Competitors
1. Search the hub keyword or main niche term
2. Identify the top 5 ranking sites, excluding giants (Wikipedia, Reddit, etc.)
3. For each: `site:[competitor.com] [niche topic]` to count pages on the topic, and note content depth (word count), freshness (publish dates), and content types used

### Step 2: Calculate the Moat

```
Average competitor pages = sum(competitor_pages) / number_of_competitors
Moat target = Average x 1.5   (need more than average to break through)
Content gap = Moat target - your_current_pages
Weeks to moat = Content gap / publishing_capacity_per_week
```

### Step 3: Feasibility Assessment

| Moat Target | Verdict | Recommendation |
|---|---|---|
| < 20 pages | GREEN — achievable | Go for it: 2-3 months at 2/week |
| 20-50 pages | YELLOW — significant | Commit fully or don't start: 3-6 months |
| 50-100 pages | ORANGE — major investment | Consider narrowing the niche: 6-12 months |
| 100+ pages | RED — very high barrier | Find a sub-niche or a different angle entirely |

### Step 4: Find Ways to Build the Moat Faster
1. **Quality over quantity** — can fewer, deeper pages beat thin competitor content?
2. **Unique data** — can proprietary data or original research be added that competitors lack?
3. **Format advantage** — video, interactive tools, calculators competitors don't offer?
4. **Update velocity** — can content be refreshed faster than competitors refresh theirs?

### Step 5: Build a Phased Timeline
- Phase 1 — Foundation: hub + core spokes
- Phase 2 — Supporting: additional spokes, long-tail
- Phase 3 — Authority: original research, comprehensive guides, proprietary data
- Phase 4 — Maintenance: refresh, update, expand

### Step 6: Self-Validate
- Competitor page counts come from real searches, not estimates
- The moat math is shown and transparent
- The feasibility verdict is honest, not optimistic spin
- Suggested competitive advantages are realistic, not wishful
- Timeline accounts for quality of content, not just volume

## Output Format

```
## Content Moat Analysis: [Niche]

### Competitor Landscape
| Competitor | Pages on Topic | Quality | Freshness |
|---|---|---|---|
| [domain] | XX | thin/average/deep | stale/recent/active |

### Moat Calculation
- Average competitor pages: XX
- Your moat target (1.5x): XX
- Your current pages: XX
- Content gap: XX
- At [X]/week: XX weeks to moat

### Feasibility: [GREEN/YELLOW/ORANGE/RED]
[honest, actionable assessment paragraph]

### Competitive Advantages
1. [way to build the moat faster]
2. [gap competitors are leaving open]

### Timeline
| Phase | Content | Pages | Weeks |
|---|---|---|---|
| Foundation | Hub + core spokes | XX | X |
| Supporting | Long-tail, tutorials | XX | X |
| Authority | Original research/data | XX | X |
| Total | | XX | X |

### Recommendation
[clear go/no-go with the reasoning behind it]
```

## Error Handling

- **No clear competitors found:** broaden the search; if still none, treat it as a blue-ocean signal and estimate a light moat of 15-20 pages.
- **Niche too broad to analyze meaningfully:** recommend narrowing to a sub-niche first before recalculating.
- **User already has substantial content:** factor in existing pages — they may already be near the moat target, so focus the analysis on gaps and freshness instead.
- **All competitors are massive authority sites:** recommend niching down — out-specializing a giant beats trying to out-produce it.

## Examples

**Example 1:** "How much content do I need to dominate AI video tools?" → top 5 sites average 35 pages, moat = 53 pages, at 2/week = 27 weeks → YELLOW, significant but doable.

**Example 2:** "Can I compete in email marketing?" → competitors average 200+ pages, moat = 300 → RED, too broad; suggest narrowing to "email marketing for Shopify stores" where the moat drops to ~25 pages, GREEN.

**Example 3:** "Content moat for my keyword clusters" (following a clustering exercise) → estimate pages needed per cluster, benchmark each against competitors, flag which clusters are GREEN vs RED.

## Suggested Next Skills

- `keyword-cluster-architect` (S3) — supply the cluster count that feeds this moat estimate
- `content-decay-detector` (S3) — check whether existing pages already count toward the moat or need refreshing first
- `listicle-generator` (S3) / `how-to-tutorial-writer` (S3) — start filling the Foundation phase once the moat is judged GREEN or YELLOW

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
