---
name: trending-content-scout
description: Analyze top-performing content across YouTube, TikTok, X, and Reddit for a niche to surface winning formats, hooks, durations, and creators before writing anything new. Use when the user wants to know what content is already working in a niche, needs data-backed inspiration before scripting, or asks "what should I make content about?"
stage: S1 Research
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Trending Content Scout

Stop guessing what content works — pull real engagement data across platforms,
normalize it into a comparable score, and extract the patterns (formats,
hooks, lengths, creators) that are already winning in the niche. Also
surfaces content gaps: angles nobody has covered well yet.

## When to Use

- User wants to know what content is currently resonating in a niche before creating their own
- User is starting a new content channel/account and needs a data-backed starting point
- User wants competitor/creator benchmarks, not just their own catalog
- Feeds directly into `content-angle-ranker` for angle selection

## Input Schema

```
{
  niche: string                  # required — topic or keyword to scout
  platforms: string[]            # optional — subset of ["youtube","tiktok","x","reddit"], default: all
  timeframe: string              # optional — "week" | "month" | "quarter", default: month
  min_engagement: number         # optional — filter floor
}
```

## Workflow

### Step 1: Choose Data Source
Use configured platform APIs when available (YouTube Data API, TikTok, X/Twitter
API, Reddit API). If none are available, fall back to `web_search` with
site-restricted queries, e.g. `site:reddit.com "<niche>"`, `"<niche>" youtube views`.

### Step 2: Collect Content Samples
Pull 15-25 pieces of top content per platform within the timeframe. For each,
capture: title/hook, format, views, likes, comments, shares, publish date, creator.

### Step 3: Normalize Engagement
Apply a consistent cross-platform engagement score so results are comparable:

```
engagement_score = (likes × 2 + comments × 3 + shares × 5) / max(views, 1) × 1000
```

Adjust for platforms without a "views" metric (e.g., Reddit: use upvotes as
the views proxy; X: use impressions if available, otherwise likes+reposts as proxy).

### Step 4: Sort and Rank
Rank content by engagement score (primary), with views and recency as
tiebreakers. Surface the top 10 across all platforms combined, plus top 5 per
individual platform.

### Step 5: Analyze Patterns
Classify each top-performer by:
- **Format**: comparison, review, tutorial, listicle, reaction, story, demo, explainer
- **Hook type**: question, shock, bold_claim, demo_first, relatable, contrarian
- **Length/duration**: note the sweet spot per platform
- **Repeat creators**: who shows up multiple times in the top results — these are the people to study closely

### Step 6: Identify Content Gaps
Compare what's covered heavily vs. what's mentioned in comments/search but has
no strong existing content — these are the underserved angles worth targeting.

### Step 7: Set Benchmarks
Calculate median and top-quartile engagement scores per platform so future
content has a concrete performance target, not a vague "do well."

## Output Format

```
## Trending Content Scout: [Niche]

### Top Performing Content (All Platforms)
| Rank | Title/Hook | Platform | Format | Hook Type | Engagement Score | Views |
|---|---|---|---|---|---|---|
| 1 | ... | ... | ... | ... | ... | ... |

### Winning Patterns
- **Dominant format**: [format] (X of top 10)
- **Dominant hook type**: [type]
- **Sweet-spot length**: [duration/word count]
- **Creators to study**: [names, with what they're doing differently]

### Content Gaps (Underserved Angles)
1. [Angle] — mentioned in comments/search but no strong existing content
2. [Angle] — ...

### Engagement Benchmarks
| Platform | Median Score | Top Quartile Score |
|---|---|---|
| ... | ... | ... |

### Recommended Next Step
Run `content-angle-ranker` on these gaps and patterns to select the best angle to produce.
```

## Error Handling

- **No API access to a platform**: fall back to `web_search` and clearly label the data as estimated/directional rather than exact.
- **Niche too narrow, few results found**: widen the search term to a parent category and note the narrowing was necessary.
- **Engagement metrics missing (e.g., no view counts)**: use available proxies (upvotes, reposts) and state the substitution explicitly.
- **All top content from one or two creators**: flag this as a signal the niche may be creator-dominated; note it as a risk for a new entrant.

## Examples

**Example 1:** "What's working in the AI video editing niche on YouTube and TikTok right now?" → Pulls top 20 videos per platform, scores engagement, finds "demo_first" hooks and comparison-format videos dominate, surfaces a gap around beginner tutorials.

**Example 2:** "Scout Reddit and X for personal finance content before I start posting" → Normalizes upvotes/reposts into engagement scores, identifies contrarian hooks outperforming generic listicles, sets a benchmark score for new posts to beat.

## Suggested Next Skills

- `content-angle-ranker` (S1) — score and rank specific angle candidates generated from this scouting data
- `monopoly-niche-finder` (S1) — if the niche looks oversaturated, find an underserved intersection instead
- `viral-post-writer` (S2) — turn the winning pattern into an actual script/post

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
