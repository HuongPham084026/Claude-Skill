---
name: social-media-scheduler
description: Generate a 30-day social media content calendar for affiliate promotion across platforms like LinkedIn, X, Facebook, and Reddit, mixing educational, engagement, and promotional posts on an 80/20 value-to-pitch ratio with an escalating weekly promotional arc. Use when the user wants a content calendar, a posting schedule, or help spreading affiliate promotion across social channels without sounding spammy.
stage: S5 Distribution
source: Affitor/affiliate-skills (github.com/Affitor/affiliate-skills), MIT-style open skill collection
---

# Social Media Scheduler

Produces a full month of platform-tailored social posts that promote an
affiliate product without burning out the audience. The core principle is
80/20: roughly 80% of posts deliver value or spark engagement, and only 20%
pitch the product directly — with promotional intensity increasing gradually
across the month rather than front-loading the pitch.

## When to Use

- User wants a content calendar or posting schedule for promoting an affiliate product
- User is active on LinkedIn, X, Facebook, or Reddit and needs a repeatable posting cadence
- User says things like "content calendar", "posting schedule", "social media plan", or "help me promote this without spamming my followers"
- A product was already identified earlier in the conversation and the user now wants a social plan built around it

## Input Schema

```
{
  product: { name: string, affiliate_url: string },   # REQUIRED
  niche: string,                                        # REQUIRED - creator's niche
  audience: string,                                     # REQUIRED - target audience
  platforms: string[],           # subset of ["linkedin","x","facebook","reddit"]
  price: string, trial_available: boolean,              # optional
  personal_experience: string,                          # optional - user's own story with the product
  posts_per_week: number         # optional, 3-7, default 5
}
```

If a product and its benefits were already established earlier in the
conversation, reuse them instead of re-asking.

## Workflow

### Step 1: Build the Four-Week Promotional Arc
Escalate promotional intensity gradually so the audience is warmed up
before being pitched:

| Week | Theme | Promo Share |
|---|---|---|
| 1 | Pure education — establish authority in the niche | 0% |
| 2 | Problem identification — name the pain point the product solves | 10% |
| 3 | Solution introduction — introduce the product as one answer | 30% |
| 4 | Social proof — testimonials, results, case studies, direct CTA | 40% |

### Step 2: Set the Post-Type Mix
Across the full month, distribute posts by type so promotion never
dominates the feed:

| Type | Share | Purpose |
|---|---|---|
| Educational | 30% | Teach something useful in the niche, no product mention |
| Engagement-driven | 20% | Questions, polls, hot takes that invite replies |
| Personal storytelling | 20% | Creator's own journey, wins, failures — builds trust |
| Curated resources | 15% | Share/comment on other people's useful content |
| Promotional | 15% | Direct product mention with a CTA and disclosure |

### Step 3: Tailor Copy Per Platform
Write distinct copy for each selected platform rather than cross-posting
identical text:

- **LinkedIn** — professional hook in line 1, 3-5 bullet points, close with a question or CTA
- **X (Twitter)** — punchy, thread-friendly, front-load the payoff in post 1 of a thread
- **Facebook** — conversational, invites comments/community discussion, longer-form OK
- **Reddit** — genuine value first, house rules respected, affiliate link disclosed separately (never disguised) and only in subreddits that allow it

### Step 4: Schedule and Sequence
Distribute `posts_per_week` (default 5) across the week, spacing promotional
posts so they never land back-to-back. Map each post to: date/day, platform,
post type, and week theme from Step 1.

### Step 5: Assemble the Calendar
For every post, produce: platform, day/date, post type, full copy (in the
platform's voice from Step 3), suggested hashtags/tags where relevant, and
an FTC disclosure line on every post that includes the affiliate link.

### Step 6: Self-Check Before Delivering
- Total post count matches `posts_per_week` × ~4.3 weeks (~30 posts for a 30-day month)
- Value-to-promotion ratio holds at roughly 80/20 across the full calendar
- Weekly promotional intensity escalates per the Step 1 arc, not front-loaded
- Every platform selected has copy tailored to its norms, not duplicated text
- Every post carrying the affiliate link has a disclosure

## Output Format

```
## 30-Day Social Media Calendar — <product name>

### Week 1 — Education (0% promo)
| Day | Platform | Type | Post Copy | CTA/Link |
|---|---|---|---|---|
| ... |

### Week 2 — Problem Identification (10% promo)
...

### Week 3 — Solution Introduction (30% promo)
...

### Week 4 — Social Proof (40% promo)
...

--- SETUP NOTES ---
Scheduling tool suggestions: Buffer, Later, Hypefury (X), native schedulers
Disclosure: append affiliate disclosure to every promotional post
Tracking: use a UTM-tagged or shortened affiliate link per platform to compare performance
---
```

## Error Handling

- **No platforms specified:** default to LinkedIn + X as the broadest professional/affiliate-friendly pair, and note the choice.
- **Reddit selected with no target subreddit given:** ask which subreddits, and flag that Reddit requires stricter self-promotion rules than other platforms.
- **No personal experience with the product:** lean harder on educational and curated content in the mix rather than fabricating a testimonial-style post.
- **posts_per_week outside 3-7:** clamp to the nearest bound (3 or 7) and tell the user why.
- **Vague niche/audience:** ask one clarifying question before generating rather than producing generic filler copy.

## Examples

**Example 1:** "Give me a 30-day content calendar promoting HeyGen to YouTube creators on LinkedIn and X" → builds the 4-week arc, ~5 posts/week per platform, LinkedIn bullet-style posts and X threads, escalating promo share by week.

**Example 2:** (after an earlier step found a product with a strong personal-use angle) "Now build a posting schedule for it on Facebook and Reddit" → reuses the product context, weights week 1-2 toward Facebook community posts and value-first Reddit posts respecting subreddit self-promo norms.

**Example 3:** "I need a social media plan but I've never used the product myself" → shifts the mix toward educational and curated content, keeps promotional posts factual (features/pricing) rather than personal testimonial.

## Suggested Next Skills

- `bio-link-deployer` (S5) — give every post one consistent link to drive traffic to
- `email-drip-sequence` (S5) — capture social traffic into an owned email list
- `conversion-tracker` (S6) — measure which platform and post type actually converts

## Attribution

Adapted from the open-source **Affitor/affiliate-skills** collection (MIT License, github.com/Affitor/affiliate-skills), repackaged as a standalone Claude Skill.
